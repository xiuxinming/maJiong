//
//  GameLayer.h
//  Mahjong
//
//  Created by etgame iphone on 12-8-23.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameManager.h"

@interface GameLayer : CCLayer 
//<MyProtocol>
{
    
}

+(id) scene;

@end

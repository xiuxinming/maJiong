//
//  MainLayer.m
//  Mahjong
//
//  Created by etgame iphone on 12-8-21.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "MainLayer.h"
#import "GameLayer.h"

@implementation MainLayer

static MainLayer *mainLayerInstance;






+(MainLayer *) sharedLayer
{
    // 半单例，任何时候只存在一个实例，不能被用来初始化MainLayer。
    NSAssert(mainLayerInstance != nil, @"MainLayer not available!");
    
    return mainLayerInstance;
}

+(id) scene
{
    CCScene *scene = [CCScene node];
    CCLayer *layer = [MainLayer node];
    [scene addChild:layer];
    
    return scene;
}

-(id) init
{
    if (self = [super init]) 
    {
        mainLayerInstance = self;
        
        
       
        
        GameLayer *gameLayer = [GameLayer node];
        [self addChild:gameLayer z:1 tag:LayerGameTags];
    }
    
    return self;
}

@end

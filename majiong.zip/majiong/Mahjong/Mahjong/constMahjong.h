//
//  constMahjong.h
//  Mahjong
//
//  Created by etgame iphone on 12-8-21.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#ifndef Mahjong_constMahjong_h
#define Mahjong_constMahjong_h

// 万子牌
#define TILE_1W     1 // 一万
#define TILE_2W     2 // 二万
#define TILE_3W     3 // 
#define TILE_4W     4 //
#define TILE_5W     5 //
#define TILE_6W     6 //
#define TILE_7W     7 //
#define TILE_8W     8 //
#define TILE_9W     9 //
// 索子牌
#define TILE_1B     10 // 
#define TILE_2B     11 //
#define TILE_3B     12 //
#define TILE_4B     13 //
#define TILE_5B     14 //
#define TILE_6B     15 //
#define TILE_7B     16 //
#define TILE_8B     17 //
#define TILE_9B     18 //
// 筒子牌
#define TILE_1C     19 //
#define TILE_2C     20 //
#define TILE_3C     21 //
#define TILE_4C     22 //
#define TILE_5C     23 //
#define TILE_6C     24 //
#define TILE_7C     25 //
#define TILE_8C     26 //
#define TILE_9C     27 //
// 字牌：四风牌
#define TILE_E     28 // 东
#define TILE_S     29 // 南
#define TILE_W     30 // 西
#define TILE_N     31 // 北
// 字牌：三元牌
#define TILE_Z     32 // 中
#define TILE_F     33 // 发
#define TILE_B     34 // 白
// 花子
#define TILE_SPR    35 // 春
#define TILE_SUM    36 // 夏
#define TILE_AUT    37 // 秋
#define TILE_WIN    38 // 冬
#define TILE_PLUM   39 // 梅
#define TILE_ORCH   40 // 兰
#define TILE_BAMB   41 // 竹
#define TILE_MUM    42 // 菊

#define N_SAME_TILE 4 // 同种牌的枚数
#define KIND_OF_TILE (9+9+9+7) // 牌的种类数
#define FLOWER_OF_TILE 8 // 花牌数

#define N_ALL_TILE ((N_SAME_TILE * KIND_OF_TILE) + FLOWER_OF_TILE) // 总共的麻将子

#endif

typedef enum {
    // 万子
    eTILE_W_1 = 0x01,
    eTILE_W_2,
    eTILE_W_3,
    eTILE_W_4,
    eTILE_W_5,
    eTILE_W_6,
    eTILE_W_7,
    eTILE_W_8,
    eTILE_W_9,
    // 索子
    eTILE_B_1 = 0x11,
    eTILE_B_2,
    eTILE_B_3,
    eTILE_B_4,
    eTILE_B_5,
    eTILE_B_6,
    eTILE_B_7,
    eTILE_B_8,
    eTILE_B_9,
    // 筒子
    eTILE_C_1 = 0x21,
    eTILE_C_2,
    eTILE_C_3,
    eTILE_C_4,
    eTILE_C_5,
    eTILE_C_6,
    eTILE_C_7,
    eTILE_C_8,
    eTILE_C_9,
    // 字牌
    eTILE_EAST = 0x31,  // 东
    eTILE_SOUTH,        // 南
    eTILE_WEST,         // 西
    eTILE_NORTH,        // 北
    eTILE_ZHONG,        // 中
    eTILE_FA,           // 发
    eTILE_BAI,          // 白
    eTILE_KIND = (9+9+9+7), // 牌的种类数
    // 花子
    eTILE_SPRING = 0x38,// 春
    eTILE_SUMMER,       // 夏
    eTILE_FALL,         // 秋
    eTILE_WINTER,       // 冬
    eTILE_PLUM,         // 梅
    eTILE_ORCH,         // 兰
    eTILE_BAMBOO,       // 竹
    eTILE_MUM,          // 菊
    eTILE_MAX,
} MAHJONG_TILES;// 麻将子数据

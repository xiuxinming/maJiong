//
//  Player.h
//  Mahjong
//
//  Created by etgame iphone on 12-8-7.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface Player : CCSprite {
    
}

@end

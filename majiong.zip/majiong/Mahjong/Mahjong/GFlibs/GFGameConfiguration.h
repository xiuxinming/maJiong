//
//  GFGameConfiguration.h
//  Mahjong_JP
//
//  Created by Gao Feng on 12-8-21.
//  Copyright (c) 2012年 BUPT. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ccTypes.h"

@interface GFGameConfiguration : NSObject
{
    NSMutableDictionary *dictionary;
	NSURL *storeUrl;
	NSMutableArray *highscores;
	NSString *currentPlayer;
	int currentScore;
	int currentScorePosition;
    BOOL isPad;
}

@property(nonatomic, retain) NSMutableDictionary *dictionary;
@property(nonatomic, assign) int currentScorePosition;
@property(nonatomic, assign) int currentScore;
@property(nonatomic, assign) BOOL isPad;

+ (GFGameConfiguration *) sharedInstance;

- (void) load:(NSString*) appname;

- (BOOL) boolForKey:(NSString *) key;

@end

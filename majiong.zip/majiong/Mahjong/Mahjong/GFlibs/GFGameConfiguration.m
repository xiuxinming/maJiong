//
//  GFGameConfiguration.m
//  Mahjong_JP
//
//  Created by Gao Feng on 12-8-21.
//  Copyright (c) 2012年 BUPT. All rights reserved.
//

#import "GFGameConfiguration.h"

@implementation GFGameConfiguration

@synthesize dictionary;
@synthesize currentScorePosition;
@synthesize currentScore;
@synthesize isPad;

static GFGameConfiguration *sharedInstance = nil;

// Init
+ (GFGameConfiguration *) sharedInstance
{
	@synchronized(self)     {
		if (!sharedInstance)
			sharedInstance = [[GFGameConfiguration alloc] init];
	}
	return sharedInstance;
}

+ (id) alloc
{
	@synchronized(self)     {
		NSAssert(sharedInstance == nil, @"Attempted to allocate a second instance of a singleton.");
		return [super alloc];
	}
	return nil;
}

- (id)init {
	if (self == [super init]) {
	}
	return self;
}

- (void)load:(NSString*)appname {
	
	NSString *indexFilePath = [[NSBundle mainBundle] pathForResource:appname ofType:@"plist" inDirectory:@""];
	if (indexFilePath) {
		storeUrl = [NSURL fileURLWithPath:indexFilePath];
		[storeUrl retain];
		dictionary = [NSMutableDictionary dictionaryWithCapacity:10];
		[dictionary retain];
		if ([[NSFileManager defaultManager] fileExistsAtPath:indexFilePath]) {
			NSDictionary *mydictionary = [NSDictionary dictionaryWithContentsOfURL:storeUrl];
			[dictionary addEntriesFromDictionary:mydictionary];
		}
	}
}

- (BOOL)boolForKey:(NSString *)key {
	NSNumber *value = (NSNumber *)[self.dictionary objectForKey:key];
	if (value == nil) {
		return FALSE;
	}
	return (BOOL)[value boolValue];
}

@end

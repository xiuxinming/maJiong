//
//  AppDelegate.h
//  Mahjong_JP
//
//  Created by Gao Feng on 12-8-21.
//  Copyright BUPT 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainMenuLayer.h"

@class RootViewController;

@interface AppDelegate : NSObject <UIApplicationDelegate> {
	UIWindow			*window;
	RootViewController	*viewController;
}

@property (nonatomic, retain) UIWindow *window;

@end

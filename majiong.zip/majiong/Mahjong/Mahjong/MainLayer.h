//
//  MainLayer.h
//  Mahjong
//
//  Created by etgame iphone on 12-8-21.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameManager.h"
#import "Cmd.h"
#import "SocketDef.h"
#import "SocketHelper.h"



typedef enum {
    LayerGameTags,
    LayerUITags,
} MainLayerTags;

@interface MainLayer : CCLayer 

{
    
}

+(id) scene;

@end

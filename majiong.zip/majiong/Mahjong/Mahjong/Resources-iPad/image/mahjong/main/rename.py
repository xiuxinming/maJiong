import sys, string, os

def s_rename(path): 
    find_name = raw_input("enter repalce name:")
    new_name = raw_input("enter new name:")
    for (path, dirs, files) in os.walk(path): 
        for filename in files: 
            ext=os.path.splitext(filename)[1] 
            if (cmp(ext,".png")==0 and filename.find(find_name)>=0):
                newName = filename.replace(find_name, new_name) 
                
                print newName
                                
                try: 
                    os.rename(path+"/"+filename, path+"/"+newName) 
                except ValueError: 
                    print "Error when rename the file " + filename 
                except NameError: 
                    print "Error when rename the file " + filename 
                except OSError: 
                    #print OSError 
                    print newName + " The file is already exist!" 
                
def s_renameID(path):
    find_name = raw_input("find file name:")
    new_name = raw_input("new file name:")
    new_id = raw_input("start ID:")
    intId = int(new_id)
    for (path, dirs, files) in os.walk(path):
        for filename in files:
            suffix = os.path.splitext(filename)[1]
            fname = os.path.splitext(filename)[0]
            fname.lower()
            if (cmp(suffix, ".png")==0 and fname.find(find_name)>=0):
                print "\n"+str(intId)+"find: "+filename
                try: 
                    os.rename(path+"/"+filename, path+"/"+new_name+str(intId)+".png") 
                except ValueError: 
                    print "Error when rename the file " + filename 
                except NameError: 
                    print "Error when rename the file " + filename 
                except OSError: 
                    #print OSError 
                    print new_name + " The file is already exist!" 
                intId+=1
                                
s_rename(".")
#s_renameID(".")

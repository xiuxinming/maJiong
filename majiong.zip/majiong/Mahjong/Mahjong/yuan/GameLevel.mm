//
//  GameLevel\.m
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月11日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import "GameLevel.h"

//服务器信息
extern tagGameServer        GameServer[Majong4Number];

@implementation GameLevel

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	GameLevel *layer = [GameLevel node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}



- (id) init
{
    self = [super init];
    
    if (self != nil)
    {
        
        
        //test 登陆
        CCMenu *shopMenu;
        shopMenu = [CCMenu menuWithItems:nil, nil];
        CGSize screenSize = [CCDirector sharedDirector].winSize;    
        CCMenuItemImage *btBack = [CCMenuItemImage 
                                   itemFromNormalImage:@"Default.png" 
                                   selectedImage:@"Default.png"
                                   disabledImage:nil
                                   target:self
                                   selector:@selector(ButtonTest:)];
        btBack.position = ccp(100,100);
        btBack.scale = 0.2;
        [shopMenu addChild:btBack];
        
        
        
        
        
        CCMenuItemImage *GoLevel = [CCMenuItemImage 
                                    itemFromNormalImage:@"Default.png" 
                                    selectedImage:@"Default.png"
                                    disabledImage:nil
                                    target:self
                                    selector:@selector(ButtonGo:)];
        GoLevel.position = ccp(200,100);
        GoLevel.scale = 0.2;
        [shopMenu addChild:GoLevel];
        
        
        CCMenuItemImage *KuaiPei = [CCMenuItemImage 
                                    itemFromNormalImage:@"Default.png" 
                                    selectedImage:@"Default.png"
                                    disabledImage:nil
                                    target:self
                                    selector:@selector(KuaiPei:)];
        KuaiPei.position = ccp(50,50);
        KuaiPei.scale = 0.2;
        [shopMenu addChild:KuaiPei];
        
        [self addChild:shopMenu];
        

        
    }
    
    return  self;
}
# pragma 测试

//返回主界面
-(void)ButtonTest:(CCMenuItemFont*)itemPassedIn
{
    
    [[CCDirector sharedDirector] replaceScene: [MainLayer scene]];
	//切换游戏场景 此处逻辑不好 以后游戏运行后在做修改
    // CCLOG(@"发送请求完成");
}


- (void)ButtonGo:(CCMenuItemFont*)itemPassedIn
{
    //准备登陆游戏中心服务器，发送登陆游戏中心服务器请求
    //根据不同按钮点击进入不同番管
    //点击快速配桌时出发次按钮
    int ret = [[GameManager sharedGameManager] OnSocketServerLogon];
    if (ret == false)
    {
        CCLOG(@"登陆游戏服务器失败");
        
    }
    
}


- (void)KuaiPei:(CCMenuItemFont*)itemPassedIn
{
    
    
//    enum TABLE_OPTION
//    {
//        TABLE_OPTION_SCENE = 0,		//场景
//        TABLE_OPTION_GOLD,			//底和台
//        TABLE_OPTION_QUAN,			//几圈结束
//        TABLE_OPTION_SPEED,			//出手速度
//        TABLE_OPTION_RULE,			//规则，常规或见字见花
//        TABLE_OPTION_ALLFRIEND,		//所有人都是好友
//        TABLE_OPTION_FANS,          //起胡番数
//        TABLE_OPTION_FIXED,			//是否定额
//        TABLE_OPTION_PARAM,         //备用
//        TABLE_OPTION_TEN,			//备用
//        TABLE_OPTION_MAX,			//总数，共8个
//    };
//[0, 1, 0, 3, 0, 0, 1
    
//    bool							bNewTable;									//是否开新局
//	bool							bSelectTable;								//是否指定桌子编号
//	bool							bOnlyFriends;								//是否亲友团
//	BYTE                            cbSitDown;                                   //是否坐下 1--坐下/0--旁观
//	WORD							wTableID;									//桌子ID
//	BYTE							cbParam[TABLE_OPTION_MAX];	
    
    
    //快速配桌按钮出发此方法  快速配桌目前不知道如何触发  因为排行榜和成就不确定是在哪个服务器返回 
    CMD_GR_UserSitSearchReq logon;
	memset(&logon, 0, sizeof(CMD_GR_UserSitSearchReq));
	logon.bNewTable = NO;
    logon.bSelectTable = NO;
    logon.bOnlyFriends = NO;
    logon.cbSitDown = YES;
    logon.wTableID = 0;
    logon.cbParam[0] = 0;
    logon.cbParam[1] = 2;
    logon.cbParam[2] = 0;
    logon.cbParam[3] = 3;
//    BYTE str[TABLE_OPTION_MAX] = "020000000";
//    memcpy(logon.cbParam, str , TABLE_OPTION_MAX);
     
   
    CCLOG(@"配置参数：a%d  b%d  c%d ",logon.cbParam[0], logon.cbParam[2],logon.cbParam[8] );
    CCLOG(@"快速配桌");
    //CCLOG(@"TABLEID:%d", logon.wTableID);
    [[GameManager sharedGameManager] SendData:MDM_GR_USER SubCmd:SUB_GR_USER_SIT_SEARCH_REQ  arg:&logon len:sizeof(CMD_GR_UserSitSearchReq)];
    
    
}

- (void)dealloc
{
    
    
    
    [super dealloc];
}



@end

//
//  GameManager.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年7月27日.
//  Copyright (c) 2012年 Yuan. All rights reserved.
//
//yuan
#import <Foundation/Foundation.h>
#import "AppDelegate.h"
#import "cocos2d.h"
#import "sys/socket.h"
#import "netinet/in.h"
#import "arpa/inet.h"
#import "GameConfig.h"
#import "pthread.h"
#import "RootViewController.h"
#import "SocketDef.h"
#import "Cmd.h"
#import "Encrypt.h"
#import "SocketHelper.h"
#import "stdio.h"
#import "string.h"
#import "stdlib.h"
#import "AllPlayInfo.h"


#define GAMECENTERDEBUG 0
#define GAMEDEBUG       1

//给游戏里面的通知例如服务器下发吃牌则告诉游戏里做出相应动作
@protocol MyProtocol <NSObject>


//游戏开始通知
- (void)GameStart:(WORD)SubCmd arg:(char*) pData len: (WORD)wDataSize;

//发送牌
- (void)GameSendCard:(WORD)SubCmd arg:(char*) pData len: (WORD)wDataSize;
@end



@interface GameManager : NSObject

{
# pragma 网络、多线程相关
    
    int fd;                                                             //网络套接字接口-大厅服务器
    int GameFd;                                                         //判断目前TCP是中心服务器还是游戏服务器
    
    pthread_t pthread;                                                  //线程
    
    WORD							m_wRecvSize;						//接收长度
	BYTE							m_cbRecvBuf[SOCKET_BUFFER*10];		//接收缓冲    

# pragma 玩家基础信息
    CMD_GP_LogonSuccess  UserData;        //用户基本数据
    tagGlobalUserData    GameCenterData;  //用户登陆游戏中心服务器信息
    CMD_GR_LogonSuccess  UserID;           //用户ID
    tagUserInfoHead      UserComeInfo;   //自己的详细信息
    
# pragma 不知道是否有用信息 可裁剪
    CMD_GR_GameSet      GameSet;

#pragma 快速配桌桌子信息 包括桌主信息 桌子号等等
    CMD_GR_NewTable TableInfo;

# pragma 跟你在一个大厅的所有玩家信息保存处 看是否需要删除此玩家信息如果这个玩家退出房间了 
    NSMutableArray *AllPlayerInfo;
    
# pragma 四个玩家ID和TableID 对应椅子号等等 椅子号0-3
    playGameIng       playGameing; //真正的游戏对应编号
    CMD_GR_SwitchChair PlayerChairInfo; //交换座位时的临时编号  最终转换成play4Gameing
    
    
    
# pragma protocol游戏中
    id <MyProtocol> delegate;
    
# pragma UI    
    RootViewController* viewController;
}

//test 多线程环境中到底要不要nonatomic 还是原子操作？
@property (nonatomic, assign) int fd;
@property (nonatomic, assign) int GameFd;
@property (nonatomic, retain) RootViewController     *viewController;
@property (nonatomic, assign) CMD_GP_LogonSuccess  UserData;
@property (nonatomic, assign) tagGlobalUserData    GameCenterData;
@property (nonatomic, assign) CMD_GR_LogonSuccess  UserID;
@property (nonatomic, assign) tagUserInfoHead      UserComeInfo;
@property (nonatomic, assign) CMD_GR_SwitchChair PlayerChairInfo; 
@property (nonatomic, assign) CMD_GR_GameSet      GameSet;
@property (nonatomic, assign) CMD_GR_NewTable TableInfo;
@property (nonatomic, retain) NSMutableArray *AllPlayerInfo;
@property (nonatomic, assign) playGameIng       playGameing;

//游戏代理
@property (nonatomic, assign) id <MyProtocol> delegate;



//单例模式
+(GameManager*)sharedGameManager;


//初始化全局变量
- (void) initSocketData;
- (void) CloseSocket;

//加密
- (WORD) SeedRandMap:(WORD) wSeed;
- (BYTE) MapSendByte:(BYTE const) cbData;
- (BYTE) MapRecvByte:(BYTE const)cbData;
- (WORD) EncryptBuffer:(BYTE *)cbDataBuffer datasize:(WORD)wDataSize buffersize:(WORD)wBufferSize;
- (WORD) CrevasseBuffer: (BYTE *)cbDataBuffer datasize:(WORD)wDataSize;

//初始化socket套接字并发送链接服务器请求
-(int)  initSocket;
-(BOOL) OnSocketServerLogon;



//发送消息
-(BOOL)  sendData:(BYTE)MainCmd sum:(BYTE)Subcmd;
-(DWORD) SendData: (WORD)wMainCmdID SubCmd: (WORD)wSubCmdID arg:(void*) pData len: (WORD) wDataSize;
-(DWORD) SendDataBuffer:(void*)pBuffer len:(WORD)wSendSize;



//接收消息处理方法
- (BOOL) OnSocketNotifyRead: (void*)shadow;
- (BOOL) OnEventTCPSocketReadGuangChang:(void*) shadoww command:(CMD_Command) Command data:(void *) pData len:(WORD) wDataSize;
- (BOOL) OnEventTCPSocketReadGameCenter:(void*) shadoww command:(CMD_Command) Command data:(void *) pData len:(WORD) wDataSize;

//处理登陆消息
- (BOOL) OnSocketMainLogonGuangChang:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;
- (BOOL) OnSocketMainLogonGameCenter:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;

//处理用户信息
- (BOOL) OnSocketUserInfo:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;

//处理桌子信息
- (BOOL) OnSocketTableStatus:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;


//解析配置信息
- (BOOL) OnSocketUserConfig:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;

//处理接收的游戏服务器信息
- (BOOL) ONSocketServerList:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;

//解析桌子框架消息
- (BOOL) OnSocketUserFrame:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;

//游戏中心消息

- (BOOL) OnSocketGameCenter:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize;


//网络转码
- (char*)    GB2UTF_8:(char *)p_srcStr;
- (NSString*)UTF8_To_GB2312:(NSString*)utf8string;
- (NSString*)GB2312_To_UTF8:(NSString*)utf8string;


//测试部分
-(BOOL) testForLogon;


@end




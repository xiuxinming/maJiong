//
//  GameManager.m
//  HappyMahjong
//
//  Created by Gao Yuan on 12年7月27日.

//  Copyright (c) 2012年 Yuan. All rights reserved.
//yuan


#import "GameManager.h"


//全局变量定义处
const DWORD g_dwPacketKey=0x74D02840;
BYTE m_cbRecvRound = 0;
BYTE m_cbSendRound = 0;
DWORD m_dwSendPacketCount = 0;
DWORD m_dwRecvPacketCount = 0;
DWORD m_dwSendXorKey=0x12345678;
DWORD m_dwRecvXorKey=0x12345678;

//服务器信息
tagGameServer        GameServer[Majong4Number];


# pragma 信号处理

void handle_pipe(int sig)
{
    //不做任何处理即可
    CCLOG(@"收到系统的SIGPIPE信号");
}



# pragma 线程处理

//线程处理方法
void *thread_handler(void *arg)
{
    CCLOG(@"thread_handler:began pthread");
    
    GameManager *shadow = (GameManager *)arg;
        
    struct sockaddr_in serAddr;
    socklen_t addrlen;
    int ret, errCode;
    memset(&serAddr, 0, sizeof(struct sockaddr_in));
   
    
    //初始化serverend
    serAddr.sin_family = AF_INET;
    serAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &serAddr.sin_addr);
    
    addrlen = sizeof(serAddr);
    
    //建立socket套接字
    shadow.fd = socket(AF_INET, SOCK_STREAM, 0);
    if (shadow.fd == -1)
    {
        CCLOG(@"initSocket: socket create failed");
        pthread_exit(NULL);
    }
    
    //test
    CCLOG(@"fd old:%d", shadow.fd);
    CCLOG(@"old port:%d", SERVER_PORT);

    //设置可重用属性 根据具体情况添加删除可配置属性
#if YES
    int resume = 1;
    if((ret = setsockopt(shadow.fd, SOL_SOCKET,SO_REUSEADDR,(char *)&resume,sizeof(resume))) < 0)
    {
        CCLOG(@"initSocket: sys_setsockopt setsockopt SO_REUSEADDR error(%d).\n", ret);
       pthread_exit(NULL);
    }
#endif
    
    
    //请求链接 可更改默认设置为可以链接3次 每次3秒钟 链接上就跳出循环
    for (int i = 0; i < 3; i++)
    {
        ret = connect(shadow.fd, (struct sockaddr *)&serAddr, addrlen);
        if (ret == OK)
        {
            CCLOG(@"链接成功");
            break;
        }
        
      //  sleep(1);
    }
    
    if (ret == ERROR)
    {
        CCLOG(@"initsocket:connect error");
        pthread_exit(NULL);
    }
    
    //目前是中心服务器
    shadow.GameFd = SOCKET_GUANGCHANG;
    
    //总结 OC与C混编  OC可以调用OC方法认为是在类里，调用C方法时不可以传任何类里面参数，C调用C方法可以一个独立的C方法被认为是整个进程都在也就是说都可以调用,C++同OC
    
    
    //设置sigpipe信号 防止客户端因为服务器断开链接而退出进程
    struct sigaction action;
    action.sa_handler = handle_pipe;
    sigemptyset(&action.sa_mask);
    action.sa_flags = 0;
    sigaction(SIGPIPE, &action, NULL);
      
    
    while (1) 
    {
        //处理接收数据
        [shadow OnSocketNotifyRead:shadow];
    }
    
}


@implementation GameManager

//静态全局变量
static	GameManager* _sharedGameManager = nil;


@synthesize fd;
@synthesize GameFd;
@synthesize viewController;
@synthesize delegate;
@synthesize UserData;
@synthesize GameCenterData;
@synthesize UserID;
@synthesize UserComeInfo;
@synthesize GameSet;
@synthesize PlayerChairInfo;
@synthesize TableInfo;
@synthesize AllPlayerInfo;
@synthesize playGameing;

#pragma 加密解密

//随机映射
- (WORD) SeedRandMap:(WORD) wSeed
{
	//CCLOG(@"1111111111");
    DWORD dwHold=wSeed;
	return (WORD)((dwHold=dwHold*241103L+2533101L)>>16);
    
}

//映射发送数据
-(BYTE) MapSendByte:(BYTE const) cbData
{
   // CCLOG(@"222222222");
    
    BYTE cbMap=g_SendByteMap[(BYTE)(cbData+m_cbSendRound)];
	m_cbSendRound+=3;
	return cbMap;
}

//映射接收数据
-(BYTE) MapRecvByte:(BYTE const)cbData
{
    
    BYTE cbMap=g_RecvByteMap[cbData]-m_cbRecvRound;
	m_cbRecvRound+=3;
	return cbMap;
}


//加密数据                //包头内容        //数据总大小包括包头    //第一个参数缓冲区大小
- (WORD)EncryptBuffer:(BYTE *)cbDataBuffer datasize:(WORD)wDataSize buffersize:(WORD)wBufferSize
{
	WORD i = 0;
    
    //效验参数
	assert(wDataSize>=sizeof(CMD_Head));
	assert(wBufferSize>=(wDataSize+2*sizeof(DWORD)));
	assert(wDataSize<=(sizeof(CMD_Head)+SOCKET_PACKET));
    
    //    wDataSize:84   buffersize:8184
   //  CCLOG(@"wDataSize:%d   buffersize:%d", wDataSize, wBufferSize);
        
    //调整长度
	WORD wEncryptSize=wDataSize-sizeof(CMD_Command),wSnapCount=0;
	if ((wEncryptSize%sizeof(DWORD))!=0)
	{
		wSnapCount=sizeof(DWORD)-wEncryptSize%sizeof(DWORD);
		memset(cbDataBuffer+sizeof(CMD_Info)+wEncryptSize,0, wSnapCount);
	}
    
    
    //映射字节
	BYTE cbCheckCode=0;
	for (WORD i=sizeof(CMD_Info);i<wDataSize;i++)
	{
		cbCheckCode+=cbDataBuffer[i];
        cbDataBuffer[i]= [self MapSendByte:cbDataBuffer[i]];
	}
    
    
    //填写信息头
	CMD_Head * pHead=(CMD_Head *)cbDataBuffer;
	pHead->CmdInfo.cbVersion=SOCKET_VER;
	pHead->CmdInfo.wPacketSize=wDataSize;
	pHead->CmdInfo.cbCheckCode=~cbCheckCode+1;
    
    
    //创建密钥
	DWORD dwXorKey=m_dwSendXorKey;
	if (m_dwSendPacketCount==0)
	{
		//随机种子
//		GUID Guid;
//		CoCreateGuid(&Guid);
//		dwXorKey=GetTickCount();
//		dwXorKey^=Guid.Data1;
//		dwXorKey^=Guid.Data2;
//		dwXorKey^=Guid.Data3;
//		dwXorKey^=*((DWORD *)Guid.Data4);
//       (int)random()% 480
        
//		//映射种子
        dwXorKey = (arc4random() % 65534) + 1; 
        
		dwXorKey=[self SeedRandMap:(WORD)dwXorKey];
		dwXorKey|=((DWORD)[self SeedRandMap:(WORD)dwXorKey ]>>16)<<16;
		dwXorKey^=g_dwPacketKey;
		m_dwSendXorKey=dwXorKey;
		m_dwRecvXorKey=dwXorKey;
        
            
	}
    
    
    
    //加密数据/Users/qboyuc
	WORD * pwSeed=(WORD *)(cbDataBuffer+sizeof(CMD_Info));
	DWORD * pdwXor=(DWORD *)(cbDataBuffer+sizeof(CMD_Info));
	WORD wEncrypCount=(wEncryptSize+wSnapCount)/sizeof(DWORD);
	
	for (WORD i = 0;i<wEncrypCount;i++)
	{
		*pdwXor++^=dwXorKey;
		dwXorKey=[self SeedRandMap:*pwSeed++];
		dwXorKey|=((DWORD)[self SeedRandMap:*pwSeed++])<<16; 
		dwXorKey^=g_dwPacketKey;

	}
    
    
    //插入密钥
	if (m_dwSendPacketCount==0)
	{
		memmove(cbDataBuffer+sizeof(CMD_Head)+sizeof(DWORD),cbDataBuffer+sizeof(CMD_Head),wDataSize);
		*((DWORD *)(cbDataBuffer+sizeof(CMD_Head)))=m_dwSendXorKey;
		pHead->CmdInfo.wPacketSize+=sizeof(DWORD);
		wDataSize+=sizeof(DWORD);
	}
    
	//设置变量
	m_dwSendPacketCount++;
	m_dwSendXorKey=dwXorKey;
    
//    cbCheckCode:41  wDataSize:84 
  //  CCLOG(@"cbCheckCode:%d  wDataSize:%d ",pHead->CmdInfo.cbCheckCode, wDataSize );
	return wDataSize;
}

//解密数据            //包头信息            //数据总大小包括包头
- (WORD)CrevasseBuffer: (BYTE *)cbDataBuffer datasize:(WORD)wDataSize
{
	//效验参数
	assert(m_dwSendPacketCount>0);
	assert(wDataSize>=sizeof(CMD_Head));
	assert(((CMD_Head *)cbDataBuffer)->CmdInfo.wPacketSize==wDataSize);
    
	//调整长度
	WORD wSnapCount=0;
	if ((wDataSize%sizeof(DWORD))!=0)
	{
		wSnapCount=sizeof(DWORD)-wDataSize%sizeof(DWORD);
		memset(cbDataBuffer+wDataSize,0,wSnapCount);
	}
    
	//解密数据
	DWORD dwXorKey=m_dwRecvXorKey;
	DWORD * pdwXor=(DWORD *)(cbDataBuffer+sizeof(CMD_Info));
	WORD  * pwSeed=(WORD *)(cbDataBuffer+sizeof(CMD_Info));
	WORD wEncrypCount=(wDataSize+wSnapCount-sizeof(CMD_Info))/4;
	for (WORD i=0;i<wEncrypCount;i++)
	{
		if ((i==(wEncrypCount-1))&&(wSnapCount>0))
		{
			BYTE * pcbKey=((BYTE *)&m_dwRecvXorKey)+sizeof(DWORD)-wSnapCount;
			memcpy(cbDataBuffer+wDataSize,pcbKey,wSnapCount);
		}
		dwXorKey=[self SeedRandMap:*pwSeed++];
		dwXorKey|=((DWORD)[self SeedRandMap:*pwSeed++])<<16;
		dwXorKey^=g_dwPacketKey;
		*pdwXor++^=m_dwRecvXorKey;
		m_dwRecvXorKey=dwXorKey;
	}
    
	//效验字节
	CMD_Head * pHead=(CMD_Head *)cbDataBuffer;
	BYTE cbCheckCode=pHead->CmdInfo.cbCheckCode;
	for (int i=sizeof(CMD_Info);i<wDataSize;i++)
	{
		cbDataBuffer[i]=[self MapRecvByte:cbDataBuffer[i]];
		cbCheckCode+=cbDataBuffer[i];
	}
    
	//关闭连接
	if (cbCheckCode!=0)
	{
		CCLOG(@"cbCheckCode!=0解密出现问题");
       // assert(FALSE);
		return 0;
	}
    
	return wDataSize;
}

//end加密解密




# pragma 网络处理部分 

//建立线程 初始化socket
- (int) initSocket
{
        
    
    
    //设置线程属性
    int errCode = 0;
    pthread_attr_t tAttr;
    pthread_attr_init(&tAttr);
    errCode = pthread_attr_setdetachstate(&tAttr, PTHREAD_CREATE_DETACHED);
    if (errCode !=0 ) 
    {
        
        CCLOG(@"initSocket:pthread_attr_setdetachstate");
        pthread_attr_destroy(&tAttr);
        //以后再看是否要做处理
        
    }
    
    //创建线程 参数为self
    pthread_create(&pthread, &tAttr, thread_handler, self);
    
    
    
    return OK;
    
}   


#pragma 网络之发送部分

//真正的发送数据报文
-(DWORD) SendDataBuffer:(void*)pBuffer len:(WORD)wSendSize
{
	//变量定义
	WORD wTotalCount=0;
    int sd = self.fd;
    
    
	//发送数据
	while (wTotalCount<wSendSize)
	{
		//发送数据
		int  nSendCount=send(sd ,(char *)pBuffer+wTotalCount,wSendSize-wTotalCount,0);
        
		//错误判断
		if ( nSendCount == ERROR )
		{
			//关闭连接处理错误
            CCLOG(@"发送失败");
			return 0L;
		}
		else
		{
			//设置变量
			wTotalCount+=nSendCount;
		}
	}
    
    
	return wSendSize;
}


//发送函数 封装报文和加密处理
-(DWORD) SendData: (WORD)wMainCmdID SubCmd: (WORD)wSubCmdID arg:(void*) pData len: (WORD) wDataSize
{
    
	//效验大小
	assert(wDataSize<=SOCKET_PACKET);
	if (wDataSize>SOCKET_PACKET) 
        return false;
    
	//变量定义
	BYTE cbDataBuffer[SOCKET_BUFFER];
	CMD_Head * pHead=(CMD_Head *)cbDataBuffer;
    
	//设置变量
	pHead->CommandInfo.wMainCmdID=wMainCmdID;
	pHead->CommandInfo.wSubCmdID=wSubCmdID;
    
	//扩展数据
	if (wDataSize>0)
	{
		assert(pData!=NULL);
		memcpy(pHead+1,pData,wDataSize);
	}
    
	//加密数据
    WORD wSendSize = [[GameManager sharedGameManager] EncryptBuffer:cbDataBuffer datasize:sizeof(CMD_Head)+wDataSize buffersize:sizeof(cbDataBuffer)];
    
	
    //发送数据
    return [[GameManager sharedGameManager] SendDataBuffer:cbDataBuffer len:wSendSize];
    
}



//发送内核命令
-(BOOL) sendData:(BYTE)MainCmd sum:(BYTE)Subcmd
{
    
	//变量定义
	BYTE cbDataBuffer[SOCKET_BUFFER];
	CMD_Head * pHead=(CMD_Head *)cbDataBuffer;
    
	//设置变量
	pHead->CommandInfo.wSubCmdID=Subcmd;
	pHead->CommandInfo.wMainCmdID=MainCmd;
    
	//加密数据
    WORD wSendSize = [[GameManager sharedGameManager] EncryptBuffer:cbDataBuffer datasize:sizeof(CMD_Head) buffersize:sizeof(cbDataBuffer)];
    
    
	//发送数据
    [[GameManager sharedGameManager] SendDataBuffer:cbDataBuffer len:wSendSize];
    
    return true;
}


#pragma 重新初始化全局变量

- (void) CloseSocket
{
    close(self.fd);
    fd = 0;
    [self initSocketData];
}


- (void) initSocketData
{
     m_cbRecvRound = 0;
     m_cbSendRound = 0;
     m_dwSendPacketCount = 0;
     m_dwRecvPacketCount = 0;
     m_dwSendXorKey=0x12345678;
     m_dwRecvXorKey=0x12345678;
    
     m_wRecvSize=0;
	
}



#pragma 网络线程中之接收解析数据部分


- (BOOL)OnSocketServerLogon
{
    struct sockaddr_in serAddr;
    socklen_t addrlen;
    int ret;
    memset(&serAddr, 0, sizeof(struct sockaddr_in));
    
    
    //断开中心服务器的FD
    [self CloseSocket];
    
   
    
    //初始化serverend
    serAddr.sin_family = AF_INET;
    serAddr.sin_port = htons(GameServer[Majong4PuTong].wServerPort);
    serAddr.sin_addr.s_addr = GameServer[Majong4PuTong].dwServerAddr;
    
    
#if 1
    char str[16];
    CCLOG(@"new port:%d  ip:%s", GameServer[Majong4PuTong].wServerPort, inet_ntop(AF_INET, &GameServer[Majong4PuTong].dwServerAddr, str, INET_ADDRSTRLEN));
   
    if (strcmp(str , "0.0.0.0") == 0)
    {
        CCLOG(@"获取游戏服务器资源失败");
        serAddr.sin_port = htons(32810);
        inet_pton(AF_INET, "61.147.105.59", &serAddr.sin_addr);
    }
    //inet_ntop(AF_INET, &GameServer.dwServerAddr2, str2, INET_ADDRSTRLEN);
    //inet_pton(AF_INET, SERVER_IP, &serAddr.sin_addr);
    CCLOG(@"new port:%d  ip:%s", ntohs(serAddr.sin_port), inet_ntop(AF_INET, &GameServer[Majong4PuTong].dwServerAddr, str, INET_ADDRSTRLEN));

#endif
    
    addrlen = sizeof(serAddr);
    
    //建立socket套接字
    self.fd = socket(AF_INET, SOCK_STREAM, 0);
    if (self.fd == -1)
    {
        CCLOG(@"initSocket: socket create failed");
        return false;
    }
    
    //test
    CCLOG(@"fd new:%d", self.fd);
   

    
    //设置可重用属性 根据具体情况添加删除可配置属性
#if YES
    int resume = 1;
    if((ret = setsockopt(self.fd, SOL_SOCKET,SO_REUSEADDR,(char *)&resume,sizeof(resume))) < 0)
    {
        CCLOG(@"initSocket: sys_setsockopt setsockopt SO_REUSEADDR error(%d).\n", ret);
        return false;
    }
#endif
    
    
    //请求链接 可更改默认设置为可以链接3次 每次3秒钟 链接上就跳出循环
    for (int i = 0; i < 3; i++)
    {
        ret = connect(self.fd, (struct sockaddr *)&serAddr, addrlen);
        if (ret == OK)
        {
            CCLOG(@"链接成功");
            break;
        }
        
        //  sleep(1);
    }
    
    if (ret == ERROR)
    {
        CCLOG(@"initsocket:connect error");
        return false;
    }
    
    
    //目前是游戏服务器
    self.GameFd = SOCKET_GAMECENTER;

    
    CMD_GR_LogonByUserID userID;
    memset(&userID, 0, sizeof(CMD_GR_LogonByUserID));
    userID.dwPlazaVersion = CLIENT_VER;
    userID.dwProcessVersion = PROCESS_VER;//100
    userID.bIsFan = NO;
    userID.cbClientType = CLIENT_TYPE;//3
    userID.dwUserID = UserData.dwUserID;
    memcpy(userID.szPassWord, GameCenterData.szPassWord, PASS_LEN);
    
    //96e79218965eb72c92a549dd5a330112   1131   
    CCLOG(@"  id:%d  pass:%s len:%d",userID.dwUserID ,userID.szPassWord, sizeof(CMD_GR_LogonByUserID));
    
    
//    [self initSocketData];
    
    //发送登陆游戏中心服务器请求
    [[GameManager sharedGameManager] SendData:MDM_GR_LOGON SubCmd:SUB_GR_LOGON_USERID  arg:&userID len:sizeof(CMD_GR_LogonByUserID)];
    
    //CCLOG(@"发送游戏中心服务器请求");
    
    
    return true;
    

}


//处理用户信息  游戏中心协议
- (BOOL) OnSocketUserInfo:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GR_USER_COME:		//用户进入
		{
			CCLOG(@"用户进入房间");
            
            //效验参数
			assert(wDataSize>=sizeof(tagUserInfoHead));
			if (wDataSize<sizeof(tagUserInfoHead)) 
                return false;
            
			//保存信息
			
			tagUserInfoHead * pLogonSuccess=(tagUserInfoHead *)pData;
            
            //保存自己的信息
            if (UserID.dwUserID == pLogonSuccess->dwUserID)
            {
                memcpy(&UserComeInfo, pLogonSuccess, sizeof(tagUserInfoHead));
            }

            
            //保存所有大厅用户信息 321
            AllPlayInfo *Information = [[[AllPlayInfo alloc] init] autorelease];
            Information.dwUserID = pLogonSuccess->dwUserID;
            Information.lLoveliness = pLogonSuccess->lLoveliness;
            Information.cbGender = pLogonSuccess->cbGender;
            Information.wTableID = pLogonSuccess->wTableID;
            Information.wChairID = pLogonSuccess->wChairID;
            Information.cbUserType = pLogonSuccess->cbUserType;
            Information.cbUserStatus = pLogonSuccess->cbUserStatus;
            Information.dwTitleID = pLogonSuccess->dwTitleID;
            
            
            
			//扩展信息
			void * pDataBuffer=NULL;
			tagDataDescribe DataDescribe;
			CRecvPacketHelper RecvPacket(pLogonSuccess+1,wDataSize-sizeof(tagUserInfoHead));
			while (true)
			{
				pDataBuffer=RecvPacket.GetData(DataDescribe);
				if (DataDescribe.wDataDescribe==DTP_NULL) 
                    break;
                
                //CCLOG(@"DataDescribe.wDataDescribe:%d", DataDescribe.wDataDescribe);
                
				switch (DataDescribe.wDataDescribe)
				{
                    case DTP_USER_ACCOUNTS:		//用户帐户
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szAccounts));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szAccounts))
						{
							memcpy(GameCenterData.szAccounts,pDataBuffer,DataDescribe.wDataSize);
                            //CCLOG(@"1 ID:%s", GameCenterData.szAccounts);
							GameCenterData.szAccounts[DataDescribe.wDataSize-1]=0;
                            //CCLOG(@"2 ID:%s", GameCenterData.szAccounts);
                            
                            if (GAMEDEBUG)//321
                            {
                 
                                NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                                    Information.PlayerAccount = [[NSString alloc] initWithBytes:GameCenterData.szAccounts length:32 encoding:encoding];
                              //      CCLOG(@"zhanghao:%@",  Information.PlayerAccount);
                                
                                     
                            }

						}
						break;
					}
                    case DTP_USER_NICK:			//用户昵称
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szNickName));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szNickName))
						{
							memcpy(GameCenterData.szNickName,pDataBuffer,DataDescribe.wDataSize);
                            // CCLOG(@"1 pass:%s", GameCenterData.szPassWord);
							GameCenterData.szNickName[DataDescribe.wDataSize-1]=0;
                           // CCLOG(@"2 nick:%s", GameCenterData.szNickName);
                            
                            if (GAMEDEBUG)
                            {   
                                //321
                                NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
                                Information.PlayerNickName = [[NSString alloc] initWithBytes:GameCenterData.szNickName length:33 encoding:encoding];
                               // CCLOG(@"nick:%@", Information.PlayerNickName);
                            }

						}
						break;
					}
                        
                    default: 
                    { break; }
				}
                
                                
			}
            
            //添加玩家信息
            [AllPlayInfo addPlayer:Information];
            
            if (!GAMEDEBUG)
            {
                CCLOG(@"totol大厅玩家数目:%d",[AllPlayerInfo count] );
                for (int i = 0; i < [AllPlayerInfo count]; i++)
                {
                    AllPlayInfo *player = [AllPlayerInfo objectAtIndex:i];
                    
                    CCLOG(@"新玩家进入大厅");
                    CCLOG(@"UserID:%d", player.dwUserID);
                    CCLOG(@"wTableID:%d", player.wTableID);
                    CCLOG(@"wchairID:%d", player.wChairID);
                    CCLOG(@"userStatus:%d", player.cbUserStatus);
                    CCLOG(@"nick:%@", player.PlayerAccount);
                    CCLOG(@"account:%@", player.PlayerNickName);
                }
            }

            
			//设置提示
			return true;
		}
        case SUB_GR_USER_STATUS:		
            //用户状态 如果有人和你坐在一桌上了，服务器下发SUB_GR_USER_STATUS，如果这个人的详细信息你本地没有，那么就要请求SUB_GR_USER_INFO来获取详细信息
		{
			CCLOG(@"用户坐在跟你一个的桌子上");
            
            //效验参数  
            assert(wDataSize>=sizeof(CMD_GR_UserStatus));
            if (wDataSize<sizeof(CMD_GR_UserStatus)) 
                return false;
            
            
            int count = wDataSize/sizeof(CMD_GR_UserStatus);
            //CCLOG(@"count === %d", count);
            
            assert( 0 == (wDataSize%sizeof(CMD_GR_UserStatus)) );

            for (int i = 0; i < count; i++) 
            {
                //保存信息
                CMD_GR_UserStatus * pLogonSuccess=(CMD_GR_UserStatus *)( (char*)pData + (i * sizeof(CMD_GR_UserStatus)) );
                
                if (GAMEDEBUG)
                {
                    //      数据库ID：1131  桌子位置:0   椅子位置：0   用户状态:2
                    CCLOG(@"数据库ID：%d  桌子位置:%d   椅子位置：%d   用户状态:%d",
                          pLogonSuccess->dwUserID, pLogonSuccess->wTableID, pLogonSuccess->wChairID,
                          (WORD)pLogonSuccess->cbUserStatus);
                }
                
                //更新用户桌子 椅子等信息
                [AllPlayInfo updataPlayerInfo:pLogonSuccess];
                
                
                //保存包括自己在内的4个玩家的桌椅ID等信息
                int myself = (DWORD)[AllPlayInfo findByUserID:UserID.dwUserID];
                
                AllPlayInfo *mySelf = [AllPlayerInfo objectAtIndex:myself];
                
                //加入是我自己或者跟我一个桌子并且游戏状态是准备玩的状态则是我的牌友 记录下来
                if ( (pLogonSuccess->wTableID == mySelf.wTableID) && (pLogonSuccess->cbUserStatus == US_PLAY) )
                {
                    for (int i = 0; i < GAME_PLAYER; i++)
                    {
                        if (playGameing.dwUserID[i] == 0)
                        {
                            playGameing.dwUserID[i] = pLogonSuccess->dwUserID;
                            playGameing.wChairID[i] = pLogonSuccess->wChairID;
                            break;
                        }
                        
                    }
                }
                
                
                
                //如果本地没有这个人的信息并且这个人还跟你一个桌子上就要发送SUB_GR_USER_INFO获取玩家详细信息
                //桌号和自己的桌号一样
                
                //作用1：获得自己所在桌子的信息并保存
                //作用2：如果收到的自己的用户ID表示自己配桌完成 则发送桌子信息给服务器表示自己准备好了 如果不加这条命令则游戏无法开始
                if ( pLogonSuccess->dwUserID == UserID.dwUserID )
                {
                    
                    CMD_GF_Info gfInfo;
                    memset(&gfInfo, 0, sizeof(CMD_GF_Info));
                    gfInfo.bAllowLookon = 0;
                    
                    [self SendData:MDM_GF_FRAME SubCmd:SUB_GF_INFO arg:&gfInfo len:sizeof(CMD_GF_Info)];
                }
                
                if (!GAMEDEBUG)
                {
                    for (int i = 0; i < GAME_PLAYER; i++)
                    {
                        CCLOG(@"old userID:%d   chairID:%d", playGameing.dwUserID[i], playGameing.wChairID[i]);
                    }
                }
                
                
               
            }

			return true;
		}
        
        case SUB_GR_SIT_FAILED:
        {   
           
            //assert(wDataSize>=sizeof(CMD_GR_SitFailed));
            //if (wDataSize<sizeof(CMD_GR_SitFailed)) 
            //  return false;
            
            CMD_GR_SitFailed *error = (CMD_GR_SitFailed*)pData;
            
            CCLOG(@"错误编号 %d  len:%d sizeof:%d  aaa%s", error->wError, strlen(error->szFailedDescribe),
                  sizeof(CMD_GR_SitFailed),error->szFailedDescribe);
            CCLOG(@"配桌失败");
            if (GAMEDEBUG)
            {
               // NSData *data = [NSData dataWithBytes:error->szFailedDescribe length:strlen(error->szFailedDescribe)];
                NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
               // NSString *retStr = [[NSString alloc] initWithData:data encoding:encoding];
                NSString *retStr = [[NSString alloc] initWithBytes:error->szFailedDescribe length:256 encoding:encoding];
                CCLOG(@"retStr:%@", retStr);
            }
            
            return true;
        }
        
        case SUB_GR_SWITCH_CHAIR:		//交换座位 记录下4个玩家的ID和椅子编号0-3  谁换到哪个椅子上去了 所以真正的椅子号要在这里确定
		{   
            assert(wDataSize>=sizeof(CMD_GR_SwitchChair));
            if (wDataSize<sizeof(CMD_GR_SwitchChair)) 
                return false;
            
            CMD_GR_SwitchChair *switchChair = (CMD_GR_SwitchChair*)pData;
            
            memset(&PlayerChairInfo, 0, sizeof(PlayerChairInfo));
            memcpy(&PlayerChairInfo, switchChair, sizeof(PlayerChairInfo));
            
            if (GAMEDEBUG)
            {
                
                for (int i = 0; i < GAME_PLAYER; i++)
                {
                    CCLOG(@"old userID:%d   wchairID:%hd", PlayerChairInfo.dwUserID[i], PlayerChairInfo.wChairID[i]);
                }
                //CCLOG(@"sizeof:%d",sizeof(CMD_GR_SwitchChair));
                CCLOG(@"交换座位");
                
            }
            
            //真正保存4位游戏玩家的ID和椅子号的地方 play4Gameing永远是最新的ID和椅子对应之处
            for (int i = 0; i < GAME_PLAYER; i++)
            {
                for (int j = 0; j < GAME_PLAYER; j++)
                {
                    if (PlayerChairInfo.dwUserID[i] == playGameing.dwUserID[j])
                    {
                        playGameing.wChairID[j] = PlayerChairInfo.wChairID[i];
                    }
                }
            }
            
            if (GAMEDEBUG)
            {
                for (int i = 0; i < GAME_PLAYER; i++)
                {
                    CCLOG(@"new userID:%d   chairID:%d", playGameing.dwUserID[i], playGameing.wChairID[i]);
                }
            }

            
            
            //保存四个玩家座位信息和ID信息后发送 交互座位完成请求 由此将会收到SUB_S_GAME_START命令，然后进入到游戏场景中
            [self sendData:MDM_GF_GAME sum:SUB_C_SWITCH_END];
             
            
            return true;
		}
            
        case SUB_GR_USER_SCORE:		//用户分数
		{
                       
            return true;
		}
            
        case SUB_GR_USER_RIGHT:		//用户权限
		{
            
            return true;
		}
            
        case SUB_GR_MEMBER_ORDER:		//会员等级
		{
            
            return true;
		}
            
        case SUB_GR_USER_CHAT:		//聊天消息
		{
            
            return true;
		}
        
        case SUB_GR_USER_WISPER:		//私语信息
		{
            
            return true;
		}

        case SUB_GR_FRIENDLIST:		//好友列表
		{
            
            return true;
		}
            
        case SUB_GR_KEEP_LOGON_AWARD:		//联系登陆次数
		{
            
            return true;
		}
            
        case SUB_GR_USER_RESULT:		//好友操作结果
		{
            
            return true;
		}
        
        case SUB_GR_HONOR_NOTIFY:		//用户解开成就的提示
		{
            
            return true;
		}
            
        case SUB_GR_MODIFY_TITLE:		//用户修改了当前称号
		{
            
            return true;
		}
            
            
        case SUB_GR_UPDATE_BAG_NOTIFY:		//物品加入到背包
		{
            
            return true;
		}
        
        case SUB_GR_UPDATE_ITEMS:		//更新背包道具
		{
            
            return true;
		}
            
            
        case SUB_GR_HANDLE_ITEM_RESP:		//处理物品返回
		{
            
            return true;
		}
            
        case SUB_GR_BAG_LIST:		//返回背包物品列表
		{
            
            return true;
		}
            
        case SUB_GR_UPDATE_EQUIP:		//更新玩家装饰物数据
		{
            
            return true;
		}
            
        case SUB_GR_SHOP_ITEM_LIST:		//请求商店物品列表
		{
            
            return true;
		}
        
            
        case SUB_GR_BUY_ITEM_RESP:		//购买返回
		{
            
            return true;
		}
            
        case SUB_GR_TAKE_GOLD_NOTIFY:		//提示玩家可以领奖
		{
            
            return true;
		}
            
        case SUB_GR_TAKE_GOLD_RESP:		//玩家领奖返回
		{
            
            return true;
		}
        
        case SUB_GR_CAMPAIGN_NEW_LOGON_INFO:		//连续登录抽奖
		{
            
            return true;
		}
        
        case SUB_GR_EXCHANGE_GOLD_RESP:		//兑换金币返回
		{
            
            return true;
		}
            
        case SUB_GR_GAME_SET:		//游戏设置  以数组形似传过来的数据，编号固定  		
        {    //效验参数
            
			assert(wDataSize>=sizeof(CMD_GR_GameSet));
			if (wDataSize<sizeof(CMD_GR_GameSet)) 
                return false;
            
			//保存信息
			CMD_GR_GameSet * pLogonSuccess=(CMD_GR_GameSet *)pData;
			memcpy(&GameSet, pLogonSuccess, sizeof(CMD_GR_GameSet));
			
            
            //测试数据信息
            CCLOG(@"GameSet:%d  %d  %d  %d  %d",GameSet.nSetValue[0], GameSet.nSetValue[1],
                  GameSet.nSetValue[2],GameSet.nSetValue[3],GameSet.nSetValue[4]);
            return true;
		}
            
        case SUB_GR_ADDGOLD_INGAME:		//游戏里补充金币
		{
            
            return true;
		}
            
        case SUB_GR_RANK_LIST_RESP:		//排行榜返回
		{
            
            return true;
		}

        case SUB_GR_RANK_QUERY_RESP:		//排行榜查询返回
		{
            
            return true;
		}
            
        case SUB_GR_REMIT_RESULT:		//汇款返回
		{
            
            return true;
		}
            
        default:
            return true;
	}
    
	return true;
}

//游戏中心消息处理
- (BOOL) OnSocketGameCenter:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_S_GAME_START:		//开始游戏
		{
			//效验参数
            assert(wDataSize>=sizeof(CMD_S_GameStart));
            if (wDataSize<sizeof(CMD_S_GameStart)) 
                return false;
            assert( 0 == (wDataSize%sizeof(CMD_S_GameStart)));
            
            int count = wDataSize/sizeof(CMD_S_GameStart);
            
            if (GAMEDEBUG)
            {      
                      //count === 1
                CCLOG(@"count === %d", count);
                      //游戏开始 wdatasize:50   sizeof:50
                CCLOG(@"游戏开始 wdatasize:%d   sizeof:%d", wDataSize, sizeof(CMD_S_GameStart));
            }
            
            //保存信息  分配了内存 游戏场景中接收到第一件事就是free掉
			CMD_S_GameStart *pLogonSuccess=(CMD_S_GameStart *)pData;
			CMD_S_GameStart *GameStart = (CMD_S_GameStart*)malloc(sizeof(CMD_S_GameStart));
            memcpy(GameStart, pLogonSuccess, sizeof(CMD_S_GameStart));
            [self.delegate GameStart:SUB_S_GAME_START arg:(char*)GameStart len:sizeof(CMD_S_GameStart)];
            

            
            return true;
		}
            
        case SUB_S_OUT_CARD:		//出牌命令  同步出牌信息
		{
			//效验参数
            assert(wDataSize>=sizeof(CMD_S_OutCard));
            if (wDataSize<sizeof(CMD_S_OutCard)) 
                return false;
            assert( 0 == (wDataSize%sizeof(CMD_S_OutCard)));
            
            //保存信息  分配了内存 游戏场景中接收到第一件事就是free掉
			CMD_S_OutCard *pLogonSuccess=(CMD_S_OutCard *)pData;
			CMD_S_OutCard *GameOperate = (CMD_S_OutCard*)malloc(sizeof(CMD_S_OutCard));
            memcpy(GameOperate, pLogonSuccess, sizeof(CMD_S_OutCard));
            
            if (GAMEDEBUG)
            {
                CCLOG(@"同步出牌信息--出牌用户:%d  出牌扑克:%d",GameOperate->wOutCardUser, GameOperate->cbOutCardData);

            }
            
            
			return true;
		}
            
        case SUB_S_SEND_CARD:		//发送扑克 补花也是在这里
		{
            //效验参数
            assert(wDataSize>=sizeof(CMD_S_SendCard));
            if (wDataSize<sizeof(CMD_S_SendCard)) 
                return false;
            assert( 0 == (wDataSize%sizeof(CMD_S_SendCard)));
            
            int count = wDataSize/sizeof(CMD_S_SendCard);
            
            if (!GAMEDEBUG)
            {      
                CCLOG(@"count === %d", count);
                CCLOG(@"wdatasize:%d   sizeof:%d", wDataSize, sizeof(CMD_S_SendCard));
            }
            
            //保存信息  分配了内存 游戏场景中接收到第一件事就是free掉
			CMD_S_SendCard *pLogonSuccess=(CMD_S_SendCard *)pData;
			CMD_S_SendCard *GameOperate = (CMD_S_SendCard*)malloc(sizeof(CMD_S_SendCard));
            memcpy(GameOperate, pLogonSuccess, sizeof(CMD_S_SendCard));
            
            
            [self.delegate GameSendCard:SUB_S_SEND_CARD arg:(char*)GameOperate len:sizeof(CMD_S_SendCard)];
            CCLOG(@"收到发送扑克");
            return true;
		}
            
        case SUB_S_LISTEN_CARD:		//听牌命令
		{
            CCLOG(@"听牌命令");
            return true;
		}
            
        case SUB_S_OPERATE_NOTIFY:		//操作提示
		{
            CCLOG(@"自己有机会操作提示");
            return true;
		}
            
        case SUB_S_OPERATE_RESULT:		//操作命令  操作之后服务器下发
		{
            //效验参数
            assert(wDataSize>=sizeof(CMD_S_OperateResult));
            if (wDataSize<sizeof(CMD_S_OperateResult)) 
                return false;
            assert( 0 == (wDataSize%sizeof(CMD_S_OperateResult)));
            
            int count = wDataSize/sizeof(CMD_S_OperateResult);
            
            
            //保存信息  分配了内存 游戏场景中接收到第一件事就是free掉
			CMD_S_OperateResult *pLogonSuccess=(CMD_S_OperateResult *)pData;
			CMD_S_OperateResult *GameOperate = (CMD_S_OperateResult*)malloc(sizeof(CMD_S_OperateResult));
            memcpy(GameOperate, pLogonSuccess, sizeof(CMD_S_OperateResult));
            
            if (GAMEDEBUG)
            {      
                CCLOG(@"操作用户:%d 供应用户:%d 操作代码:%d 操作扑克:%d",GameOperate->wOperateUser, GameOperate->wProvideUser
                        ,GameOperate->cbOperateCode, GameOperate->cbOperateCard);
                CCLOG(@"同步操作结果");
            }
            
            //操作命令
            //操作命令也需要下发到游戏服务器
            
            return true;
		}
            
        case SUB_S_GAME_END:		//游戏结束
		{
            CCLOG(@"游戏结束");
            return true;
		}
            
        case SUB_S_TRUSTEE:		//用户托管
		{
            CCLOG(@"用户托管");
            return true;
		}
            
        case SUB_S_MOVIE_END:		//客户端动画结束 用于通知客户端正式开始打牌了。客户端会播放“开始喽”配音
		{
            
            //效验参数
            assert(wDataSize>=sizeof(CMD_S_MovieEnd));
            if (wDataSize<sizeof(CMD_S_MovieEnd)) 
                return false;
            assert( 0 == (wDataSize%sizeof(CMD_S_MovieEnd)));
            
                
            //保存信息  分配了内存 游戏场景中接收到第一件事就是free掉
			CMD_S_MovieEnd *pLogonSuccess=(CMD_S_MovieEnd *)pData;
			CMD_S_MovieEnd *GameSpriteEnd = (CMD_S_MovieEnd*)malloc(sizeof(CMD_S_MovieEnd));
            memcpy(GameSpriteEnd, pLogonSuccess, sizeof(CMD_S_MovieEnd));
            
             
            //应该发送到游戏中心告诉游戏内部发出游戏开始声音
            if (GAMEDEBUG)
            {      
                
                CCLOG(@"客户端动画结束:%d",GameSpriteEnd->cbSwapCard );
                
            }
            
            return true;
		}
            
        case SUB_S_SWITCH_CHAIR:		//变更椅子
		{
            
            return true;
		}
            
        case SUB_S_RULE_TEST_RESP:		//胡牌测试结果
		{
            
            return true;
		}
            
            
        case SUB_S_SWAP_CARD:		//换牌
		{
            
            return true;
		}
            
            
        case SUB_S_SWAP_RESULT:		//换牌结束
		{
            
            return true;
		}
            
        case SUB_S_CHIHU_CARD:		//听牌提示命令
		{
            CCLOG(@"听牌提示命令");
            return true;
		}

            
        case SUB_S_NOT_CHIHU:		//番数不够
		{
            CCLOG(@"番薯不够");
            return true;
		}
        
        case SUB_S_USER_LEFT:		//用户退出
		{
            CCLOG(@"用户退出1");
            return true;
		}
            
        case SUB_S_EXIT_GAME:		//用户退出
		{
            CCLOG(@"用户退出2");
            return true;
		}
        
            
        default:
            return true;
	}
    
	return true;
}




//解析桌子框架
- (BOOL) OnSocketUserFrame:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GF_INFO:		//桌子消息  100
		{
			return true;
		}
        case SUB_GF_OPTION:		//游戏状态参数
		{
			
			return true;
		}
        case SUB_GF_BANK_STORAGE:		
		{
            return true;
		}
        case SUB_GF_BANK_GET:		
		{
            
            return true;
		}
        
        case SUB_GF_SCENE:  //游戏场景中根据场景状态不同收到不同结构体  101
        {
            
        }
            
        default:
            return true;
	}
    
	return true;
}

//解析桌子协议
- (BOOL) OnSocketTableStatus:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GR_TABLE_INFO:		//桌子信息
		{
            
            CCLOG(@"桌子信息");
            return true;
		}
        case SUB_GR_TABLE_STATUS:		//桌子状态
		{
			CCLOG(@"桌子状态");
			return true;
		}
        case SUB_GR_NEW_TABLE:		//新桌子
		{
            //效验参数
            
			assert(wDataSize>=sizeof(CMD_GR_NewTable));
			if (wDataSize<sizeof(CMD_GR_NewTable)) 
                return false;
            
            memset(&TableInfo, 0, sizeof(CMD_GR_NewTable));
			//保存信息
			CMD_GR_NewTable * pLogonSuccess=(CMD_GR_NewTable *)pData;
			memcpy(&TableInfo, pLogonSuccess, sizeof(CMD_GR_NewTable));
            CCLOG(@"新桌子wtableID:%d  zhuoZhuName:%s  GameCount:%d  ",
                  TableInfo.wTableID, TableInfo.szMasterNick, TableInfo.cbPlayCount);
            return true;
		}
            
        default:
            return true;
	}
    
	return true;
}


//解析配置信息  游戏中心协议
- (BOOL) OnSocketUserConfig:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GR_SERVER_INFO:		//房间配置
		{
			return true;
		}
        case SUB_GR_ORDER_INFO:		//等级配置
		{
			
			return true;
		}
        case SUB_GR_CONFIG_FINISH:		//配置完成
		{
           
            return true;
		}
        
        default:
            return true;
	}
    
	return true;
}



//处理登陆消息  游戏中心协议
- (BOOL) OnSocketMainLogonGameCenter:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GR_LOGON_SUCCESS:		//登录成功
		{
			//效验参数
			assert(wDataSize>=sizeof(CMD_GR_LogonSuccess));
			if (wDataSize<sizeof(CMD_GR_LogonSuccess)) 
                return false;
            
			//保存信息
            CMD_GR_LogonSuccess * pLogonSuccess = (CMD_GR_LogonSuccess *)pData;
			UserID.dwUserID = pLogonSuccess->dwUserID;
            
            CCLOG(@"UserID:%d", UserID.dwUserID);
            
			return true;
		}
        case SUB_GR_LOGON_ERROR:		//登录失败
		{
			
            CMD_GR_LogonError *error=(CMD_GR_LogonError *)pData;
//          CCLOG(@"errorCode:%d  %s", error->lErrorCode, error->szErrorDescribe);
            CCLOG(@"登陆失败");
			return true;
		}
        case SUB_GR_LOGON_FINISH:		//登录完成
		{
            CCLOG(@"登陆游戏服务器完成");
            
            return true;
		}
	}
    
	return true;
}


//解析处理登陆信息  广场协议
- (BOOL) OnSocketMainLogonGuangChang:(CMD_Command)Command data:(void*)pData len:(WORD)wDataSize
{
	switch (Command.wSubCmdID)
	{        
        case SUB_GR_LOGON_SUCCESS:		//登录成功
		{
			//效验参数
			assert(wDataSize>=sizeof(CMD_GP_LogonSuccess));
			if (wDataSize<sizeof(CMD_GP_LogonSuccess)) 
                return false;
            
			//保存信息
			//tagGlobalUserData & UserData=g_GlobalUnits.GetGolbalUserData();
			CMD_GP_LogonSuccess * pLogonSuccess=(CMD_GP_LogonSuccess *)pData;
			UserData.wFaceID=pLogonSuccess->wFaceID;
			UserData.cbGender=pLogonSuccess->cbGender;
			UserData.cbMember=pLogonSuccess->cbMember;
			UserData.dwUserID=pLogonSuccess->dwUserID;
			UserData.dwGameID=pLogonSuccess->dwGameID;
			UserData.dwExperience=pLogonSuccess->dwExperience;
			UserData.dwCustomFaceVer=pLogonSuccess->dwCustomFaceVer;
            UserData.lGameGold = pLogonSuccess->lGameGold;
            
            //测试数据信息
            //[self testForLogon];
            
			//扩展信息
			void * pDataBuffer=NULL;
			tagDataDescribe DataDescribe;
			CRecvPacketHelper RecvPacket(pLogonSuccess+1,wDataSize-sizeof(CMD_GP_LogonSuccess));
			while (true)
			{
				pDataBuffer=RecvPacket.GetData(DataDescribe);
				if (DataDescribe.wDataDescribe==DTP_NULL) 
                    break;
                
                CCLOG(@"DataDescribe.wDataDescribe:%d", DataDescribe.wDataDescribe);
                
				switch (DataDescribe.wDataDescribe)
				{
                    case DTP_USER_ACCOUNTS:		//用户帐户
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szAccounts));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szAccounts))
						{
							memcpy(GameCenterData.szAccounts,pDataBuffer,DataDescribe.wDataSize);
                           // CCLOG(@"1 ID:%s", GameCenterData.szAccounts);
							GameCenterData.szAccounts[DataDescribe.wDataSize-1]=0;
                            CCLOG(@"2 IDzhanghao:%s", GameCenterData.szAccounts);
                            
						}
						break;
					}
                    case DTP_USER_PASS:			//用户密码
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szPassWord));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szPassWord))
						{
							memcpy(GameCenterData.szPassWord,pDataBuffer,DataDescribe.wDataSize);
                           // CCLOG(@"1 pass:%s", GameCenterData.szPassWord);
							GameCenterData.szPassWord[DataDescribe.wDataSize-1]=0;
                            CCLOG(@"2 pass:%s", GameCenterData.szPassWord);
						}
						break;
					}
                    case DTP_UNDER_WRITE:		//个性签名
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szUnderWrite));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szUnderWrite))
						{
							memcpy(GameCenterData.szUnderWrite,pDataBuffer,DataDescribe.wDataSize);
							GameCenterData.szUnderWrite[DataDescribe.wDataSize-1]=0;
						}
						break;
					}
                    case DTP_USER_GROUP_NAME:	//社团名字
					{
//						assert(pDataBuffer!=NULL);
//						assert(DataDescribe.wDataSize>0);
//						assert(DataDescribe.wDataSize<=sizeof(UserData.szGroupName));
//						if (DataDescribe.wDataSize<=sizeof(UserData.szGroupName))
//						{
//							CopyMemory(UserData.szGroupName,pDataBuffer,DataDescribe.wDataSize);
//							UserData.szGroupName[CountArray(UserData.szGroupName)-1]=0;
//						}
                        CCLOG(@"社团名字");
						break;
					}
                    case DTP_STATION_PAGE:		//游戏主站
					{
//						assert(pDataBuffer!=NULL);
//						if (pDataBuffer!=NULL) 
//						{
//							g_GlobalUnits.SetStationPage((LPCTSTR)pDataBuffer);
//							m_pHtmlBrower->Navigate(g_GlobalUnits.GetStationPage());
//						}
                        CCLOG(@"游戏主战");
						break;
					}
                    case DTP_USER_NICK:			//用户昵称
					{
						assert(pDataBuffer!=NULL);
						assert(DataDescribe.wDataSize>0);
						assert(DataDescribe.wDataSize<=sizeof(GameCenterData.szNickName));
						if (DataDescribe.wDataSize<=sizeof(GameCenterData.szNickName))
						{
							memcpy(GameCenterData.szNickName,pDataBuffer,DataDescribe.wDataSize);
                            // CCLOG(@"1 pass:%s", GameCenterData.szPassWord);
							GameCenterData.szNickName[DataDescribe.wDataSize-1]=0;
                            CCLOG(@"2 nick:%s", GameCenterData.szNickName);
						}
						break;
					}
                    
                    default: 
                    { break; }
				}
			}
            
			//设置提示
			return true;
		}
        case SUB_GR_LOGON_ERROR:		//登录失败
		{
			
//			//关闭连接
//			g_GlobalAttemper.DestroyStatusWnd(this);
//			m_ClientSocket->CloseSocket();
//            
//			//显示消息
//			WORD wDescribeSize=wDataSize-(sizeof(CMD_GP_LogonError)-sizeof(pLogonError->szErrorDescribe));
//			if (wDescribeSize>0)
//			{
//				pLogonError->szErrorDescribe[wDescribeSize-1]=0;
//				ShowMessageBox(pLogonError->szErrorDescribe,MB_ICONINFORMATION);
//			}                           96e79218965eb72c92a549dd5a330112    

//          CMD_GR_LogonError 
            //123
            
            CMD_GR_LogonError * error=(CMD_GR_LogonError *)pData;
            NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            
            NSString *retStr = [[NSString alloc] initWithBytes:error->szErrorDescribe length:strlen(error->szErrorDescribe) encoding:encoding];
            CCLOG(@"登陆失败retStr:%@", retStr);
        
			return true;
		}
            
        case SUB_GR_LOGON_FINISH:		//登录完成
		{
            CCLOG(@"登陆完成");
            return true;
		}
	}
    
	return true;
}


- (BOOL) ONSocketServerList:(CMD_Command)Command data:(void *)pData len:(WORD)wDataSize
{
    switch (Command.wSubCmdID)
    {
            case SUB_GP_LIST_TYPE:
            {
                CCLOG(@"SUB_GP_LIST_TYPE");
                break;
            }
            case SUB_GP_LIST_KIND:
            {
                CCLOG(@"SUB_GP_LIST_KIND");
                break;
            }
            case SUB_GP_LIST_STATION:
            {
                CCLOG(@"SUB_GP_LIST_STATION");
                break;
            }
            
            case SUB_GP_LIST_SERVER:
            {
                CCLOG(@"SUB_GP_LIST_SERVER");
                //效验参数
                assert(wDataSize>=sizeof(tagGameServer));
                if (wDataSize<sizeof(tagGameServer)) 
                    return false;
                assert( 0 == (wDataSize%sizeof(tagGameServer)) );
                
                int count = wDataSize/sizeof(tagGameServer);
                CCLOG(@"count === %d", count);
                
                for (int i = 0; i < count; i++) 
                {
                    //保存信息
                    
                    tagGameServer * pLogonSuccess=(tagGameServer *)( (char*)pData + (i * sizeof(tagGameServer)) );
                    
                    memcpy(&GameServer[i], pLogonSuccess, sizeof(tagGameServer));
                    
                    //test
                    char str1[INET_ADDRSTRLEN];
                    char str2[INET_ADDRSTRLEN];
                    inet_ntop(AF_INET, &GameServer[i].dwServerAddr, str1, INET_ADDRSTRLEN);
                    inet_ntop(AF_INET, &GameServer[i].dwServerAddr2, str2, INET_ADDRSTRLEN);
                    CCLOG(@"port: %d   IP:%s   IP2:%s  fanguanLevel:%d Housetype:%d",GameServer[i].wServerPort ,str1, str2, GameServer[i].wServerLevel, GameServer[i].wServerType);
                    //end
                }
                break;
            }
            
            default:
            {
                break;
            }
            
            
    }
    
    
    return true;
}

//解析协议内容   游戏中心协议
- (BOOL) OnEventTCPSocketReadGameCenter:(void*) shadoww command:(CMD_Command) Command data:(void *) pData len:(WORD) wDataSize
{
    
    CCLOG(@"解析游戏中心协议包 主命令%d  子命令:%d len:%d", Command.wMainCmdID, Command.wSubCmdID, wDataSize);
    GameManager *shadow =[GameManager sharedGameManager];
    
    //解析登陆主命令  1
    if (Command.wMainCmdID == MDM_GR_LOGON)
    {
        [shadow OnSocketMainLogonGameCenter:Command data:pData len:wDataSize];
    }
    
    
    //处理用户信息  2
    if (Command.wMainCmdID == MDM_GR_USER)
    {
        [shadow OnSocketUserInfo:Command data:pData len:wDataSize];
    }
    
    
    //解析配置信息  3
    if (Command.wMainCmdID == MDM_GR_INFO)
    {
        [shadow OnSocketUserConfig:Command data:pData len:wDataSize];
    }
   
    
    //桌子状态     4    手游应该不用显示具体桌子忽略
    if (Command.wMainCmdID == MDM_GR_STATUS)
    {
        [shadow OnSocketTableStatus:Command data:pData len:wDataSize];
    }
    
    
    //管理命令  5
    if (Command.wMainCmdID == MDM_GR_MANAGER)
    {
        CCLOG(@"管理命令 手游无需");
    }
    
    //系统消息  10
    if (Command.wMainCmdID == MDM_GR_SYSTEM)
    {
        CCLOG(@"系统消息");
    }

    //房间消息  11
    if (Command.wMainCmdID == MDM_GR_SERVER_INFO)
    {
        CCLOG(@"房间消息");
    }
    
    //桌子框架消息  101 
    if (Command.wMainCmdID == MDM_GF_FRAME)
    {
        CCLOG(@"桌子框架信息");
        [shadow OnSocketUserFrame:Command data:pData len:wDataSize];
    }
    
    //开始游戏消息  100 
    if (Command.wMainCmdID == MDM_GF_GAME)
    {
        [shadow OnSocketGameCenter:Command data:pData len:wDataSize];
    }
    
    
    return true;
    
    
}




//解析协议内容   广场协议
- (BOOL) OnEventTCPSocketReadGuangChang:(void*) shadoww command:(CMD_Command) Command data:(void *) pData len:(WORD) wDataSize
{
    
    CCLOG(@"解析广场协议包 主命令%d  子命令:%d len:%d", Command.wMainCmdID, Command.wSubCmdID, wDataSize);
    GameManager *shadow =[GameManager sharedGameManager];
    
    //解析登陆主命令
    if (Command.wMainCmdID == MDM_GR_LOGON)
    {
        [shadow OnSocketMainLogonGuangChang:Command data:pData len:wDataSize];
    }
    
    //获取游戏服务器IP 端口信息
    if (Command.wMainCmdID == MDM_GP_SERVER_LIST)
    {
        [shadow ONSocketServerList:Command data:pData len:wDataSize];
    }
    
    
    return true;
            
    
}


//死循环内
//接收消息处理方法
- (BOOL) OnSocketNotifyRead: (void*)shadow
{
    
        int rcode = 0, ret;
        BOOL bSuccess;
        GameManager *shadoww = (GameManager *)shadow;
        
        fd_set set;
        FD_ZERO(&set);
        FD_SET(shadoww.fd, &set);
        
        rcode = select(shadoww.fd + 1, &set, NULL, NULL, NULL);
        
    
        //test
        //CCLOG(@"OnSocketNotifyRead===");
    
        //出错直接返回
        if (rcode < 0)
        {
            CCLOG(@"thread_handler:select < 0");
        }
        
        //从服务器接受到信息 并解析协议
        if(FD_ISSET(shadoww.fd, &set))
        {
            //读取数据
            int  iRetCode=recv(shadoww.fd,(char *)m_cbRecvBuf+m_wRecvSize,sizeof(m_cbRecvBuf)-m_wRecvSize,0);
            
            CCLOG(@"收到数据包:%d", iRetCode);
            //关闭判断 暂时为空 
            
            //出错 重新请求连接
            if (iRetCode == -1)
            {
                //[self OnSocketServerLogon];
                return false;
            }
            
            //设置变量
            m_wRecvSize+=iRetCode;
            
            //变量定义
            CMD_Head * pHead=(CMD_Head *)m_cbRecvBuf;
            BYTE cbDataBuffer[SOCKET_PACKET+sizeof(CMD_Head)];
            
            
            //数据包头处理
            while (m_wRecvSize>=sizeof(CMD_Head))
            {
                //版本判断
                if (pHead->CmdInfo.cbVersion!=SOCKET_VER)
                {
                    CCLOG(@"版本不匹配");
                    return FALSE;
                }
                
                //长度判断
                if (pHead->CmdInfo.wPacketSize>(SOCKET_PACKET+sizeof(CMD_Head)))
                {
                    CCLOG(@"接收包长度过长");
                    return FALSE;
                }
                
                //test
                //CCLOG(@"m_wRecvSize:%d  packetTotal:%d", m_wRecvSize,pHead->CmdInfo.wPacketSize );
                //CCLOG(@"mainCmd:%d   Subcmd:%d",pHead->CommandInfo.wMainCmdID,pHead->CommandInfo.wSubCmdID);
                
                //完整判断
                WORD wPacketSize=pHead->CmdInfo.wPacketSize;
                if (m_wRecvSize<pHead->CmdInfo.wPacketSize) 
                {
                    CCLOG(@"包长错误");
                    return FALSE;
                }
                //设置变量
                m_dwRecvPacketCount++;
                m_wRecvSize-=wPacketSize;
                
                //提取数据
                memcpy(cbDataBuffer,m_cbRecvBuf,wPacketSize);
                memmove(m_cbRecvBuf,m_cbRecvBuf+wPacketSize,m_wRecvSize);
                
                //解密数据
#ifdef _WEIBO_DEBUG
                WORD wRealySize = wPacketSize;
#else
                WORD wRealySize=[shadoww CrevasseBuffer:cbDataBuffer datasize:wPacketSize];
#endif

                
                //解释数据
                WORD wDataSize=wRealySize-sizeof(CMD_Head);
                void * pDataBuffer=cbDataBuffer+sizeof(CMD_Head);
                CMD_Command Command=((CMD_Head *)cbDataBuffer)->CommandInfo;
                
                
                //test
                //CCLOG(@"mainCmd:%d   Subcmd:%d",Command.wMainCmdID,Command.wSubCmdID);
                
                //内核数据
                if (Command.wMainCmdID==MDM_KN_COMMAND)
                {
                    switch (Command.wSubCmdID)
                    {
                        case SUB_KN_DETECT_SOCKET:		//网络检测
                        {
                            CCLOG(@"内核命令SUB_KN_DETECT_SOCKET");
                            [shadoww sendData:MDM_KN_COMMAND sum:SUB_KN_DETECT_SOCKET];
                            break;
                        }
                        case SUB_KN_SHUT_DOWN_SOCKET:	//中断连接
                        {
                            [self CloseSocket];
                            CCLOG(@"内核命令中断链接");                            
                            break;
                        }
                    }
                }
                
                //常规数据
                if (Command.wMainCmdID!=MDM_KN_COMMAND)
                {
                   
                    //处理广场数据
                    if (self.GameFd == SOCKET_GUANGCHANG)
                    {
                        //处理数据
                        //CCLOG(@"广场数据");
                        bSuccess = [shadoww OnEventTCPSocketReadGuangChang:shadoww command:Command 
                                                                 data:pDataBuffer len:wDataSize];
                    }
                    
                    //处理游戏中心数据
                    if (self.GameFd == SOCKET_GAMECENTER)
                    {
                        //处理数据
                        //CCLOG(@"游戏中心数据");
                        bSuccess = [shadoww OnEventTCPSocketReadGameCenter:shadoww command:Command 
                                                             data:pDataBuffer len:wDataSize];
                    }
                    
                    
                    if (bSuccess == false)
                    {
                        //关闭链接
                        CCLOG(@"处理常规数据失败关闭链接");
                        [self CloseSocket];
                    }
                        
                }
            }
            
        }
        
    
}

#pragma 测试调试部分

//发送游戏服务器登陆请求返回的命令
//2012-08-09 16:54:58.873 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令1  子命令:102
//2012-08-09 16:54:58.874 HappyMahjong[6690:14503] 登陆游戏服务器完成
//2012-08-09 16:54:59.791 HappyMahjong[6690:14503] 收到数据包:12
//2012-08-09 16:54:59.792 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令1  子命令:100
//2012-08-09 16:54:59.793 HappyMahjong[6690:14503] UserID:1131
//2012-08-09 16:55:00.360 HappyMahjong[6690:14503] 收到数据包:1022
//2012-08-09 16:55:00.360 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令3  子命令:100
//2012-08-09 16:55:00.361 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令3  子命令:103
//2012-08-09 16:55:00.361 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令3  子命令:104
//2012-08-09 16:55:00.362 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:100     用户进入
//2012-08-09 16:55:00.362 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令4  子命令:100
//2012-08-09 16:55:00.363 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:440
//2012-08-09 16:55:00.363 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:502
//2012-08-09 16:55:00.363 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:509
//2012-08-09 16:55:00.364 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:419
//2012-08-09 16:55:00.364 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:471
//2012-08-09 16:55:00.365 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令2  子命令:459
//2012-08-09 16:55:00.365 HappyMahjong[6690:14503] 解析游戏中心协议包 主命令1  子命令:102
//2012-08-09 16:55:00.365 HappyMahjong[6690:14503] 登陆游戏服务器完成
//2012-08-09 16:56:28.852 HappyMahjong[6701:14403] 解析游戏中心协议包 主命令11  子命令:100


//打印登陆信息
-(BOOL) testForLogon
{
//    UserData.wFaceID=pLogonSuccess->wFaceID;
//    UserData.cbGender=pLogonSuccess->cbGender;
//    UserData.cbMember=pLogonSuccess->cbMember;
//    UserData.dwUserID=pLogonSuccess->dwUserID;
//    UserData.dwGameID=pLogonSuccess->dwGameID;
//    UserData.dwExperience=pLogonSuccess->dwExperience;
//    UserData.dwCustomFaceVer=pLogonSuccess->dwCustomFaceVer;
//    UserData.lGameGold = pLogonSuccess->lGameGold;
//    
//    UserComeInfo.dwUserID = pLogonSuccess->dwUserID;//用户ID
//    UserComeInfo.dwUserRight = pLogonSuccess->dwUserRight;//等级
//    UserComeInfo.lLoveliness = pLogonSuccess->lLoveliness;//魅力值
//    UserComeInfo.cbGender = pLogonSuccess->cbGender;//性别
//    LONG								lScore;								//用户分数
//    LONG								lGameGold;							//游戏金币
//    LONG								lInsureScore;						//存储金币
//    LONG								lWinCount;							//胜利盘数
//    LONG								lLostCount;							//失败盘数
//    LONG								lDrawCount;							//和局盘数
//    LONG								lFleeCount;							//断线数目
//    LONG								lExperience;						//用户经验
//    LONG								lGameExperience;					//游戏经验
//    LONG								lGameRP;							//牌品
//    LONG 								lGamePoint;							//成就点数
//    LONG 								lCrystal;							//点券数
//    LONG								lGiftPoint;							//礼券
//    WORD								wGameLevel;							//游戏级别
    
    CCLOG(@"UserComeInfo.dwUserID:%d", UserComeInfo.dwUserID);
    CCLOG(@"UserComeInfo.dwUserRight:%d", UserComeInfo.dwUserRight);
    CCLOG(@"UserComeInfo.cbGende:%d", UserComeInfo.cbGender);
    CCLOG(@"UserComeInfo.score:%d", UserComeInfo.dwTitleID);
    CCLOG(@"UserComeInfo.scoreInfo:%d", UserComeInfo.UserScoreInfo.lGameRP);
    CCLOG(@"UserComeInfo.scoreInfo:%d", UserComeInfo.UserScoreInfo.lGameExperience);
    
    
    
    return true;
}

# pragma 网络转码 目前不管用 后期仔细研究核实

- (NSString*)UTF8_To_GB2312:(NSString*)utf8string
{
    NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
    NSData* gb2312data = [utf8string dataUsingEncoding:encoding];
    return [[[NSString alloc] initWithData:gb2312data encoding:encoding] autorelease];
}

- (NSString*)GB2312_To_UTF8:(NSString*)utf8string
{
    NSStringEncoding encoding =CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingHZ_GB_2312);
    NSData* gb2312data = [utf8string dataUsingEncoding:encoding];
    return [[[NSString alloc] initWithData:gb2312data encoding:encoding] autorelease];
}






#pragma 单例模式初始化部分

-(id)init
{
    self = [super init];
    
	if(self != nil)
	{
        //套接字初始化
        fd = 0;
        GameFd = 0;
        
        //这里初始化各种数据
        memset(m_cbRecvBuf, 0, sizeof(m_cbRecvBuf));
        m_wRecvSize = 0;
        memset(&UserData, 0, sizeof(CMD_GP_LogonSuccess));
        memset(&GameCenterData, 0, sizeof(tagGlobalUserData));
        memset(&UserID, 0, sizeof(CMD_GR_LogonSuccess));
        memset(&UserComeInfo, 0, sizeof(tagUserInfoHead));
        memset(&GameSet, 0, sizeof(CMD_GR_GameSet));
        memset(GameServer, 0, sizeof(GameServer));
        memset(&PlayerChairInfo, 0, sizeof(PlayerChairInfo));
        memset(&TableInfo, 0, sizeof(TableInfo));
        memset(&playGameing, 0, sizeof(playGameing));
        
        
        
        //分配
        AllPlayerInfo = [[NSMutableArray alloc] init];
        
    }
    
    
    
    
    return  self;
    
    
}

//类方法
+(GameManager*)sharedGameManager
{
	@synchronized([GameManager class])
	{
		if(!_sharedGameManager)[[self alloc] init];
		return _sharedGameManager;
	}
	return nil;
}


+(id)alloc
{
    @synchronized([GameManager class])
    {
        NSAssert(_sharedGameManager == nil,
                 @"attempted to allocate a second instance of the Game Manager singletion");
        _sharedGameManager = [super alloc];
        return _sharedGameManager;
    }
}



- (void) dealloc
{
    
    [AllPlayerInfo release];
    [viewController release];
    //最后释放整个单例类
	_sharedGameManager = nil;
	[super dealloc];
}


@end





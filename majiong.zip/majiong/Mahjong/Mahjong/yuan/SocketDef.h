//
//  SocketDef.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月1日.
//  Copyright (c) 2012年 Yuan. All rights reserved.
//

#ifndef HappyMahjong_SocketDef_h
#define HappyMahjong_SocketDef_h
#import "Cmd.h"

#pragma 网络

#define CONNECTED 0
#define CONNECT_SUC 1
#define CONNECT_FAIL 2
#define SERVER_IP "112.84.186.31" 
#define SERVER_PORT 9001          //8080

typedef unsigned char       BYTE;     		//1字节
typedef unsigned short      WORD;		//2字节
typedef unsigned long       DWORD;		//4字节
typedef char TCHAR;
typedef long  LONG;
typedef int INT;
typedef char CHAR;

//网络数据定义
#define PACKET_HEAD                     8
#define WSOCIAlID                       0
#define CLIENT_VER                      0x10001
#define CLIENT_TYPE                     3                                   //3-ios  4-android
#define PROCESS_VER                     100                              //客户端版本。具体值可在fla里设定
#define SOCKET_VER						0x66								//网络版本
#define SOCKET_BUFFER					8192								//网络缓冲

#define SOCKET_GUANGCHANG                           1
#define SOCKET_GAMECENTER                           2



//as中宏 
#define KIND_ID                     328     //游戏ID
#define GAME_PLAYER                 4
#define GAME_NAME                  "13张麻將"



//游戏类型
#define GAME_GENRE_SCORE				 0x0001								//点值类型
#define GAME_GENRE_GOLD					 0x0002								//金币类型
#define GAME_GENRE_MATCH				 0x0004								//比赛类型
#define GAME_GENRE_EDUCATE				 0x0008								//训练类型


//游戏状态
#define GS_FREE							 0								//空闲状态
#define GS_PLAYING						100                             //游戏状态



//常量定义
#define MAX_HUA						 8									//花牌数量
#define MAX_WEAVE					 4									//最大组合
#define MAX_INDEX					 42									//最大索引
#define	MAX_COUNT					 14									//最大数目
#define MAX_REPERTORY				 144									//最大库存
#define LOCKED_COUNT				 0									//牌堆末尾不能摸的张数
#define MAX_RIGHT_COUNT				 3									//最大权位DWORD个数
//扑克定义
#define HEAP_FULL_COUNT				 36									//堆立全牌
#define DISCARD_COUNT				 60									//最多记录多少个丢弃的牌

//公共定义
#define POS_SHOOT					5								//弹起象素
#define POS_SPACE					 8								//分隔间隔
#define ITEM_COUNT					 43									//子项数目
#define INVALID_ITEM				 0xFFFF								//无效索引
#define MASK_CHI_HU_RIGHT			 0x0fffffff

//逻辑掩码
#define	MASK_COLOR					 0xF0								//花色掩码
#define	MASK_VALUE					 0x0F							//数值掩码



//动作定义

#define GAME_START					 0xFF

//补花
//动作标志
#define WIK_NULL					 0x00								//没有类型
#define WIK_LEFT					 0x01								//左吃类型
#define WIK_CENTER					 0x02								//中吃类型
#define WIK_RIGHT					 0x04								//右吃类型
#define WIK_PENG					 0x08								//碰牌类型
#define WIK_GANG					 0x10								//杠牌类型
#define WIK_HUA						 0x20								//花牌类型
#define WIK_CHI_HU					 0x40								//吃胡类型
#define WIK_LISTEN					 0x80								//听牌类型

//////////////////////////////////////////////////////////////////////////
//胡牌定义

#define CHR_PING_HU					 0x00000001							//
#define CHR_GOU_DOU					 0x00000002							//
//#define CHR_DA_GOU_DOU				0x00000004							//
#define CHR_MAN_GUAN				 0x00000008							//
#define CHR_BEN_PIAO				 0x00000010							//
#define CHR_XI_PIAO					 0x00000020							//
#define CHR_QING_YI_SE				 0x00000040							//
#define CHR_QING_YI_SE_BEN_PIAO		 0x00000080							//
#define CHR_QING_YI_SE_XI_PIAO		 0x00000100							//

 //////////////////////////////////////////////////////////////////////////
 //客户端命令结构

#define SUB_C_OUT_CARD				 1									//出牌命令
#define SUB_C_LISTEN_CARD			 2									//听牌命令
#define SUB_C_OPERATE_CARD			 3									//操作扑克
#define SUB_C_TRUSTEE				 4									//用户托管
#define SUB_C_DING_ZHANG			 5									//
#define SUB_C_MOVIE_END				 6									//开始动画结束


#define SUB_C_SWITCH_END			 7									//交换座位结束
#define SUB_C_DEBUG_CARD			 8									//测试命令，想要哪张摸哪张

#define SUB_C_RULE_TEST_REQ   	     9									//测试命令

#define SUB_C_EXPOSURE_CARD			 12									//亮牌
#define SUB_C_EXPOSURE_END			 13									//取消亮牌
#define SUB_C_SWAP_CARD				 14									//换牌
#define SUB_C_SWAP_END				 15									//取消换牌
#define SUB_C_USER_LEFT				 16									//用户退出

#define LOC_GAME					 1000				//本地游戏命令
#define LOC_G_ON_CLICK_LISTEN		 1001				//游戏中点击听牌操作按钮

#define IDI_DISC_EFFECT			 102								//丢弃效果


//游戏定时器

#define IDI_START_GAME			 200									//开始定时器
#define IDI_OPERATE_CARD		 201									//操作定时器
#define IDI_CHANGE_CARD			 202									//换牌定时器
#define IDI_EXPOSE_CARD			 203									//明牌定时器
//游戏定时器

//各馆名称
//SERVER_NAME:["翻本馆","推倒馆","三番馆","五番馆","八番馆","比赛馆","互粉馆", "积分馆"];

//网络内核      
typedef struct CMD_Info
{
    BYTE        cbVersion;       //版本标识
    BYTE        cbCheckCode;      //效验字段
    WORD        wPacketSize;      //数据大小
}CMD_Info;

//网络命令
typedef  struct CMD_Command
{
    WORD        wMainCmdID;       //主命令码
    WORD        wSubCmdID;       //子命令码
}CMD_Command;

//网络包头
typedef struct CMD_Head
{
    CMD_Info       CmdInfo;       //基础结构
    CMD_Command       CommandInfo;      //命令信息
}CMD_Head;


#define SOCKET_PACKET					(SOCKET_BUFFER-sizeof(CMD_Head)-2*sizeof(DWORD))

//网络包
//包头共8个字节，包含版本号（固定），校验码、包长、主命令码、子命令码
//其中，校验码是在加密后获得的。加解密函数及具体算法见客户端代码(com\emine\qp\plaza\net\ConnManage.as)

typedef  struct CMD_Buffer
{
    CMD_Head       Head;        //数据包头
    BYTE        cbBuffer[SOCKET_PACKET];   //数据缓冲
}CMD_Buffer;



//注册登陆协议部分
typedef struct CMD_GP_LogonByAccounts
{
    DWORD        dwPlazaVersion;     //广场版本     广场版本是多少？  0x10001（见GlobalDef.as)
    TCHAR        szAccounts[NAME_LEN];   //登录帐号
    TCHAR        szPassWord[PASS_LEN];   //登录密码
    WORD        wSocialID;      //平台编号             默认多少      默认0
    BYTE        cbPasswordType;     //密码类型，0是密码，1是网站生成的Key
}CMD_GP_LogonByAccounts;

typedef struct CMD_GP_LogonSuccess
{
    WORD        wFaceID;      //头像索引      具体如何排列头像和对应数字   忽略此字段
    BYTE        cbGender;      //用户性别      男女对应什么数字            0-女  1-男
    BYTE        cbMember;      //会员等级
    DWORD        dwUserID;      //用户 I D     
    DWORD        dwGameID;      //游戏 I D
    DWORD        dwExperience;     //用户经验
    
    //扩展信息
    DWORD        dwCustomFaceVer;    //头像版本         什么是头像版本      忽略
    LONG         lGameGold;                      //可能的金币   就是金币拥有量吧   就是金币数
    
       
}CMD_GP_LogonSuccess;


typedef struct tagGlobalUserData
{
    //登陆游戏服务器信息
    BYTE								szAccounts[NAME_LEN];						//登录帐号
    BYTE								szPassWord[PASS_LEN];						//登录密码
    BYTE								szGroupName[GROUP_LEN];                                //社团信息
    BYTE								szUnderWrite[UNDER_WRITE_LEN];                               //个性签名
    BYTE                                szNickName[NAME_LEN];

}tagGlobalUserData;


typedef struct CMD_GR_LogonError
{
    LONG       lErrorCode;       //错误代码
    TCHAR      szErrorDescribe[128];    //错误消息
}CMD_GR_LogonError;


typedef struct CMD_GR_LogonByUserID
{
    DWORD       dwPlazaVersion;    //广场版本
    DWORD       dwProcessVersion;  //进程版本
    DWORD       dwUserID;          //用户 I D
    TCHAR       szPassWord[PASS_LEN];    //登录密码
    BOOL        bIsFan;            //是否是粉丝
    BYTE        cbClientType;      //客户端类型
}CMD_GR_LogonByUserID;




typedef struct tagGameServer
{
    WORD        wSortID;       //排序号码                   列表显示时的排序依据
    WORD        wKindID;       //名称号码                   游戏类型ID
    WORD        wServerID;       //房间号码                 房间编号，无特定含义
    WORD        wServerLevel;    //房间级别                 馆的编号，各馆名称可见game\SparrowGB\src\Sparrow.as的                       SERVER_NAME 
    WORD        wServerType;      //房间类型                见com\emine\qp\share\enum\ServerType.as。国标麻将是GAME_GENRE_GOLD  1是新手管 2是3饭馆?
    WORD        wStationID;       //站点号码                忽略
    WORD        wServerPort;      //房间端口                Socket端口
    DWORD        dwServerAddr;      //房间地址              IP地址1
    DWORD        dwServerAddr2;      //房间地址2，一般为网通地址   IP地址2
    DWORD        dwOnLineCount;      //在线人数             房间在线人数
    DWORD        dwPlayCount;        //游戏人数             在玩的人数
    TCHAR        szServerName[32];   //房间名称             名称。但现在客户端没有显示
    TCHAR        szDomainAddr[32];   //域名地址             如果此项不为空，则应优先使用此地址
}tagGameServer;


//数据描述头
//用来解析session ID额外数据等信息
typedef struct tagDataDescribe
{
	WORD							wDataSize;						//数据大小
	WORD							wDataDescribe;					//数据描述
}tagDataDescribe;


//游戏服务器登陆成功命令
typedef struct CMD_GR_LogonSuccess
{
    DWORD       dwUserID;       //用户 I D
}CMD_GR_LogonSuccess;


//桌子框架消息
typedef struct CMD_GF_Info
{
    BYTE        bAllowLookon;
}CMD_GF_Info;

typedef struct tagUserScore
{
    LONG								lScore;								//用户分数
    LONG								lGameGold;							//游戏金币
    LONG								lInsureScore;						//存储金币
    LONG								lWinCount;							//胜利盘数
    LONG								lLostCount;							//失败盘数
    LONG								lDrawCount;							//和局盘数
    LONG								lFleeCount;							//断线数目
    LONG								lExperience;						//用户经验
    LONG								lGameExperience;					//游戏经验
    LONG								lGameRP;							//牌品
    LONG 								lGamePoint;							//成就点数
    LONG 								lCrystal;							//点券数
    LONG								lGiftPoint;							//礼券
    WORD								wGameLevel;							//游戏级别
    
}tagUserScore;


//会员等级
typedef struct CMD_GR_MemberOrder
{
	DWORD							dwUserID;							//数据库 ID
	BYTE							cbMemberOrder;						//会员等级
}CMD_GR_MemberOrder;

//用户权限
typedef struct CMD_GR_UserRight
{
	DWORD							dwUserID;							//数据库 ID
	DWORD							dwUserRight;						//用户权限
}CMD_GR_UserRight;

//用户状态
typedef struct CMD_GR_UserStatus
{
	DWORD							dwUserID;							//数据库 ID
	WORD							wTableID;							//桌子位置
	WORD							wChairID;							//椅子位置
	BYTE							cbUserStatus;						//用户状态
}CMD_GR_UserStatus;


#define US_NULL   0x00        //没有状态
#define US_FREE    0x01        //站立状态
#define US_SIT    0x02        //坐下状态
#define US_READY   0x03        //同意状态
#define US_LOOKON   0x04        //旁观状态
#define US_PLAY    0x05       //游戏状态
#define US_OFFLINE   0x06        //断线状态"

typedef struct tagUserInfoHead               
{
    DWORD        dwUserID;       //用户 I D
    DWORD        dwGroupID;       //社团索引                   忽略
    DWORD        dwUserRight;      //用户等级                  忽略
    LONG         lLoveliness;      //用户魅力                  用于开福袋的货币，玩游戏即可获得
    DWORD        dwMasterRight;      //管理权限                用于区分是否管理员
    DWORD        dwClientIP;
    BYTE         cbGender;       //用户性别
    BYTE         cbMemberOrder;      //会员等级                VIP等级，0表示不是VIP
    BYTE         cbMasterOrder;      //管理等级                忽略
    WORD         wTableID;       //桌子号码                    在哪张桌子上。65535(INVALID_TABLE)表示不在桌子上
    WORD         wChairID;       //椅子位置                    椅子编号。INVALID_CHAIR表示不在椅子上
    BYTE         cbUserStatus;      //用户状态                 见com\emine\qp\share\utils\GlobalDef.as中的US_XXX
    tagUserScore UserScoreInfo;      //积分信息                
    WORD         wAdornData[10];   //装饰数据                  人物服装数据。按部位记录的索引号
    DWORD        dwTitleID;        //当前称号id                对应的成就ID
    BYTE         cbUserType;        //用户类型  0普通帐号 1机器人 2游客
}tagUserInfoHead;

//用户分数
typedef struct CMD_GR_UserScore
{
	LONG							lLoveliness;						//用户魅力
	//LONG							lInsureScore;						//消费金币
	//LONG							lGameGold;							//游戏金币
	DWORD							dwUserID;							//用户 I D
	DWORD							dwTitleID;							//用户称号
	tagUserScore					UserScore;							//积分信息
}CMD_GR_UserScore;

//请求坐下
typedef struct CMD_GR_UserSitReq
{
	WORD							wTableID;							//桌子位置
	WORD							wChairID;							//椅子位置
	BYTE							cbPassLen;							//密码长度
	//LONG                            lGameChip;                          //携带筹码
	TCHAR							szTablePass[PASS_LEN];				//桌子密码
}CMD_GR_UserSitReq;




typedef struct CMD_GR_UserSitSearchReq
{
	bool							bNewTable;									//是否开新局
	bool							bSelectTable;								//是否指定桌子编号
	bool							bOnlyFriends;								//是否亲友团
	BYTE                            cbSitDown;                                   //是否坐下 1--坐下/0--旁观
	WORD							wTableID;									//桌子ID
	BYTE							cbParam[TABLE_OPTION_MAX];					//游戏类型
    
}CMD_GR_UserSitSearchReq;



//邀请用户 
typedef struct CMD_GR_UserInviteReq
{
	WORD							wTableID;							//桌子号码
	DWORD							dwUserID;							//用户 I D
}CMD_GR_UserInviteReq;

typedef struct CMD_GR_AdvUserInviteReq
{
	WORD							wTableID;							//桌子号码
	DWORD							dwDestUserID;						//被邀请者ID
	
	WORD							wDestKindID;						//被邀请者游戏ID
	WORD							wDestServerID;						//被邀请者服务器ID
    
	DWORD							dwSendUserID;						//发送者ID
	WORD							wSendKindID;							//游戏类型
	WORD							wSendServerID;							//哪个服务器
	TCHAR							szDesc[128];						//描述信息
}CMD_GR_AdvUserInviteReq;

//坐下失败
typedef struct CMD_GR_SitFailed
{
	WORD                            wError;
	TCHAR							szFailedDescribe[256];				//错误描述
}CMD_GR_SitFailed;





//聊天结构 
//typedef struct CMD_GR_UserChat
//{
//	WORD							wChatLength;						//信息长度
//	COLORREF						crFontColor;						//信息颜色
//	DWORD							dwSendUserID;						//发送用户
//	DWORD							dwTargetUserID;						//目标用户
//	TCHAR							szSendUserNick[NAME_LEN];			//发送者名称
//	TCHAR							szChatMessage[MAX_CHAT_LEN];		//聊天信息
//}CMD_GR_UserChat;

//私语结构 
//typedef struct CMD_GR_Wisper
//{
//	WORD							wChatLength;						//信息长度
//	COLORREF						crFontColor;						//信息颜色
//	DWORD							dwSendUserID;						//发送用户
//	DWORD							dwTargetUserID;						//目标用户
//	TCHAR							szSendUserNick[NAME_LEN];			//发送者名称
//	TCHAR							szChatMessage[MAX_CHAT_LEN];		//聊天信息
//}CMD_GR_Wisper;

//用户规则
typedef struct  CMD_GR_UserRule
{
	bool							bPassword;							//设置密码
	bool							bLimitWin;							//限制胜率
	bool							bLimitFlee;							//限制断线
	bool							bLimitScore;						//限制分数
	bool							bCheckSameIP;						//效验地址
	WORD							wWinRate;							//限制胜率
	WORD							wFleeRate;							//限制逃跑
	LONG							lMaxScore;							//最高分数 
	LONG							lLessScore;							//最低分数
	TCHAR							szPassword[PASS_LEN];				//桌子密码
}CMD_GR_UserRule;

//邀请用户 
typedef struct CMD_GR_UserInvite
{
	WORD							wTableID;							//桌子号码
	DWORD							dwUserID;							//用户 I D
}CMD_GR_UserInvite;

typedef struct CMD_GR_RequestUserInfo
{
	DWORD							dwUserID;
}CMD_GR_RequestUserInfo;



//游戏房间信息
typedef struct CMD_GR_ServerInfo
{
	//房间属性
	WORD							wKindID;							//类型 I D
	WORD							wTableCount;						//桌子数目
	WORD							wChairCount;						//椅子数目
	DWORD							dwVideoAddr;						//视频地址
    
	//扩展配置
	WORD							wGameGenre;							//游戏类型
	BYTE							cbHideUserInfo;						//隐藏信息
}CMD_GR_ServerInfo;

//分数描述信息
typedef struct CMD_GR_ScoreInfo
{
	WORD							wDescribeCount;						//描述数目
	WORD							wDataDescribe[16];					//数据标志
}CMD_GR_ScoreInfo;

//等级描述结构
typedef struct tagOrderItem
{
	LONG							lScore;								//等级积分
	WORD							wOrderDescribe[16];					//等级描述
}tagOrderItem;

//等级描述信息
typedef struct CMD_GR_OrderInfo
{
	WORD							wOrderCount;						//等级数目
	tagOrderItem					OrderItem[128];						//等级描述
}CMD_GR_OrderInfo;

//列表项描述结构
typedef struct tagColumnItem
{
	WORD							wColumnWidth;						//列表宽度
	WORD							wDataDescribe;						//字段类型
	TCHAR							szColumnName[16];					//列表名字
}tagColumnItem;

//列表描述信息
typedef struct CMD_GR_ColumnInfo
{
	WORD							wColumnCount;						//列表数目
	tagColumnItem					ColumnItem[32];						//列表描述
}CMD_GR_ColumnInfo;

//桌子状态结构
typedef struct tagTableStatus
{
	WORD							wTableID;							//桌子号码
	TCHAR							szMasterNick[NAME_LEN];				//桌主名字
	BYTE							cbMasterChairID;					//桌主位置
	BYTE							cbPlayCount;						//游戏人数
	BYTE							cbPlayStatus;						//游戏状态  0000 0|亲友|锁定|开始
	BYTE							cbParam[TABLE_OPTION_MAX];			//游戏桌子的设定
}tagTableStatus;


//桌子状态数组 sizeof(tagTableStatus)*512+2不能大于8192
typedef struct CMD_GR_TableInfo
{
	WORD							wTableCount;						//桌子数目
	tagTableStatus					TableStatus[512];					//状态数组
}CMD_GR_TableInfo;

//开新桌
typedef struct CMD_GR_NewTable
{
	WORD							wTableID;							//桌子号码
	TCHAR							szMasterNick[NAME_LEN];				//桌主名字
	BYTE							cbMasterChairID;					//桌主位置
	BYTE							cbPlayCount;						//游戏人数
	BYTE							cbPlayStatus;						//游戏状态  0000 0|亲友|锁定|开始
	BYTE							cbParam[TABLE_OPTION_MAX];			//游戏桌子的设定
}CMD_GR_NewTable;

//桌子状态信息
typedef struct CMD_GR_TableStatus
{
	WORD							wTableID;							//桌子号码
	BYTE							cbPlayCount;						//游戏人数
	BYTE							cbPlayStatus;						//游戏状态  0000 0|亲友|锁定|开始
}CMD_GR_TableStatus;


//发送警告
//typedef struct CMD_GR_SendWarning
//{
//	WORD							wChatLength;						//信息长度
//	DWORD							dwTargetUserID;						//目标用户
//	TCHAR							szWarningMessage[MAX_CHAT_LEN];		//警告消息
//}CMD_GR_SendWarning;

//系统消息
#define MAX_CHAT_LEN    128
typedef struct CMD_GR_SendMessage
{
	BYTE							cbGame;								//游戏消息
	BYTE							cbRoom;								//游戏消息
	WORD							wChatLength;						//信息长度
	TCHAR							szSystemMessage[MAX_CHAT_LEN];		//系统消息
}CMD_GR_SendMessage;

//查看地址
typedef struct CMD_GR_LookUserIP
{
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_LookUserIP;

//踢出用户
typedef struct CMD_GR_KillUser
{
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_KillUser;

//禁用帐户
typedef struct CMD_GR_LimitAccounts
{
	DWORD							dwTargetUserID;						//目标用户
}CMD_GR_LimitAccounts;

//权限设置
typedef struct CMD_GR_SetUserRight
{
	//目标用户
	DWORD							dwTargetUserID;						//目标用户
    
	//绑定变量
	BYTE							cbGameRight;						//帐号权限
	BYTE							cbAccountsRight;					//帐号权限
    
	//权限变化
	BYTE							cbLimitRoomChat;					//大厅聊天
	BYTE							cbLimitGameChat;					//游戏聊天
	BYTE							cbLimitPlayGame;					//游戏权限
	BYTE							cbLimitSendWisper;					//发送消息
	BYTE							cbLimitLookonGame;					//旁观权限
}CMD_GR_SetUserRight;

//房间设置
typedef struct CMD_GR_OptionServer
{
	BYTE							cbOptionFlags;						//设置标志
	BYTE							cbOptionValue;						//设置标志
}CMD_GR_OptionServer;

//消息数据包
typedef struct CMD_GR_Message
{
	WORD							wMessageType;						//消息类型
	WORD							wMessageLength;						//消息长度
	TCHAR							szContent[1024];					//消息内容
}CMD_GR_Message;


//人数信息
typedef struct tagOnLineCountInfo
{
	WORD							wKindID;							//类型标识
	DWORD							dwOnLineCount;						//在线人数
	DWORD							dwPlayCount;						//游戏人数
}tagOnLineCountInfo;


//------------------------------------------------------------------------------------------------------------
// begin by xuxiangqian 2010-04-15

// 添加好友请求
typedef struct CMD_GR_AddFriendReq 
{
	DWORD dwUserID; //好友id
	BYTE cbFlag; //好友标识 1-好友/2-黑名单
}CMD_GR_AddFriendReq;


// 删除好友请求
typedef struct CMD_GR_DelFriendReq 
{
	DWORD dwUserID; //好友id
	//BYTE cbFlag; //好友标识 0-好友/1-黑名单
}CMD_GR_DelFriendReq;


//返回给客户端的错误码
typedef struct CMD_GR_User_Result 
{
	DWORD dwUserID; //目标用户
	BYTE  cbOperate; //当前操作 添加/删除
	BYTE  cbObject; //操作对象 好友/黑名单
	WORD  wError; //错误码
}CMD_GR_User_Result;

//获取邮件内容邮件
typedef struct CMD_GR_MailContent
{
	DWORD dwMailID;                           //邮件
}CMD_GR_MailContent;

//返回邮件内容
typedef struct CMD_GR_MailContent_Result
{
	DWORD dwMailID;                           //邮件
	TCHAR szContent[MAX_MAIL_CONTENT];        //邮件内容
}CMD_GR_MailContent_Result;

//删除邮件
typedef struct CMD_GR_RemoveMail
{
	DWORD dwMailID; //邮件
}CMD_GR_RemoveMail;

// 删除邮件返回
typedef struct CMD_GR_RemoveMail_Result
{
	DWORD dwMailID; //邮件
	WORD  wError;   //错误码
}CMD_GR_RemoveMail_Result;

// 邮件发送定义
typedef struct CMD_GR_SendMail 
{
	DWORD dwRecvID; //邮件接收者
	TCHAR szTitle[MAX_MAIL_TITLE]; //邮件标题
	TCHAR szContent[MAX_MAIL_CONTENT]; //邮件内容
}CMD_GR_SendMail;

//返回发送邮件的错误码
typedef struct CMD_GR_SendMailResult
{
	DWORD dwUserID; //目标用户
	WORD  wError; //错误码
}CMD_GR_SendMailResult;

// 获取邮件列表
typedef struct  CMD_GR_GetMail_Req
{
	WORD wCurrPage; //当前页
	WORD wPageSize; //每一页的数量
}CMD_GR_GetMail_Req;

// 获取邮件数据
typedef struct CMD_GR_GetMailInfo 
{
	WORD  wCurrPage; //当前页码
	WORD  wTotalCount; //总的邮件数量
	WORD  wUnreadCnt; //未读邮件数量
	WORD  wCurrNum; //当前页的数量
}CMD_GR_GetMailInfo;

//发送未读邮件数量
typedef struct  CMD_GR_UnReadMailCnt
{
	WORD wCnt; //未读邮件数量
}CMD_GR_UnReadMailCnt;

// 解开成就提示
typedef struct CMD_GR_HonorNotify 
{
	DWORD dwUserID; //用户id
	DWORD nHonorId; //成就id
    
	// 解开成就得到的奖励
	DWORD nGold; //金币
	DWORD nExp; //经验
	DWORD nPoint; //点数
}CMD_GR_HonorNotify;

// 修改称号
typedef struct CMD_GR_ChangeTitle 
{
	DWORD nHonorId; //成就编号
}CMD_GR_ChangeTitle;

// 修改昵称
typedef struct CMD_GR_NickName 
{
	TCHAR szNickName[NAME_LEN]; //用户昵称
}CMD_GR_NickName;

// 背包物品
typedef struct CMD_GR_BagItemInfo  
{
	DWORD dwGuid; //背包物品的GUID
	DWORD dwitemID; //道具编号
	INT   nCurTimeDuration; //获取当前剩余时间
	INT   nCurTimeCD; //当前冷却时间;
	INT   nUsedCount; //当前剩余次数
	WORD  wSlot; //在包裹中的位置
	WORD  wContainerSlot; //背包索引
	WORD  wStackCount; //堆叠个数
	BYTE  cbIsBinding; //是否已绑定
	BYTE  cbUsedFlag; //使用标识
}CMD_GR_BagItemInfo;

// 更新背包道具
typedef struct CMD_GR_UpdateItems
{
	BYTE  cbDirty;     //标识1-更新/2-删除/3-添加
	DWORD dwGuid;      //背包物品的GUID
	DWORD dwitemID;    //道具编号
	INT   nCurTimeDuration; //获取当前剩余时间
	INT   nCurTimeCD; //当前冷却时间;
	INT   nUsedCount; //当前剩余次数
	WORD  wSlot;      //在包裹中的位置
	WORD  wContainerSlot; //背包索引
	WORD  wStackCount; //堆叠个数
	BYTE  cbIsBinding; //是否已绑定
	BYTE  cbUsedFlag;  //使用标识
}CMD_GR_UpdateItems;

typedef struct SMD_GR_ShopItem 
{
	DWORD dwItemId;    //物品id
	DWORD dwSellPrice; //当前价格
	DWORD dwOffPrice;  //打折价格
	LONG  lSendGold;   //获赠金币
	BYTE  cbKeepTime;
	/*
     BYTE  cbMoneyType; //金币类型
     BYTE  cbShopType;  //商店类型
     BYTE  cbHot;       //热卖
     BYTE  cbNew;       //新品
     */
	BYTE cbFlag;
}SMD_GR_ShopItem;

#define ADORN_MAX_TYPE 10
// 更新装备
typedef struct CMD_GR_UpdateEquipReq
{
	INT  nItems[ADORN_MAX_TYPE]; //使用物品GID列表
	WORD wContainerSlot; //背包索引
}CMD_GR_UpdateEquipReq;

// 删除背包物品请求
typedef struct CMD_GR_DelItemReq
{
	DWORD dwGuid; //背包物品的GUID
	WORD  wCount; //删除物品的个数 0--表示全部删除
}CMD_GR_DelItemReq;

// 购买装备请求
typedef struct CMD_GR_BuyAvatarReq 
{
	DWORD dwItemID[ADORN_MAX_TYPE]; //物品ID
	WORD  wBuyCount[ADORN_MAX_TYPE]; //购买数量
	BYTE  cbShopID[ADORN_MAX_TYPE]; //商店编号
	BYTE  cbUsed; //是否购买立即使用，0-不使用，1-使用
}CMD_GR_BuyAvatarReq;

// 购买道具
typedef struct  CMD_GR_BuyItemReq
{
	DWORD dwItemID; //道具id
	WORD  wItemCount; //数量
	BYTE  cbShopID; //商店编号
	BYTE  cbUsed; 
}CMD_GR_BuyItemReq;

//物品续费
typedef struct CMD_GR_PayItemsReq
{
	DWORD dwGuid[ADORN_MAX_TYPE]; //道具Guid
	WORD  wItemCount[ADORN_MAX_TYPE]; //数量
}CMD_GR_PayItemsReq;

//续费返回
typedef struct CMD_GR_PayItemsResp 
{
	WORD  wError;   //错误码
	DWORD lCrystal; //使用点券
	DWORD lGold;    //使用金币
}CMD_GR_PayItemsResp;


// 购买返回
typedef struct CMD_GR_Response 
{
	WORD wError; //错误码
}CMD_GR_Response;


// 使用道具
typedef struct  CMD_GR_UsedItemReq
{
	DWORD dwGuid; //道具guid
}CMD_GR_UsedItemReq;

// 使用物品返回
typedef struct CMD_GR_HandleItemResp 
{
	WORD  wError; //错误码
	WORD  wFlag; //当前操作 0-使用物品，1-删除物品
	DWORD nItemId; //物品的id
}CMD_GR_HandleItemResp;

// 更新装饰数据
typedef struct UpdateAdornDataNotify
{
	WORD dwAdornData[ADORN_MAX_TYPE]; //装饰物数据
}UpdateAdornDataNotify;

//领奖请求
typedef struct CMD_GR_CampaignRewardsReq
{
	DWORD dwCampaignID;//活动id
}CMD_GR_CampaignRewardsReq;
//领奖返回
typedef struct CMD_GR_CampaignRewardsResp
{
	DWORD dwCampaignID;//活动id
	WORD wError; //错误码 0-成功/1-已领取过了/2-活动已结束/3-没有该活动/4-条件不满足
	WORD wLeftCount; //剩余次数
}CMD_GR_CampaignRewardsResp;

//提示领取每日奖励
typedef struct CMD_GR_DailyAwardsNotify
{
	BYTE	cbMaxCount;			//最大领取次数
	BYTE	cbTodayCount;		//今日可领取次数
	BYTE	cbLeftCount;		//剩余领取次数
}CMD_GR_DailyAwardsNotify;

//领取每日奖励请求
typedef struct DailyAwards
{
	BYTE  cbReqType;//标识
}DailyAwards;

//领奖返回
typedef struct DailyAwardsResult
{
	BYTE	cbReqType;
	BYTE	cbMaxCount;			//最大领取次数
	BYTE	cbTodayCount;		//今日可领取次数
	BYTE	cbLeftCount;		//剩余领取次数
	WORD	wError; //成功标识 --0:成功/1当天已经领完/2活动关闭
	DWORD	dwGold; //金币数量
}DailyAwardsResult;

// 防沉迷信息


// 游戏设置
typedef struct  CMD_GR_GameSet
{
	INT nSetValue[MAX_GAMESET_LEN];
}CMD_GR_GameSet;

//兑换金币请求
typedef struct CMD_GR_ExchangeGoldReq 
{
	DWORD lCrystal;//需要兑换的点券数量
}CMD_GR_ExchangeGoldReq;

//兑换金币返回
typedef struct CMD_GR_ExchangeGoldResp 
{
	WORD  wError;//错误码 0-成功/1-点券不够/-不能兑换
	DWORD lGold; //兑换获得的金币
}CMD_GR_ExchangeGoldResp;

//兑换礼券请求
typedef struct  CMD_GR_GiftExchangeReq
{
	TCHAR szSerialNo[50]; //序列号。随机生成，数字和字母结合
}CMD_GR_GiftExchangeReq;

//兑换礼券返回
typedef struct  CMD_GR_GiftExchangeResp
{
	WORD   wError;       //错误码
	LONG   lGold;        //包含金币
	DWORD  dwItemList[5];//包含物品
	WORD   wItemCount[5];//物品对应数量
}CMD_GR_GiftExchangeResp;

// 补偿提示
typedef struct CMD_GR_ExpiationNotify
{
	TCHAR szSchemeName[50]; //方案名称
	TCHAR szReason[512];    //补偿原因
	//TCHAR szContents[1024]; //补偿内容
}CMD_GR_ExpiationNotify;

// 游戏中补充金币
typedef struct CMD_GR_AddGoldInGame
{
	LONG lGold;
}CMD_GR_AddGoldInGame;

// 排行榜
typedef struct CMD_GR_RankList
{
	BYTE cbRankType;//排行榜类型:金币1/等级2/胜率3/成就4/好友5
}CMD_GR_RankList;

// 查询玩家排行榜
typedef struct  CMD_GR_RankQueryReq
{
	DWORD dwUserID; //用户id
	TCHAR szUserNick[NAME_LEN];//玩家昵称
}CMD_GR_RankQueryReq;

// 查询返回
typedef struct CMD_GR_RankQueryResp
{
	WORD  wError;//0-成功/1-玩家不存在/2-没有排行记录
	WORD  wRankType[RANK_TYPE_LEN];
	DWORD dwRankValue[RANK_TYPE_LEN];
	DWORD dwRankPlace[RANK_TYPE_LEN];
	DWORD dwLastPlace[RANK_TYPE_LEN];
	DWORD dwLastWeekPlace[RANK_TYPE_LEN];
	TCHAR szAccounts[NAME_LEN];//玩家帐号
}CMD_GR_RankQueryResp;

//Buffer
typedef struct CMD_GR_Buffer 
{
	DWORD dwUserID;
	WORD  wBufferCount;
}CMD_GR_Buffer;

//玩家连续登录次数
typedef struct CMD_GR_LOGON_AWARD 
{
	DWORD dwKeepLogonDays;		//连续登陆天数
	DWORD dwGold[6];		    //金币奖励级别
	DWORD dwGiftPoint[6];		//点券奖励级别
}CMD_GR_LOGON_AWARD;

//领取连续登录的奖励
typedef struct CMD_GR_GET_LOGON_AWARD_RESULT
{
	BYTE cbGetResult;		//非0则错误
	DWORD dwGold;
	DWORD dwGiftPoint;	
}CMD_GR_GET_LOGON_AWARD_RESULT;

typedef struct CMD_GR_Remit
{
	DWORD dwDestUserID;
	DWORD dwRemitGold;
}CMD_GR_Remit;

typedef struct CMD_GR_RemitResult
{
	WORD  wError;
	DWORD dwRemitGold;
}CMD_GR_RemitResult;
//////////////////////////////////////////////////////////////////////////

// 连续登录抽奖----------------------------------------------------

typedef struct CMD_GR_NEW_LOGON_INFO
{
	BYTE		cbMaxGetCount;		//最大获取次数
	BYTE		cbCanGetCount;		//剩余获取次数
}CMD_GR_NEW_LOGON_INFO;

#define MAX_LOGON_AWARD_NUM	4		//最多抽取四次
//请求领奖
typedef struct CMD_GR_NEW_LOGON_GET_REQ
{
	BYTE		cbGetIndex[MAX_LOGON_AWARD_NUM-1];		//已经获取到的奖励索引
}CMD_GR_NEW_LOGON_GET_REQ;

typedef struct CMD_GR_NEW_LOGON_GET_RESULT
{
	BYTE		cbMaxGetCount;		//最大获取次数
	BYTE		cbCanGetCount;		//剩余获取次数
	BYTE		cbResult;			//是否领取成功，0-成功，>0领取失败
	BYTE		cbAwardIndex;		//奖品索引值
}CMD_GR_NEW_LOGON_GET_RESULT;

//------------------------------------------------------------------

// 开福袋 ----------------------------------------------------------

typedef struct CMD_GR_OPEN_FUDAI
{
	BYTE		cbOpenType;			//打开类型
}CMD_GR_OPEN_FUDAI;


//==================================================================
//end
//Sparrow 游戏部分注释
//////////////////////////////////////////////////////////////////////////
//公共宏定义


#define GAME_GENRE					(GAME_GENRE_SCORE|GAME_GENRE_MATCH|GAME_GENRE_GOLD)	//游戏类型
#define GAME_MODE                   (GM_ENTER_SITDOWN|GM_FULLSIT)       //游戏模式

//游戏状态
#define GS_MJ_FREE					GS_FREE								//空闲状态
#define GS_MJ_PLAY					(GS_PLAYING+1)						//游戏状态

//常量定义

#define MAX_HUA						8									//最大花的个数
#define MAX_WEAVE					4									//最大组合
#define MAX_INDEX					42									//最大索引
#define MAX_COUNT					14									//最大数目
#define MAX_REPERTORY				144									//最大库存
#define LOCKED_COUNT				0									//空16张不能摸
#define MAX_RIGHT_COUNT				3									//最大权位DWORD个数

#define DISCARD_COUNT				60									//最多记录多少个丢弃的牌

#define MAX_FAN_HINT                24                                  //大番提示

//////////////////////////////////////////////////////////////////////////

//组合子项
typedef struct CMD_WeaveItem
{
	BYTE							cbWeaveKind;						//组合类型
	BYTE							cbCenterCard;						//中心扑克
	BYTE							cbPublicCard;						//公开标志
	WORD							wProvideUser;						//供应用户
}CMD_WeaveItem;

//=========================================================================
#define LOG_BEGIN	'B'		//游戏开始，后接一张牌两个字节，共MAX_REPERTORY*2个字节
#define LOG_SEND	'F'		//发牌：椅子，牌
#define LOG_OUT		'O'		//出牌：椅子，牌
#define LOG_CHI		'C'		//吃：椅子，牌
#define LOG_PENG	'P'		//碰：椅子，牌
#define LOG_GANG	'G'		//杠：椅子，牌
#define LOG_TING	'T'		//听：椅子
#define LOG_HUA		'H'		//补花：椅子，花牌，补牌
#define LOG_QUIT	'Q'		//放弃：椅子
#define LOG_END		'E'		//游戏结束：0-胡牌，1-流局，椅子
#define LOG_AUTO	'A'		//自动处理
#define LOG_MAX_SIZE 2048	//最大记录长度

//////////////////////////////////////////////////////////////////////////
//服务器命令结构

#define SUB_S_GAME_START			100									//游戏开始
#define SUB_S_OUT_CARD				101									//出牌命令
#define SUB_S_SEND_CARD				102									//发送扑克
#define SUB_S_LISTEN_CARD			103									//听牌命令
#define SUB_S_OPERATE_NOTIFY		104									//操作提示
#define SUB_S_OPERATE_RESULT		105									//操作命令
#define SUB_S_GAME_END				106									//游戏结束
#define SUB_S_TRUSTEE				107									//用户托管
#define SUB_S_MOVIE_END				108									//客户端动画结束
#define SUB_S_SWITCH_CHAIR			109									//交换椅子
#define SUB_S_RULE_TEST_RESP 		110									//测试结果
#define SUB_S_GET_AWARD				112									//获得奖励
#define SUB_S_CONTINUE_GAME         113                                 //继续游戏
#define SUB_S_TRYAGAIN_GAME         114                                 //游戏结束继续
#define SUB_S_EXPOSURE_CARD         115                                 //亮牌
#define SUB_S_EXPOSURE_END          116                                 //亮牌结束
#define SUB_S_SWAP_CARD             117                                 //使用换牌卡
#define SUB_S_SWAP_RESULT           118                                 
#define SUB_S_CHIHU_CARD            119                                 //吃胡扑克
#define SUB_S_NOT_CHIHU             120                                 //
#define SUB_S_USER_LEFT             121                                 //用户退出
#define SUB_S_EXIT_GAME             125                                 //离开游戏
#define SUB_S_DEBUG					199									//调试信息命令

//测试结果
typedef struct  CMD_S_RuleTest
{
	DWORD                           dwChiHuKind;
	DWORD							dwChiHuRight[3];		//胡牌类型
}CMD_S_RuleTest;

//换牌失败
typedef struct CMD_S_ResultSelect
{
	DWORD                           dwItemID;                           //
	//失败标示0-成功/1-金币不足/2-牌不够换/3-使用达到上限/4-补花/5-非当前用户/6-换的牌没有/7-已经听牌/8没有听牌/9-吃碰杠不能换
	BYTE							cbResult;						    
	LONG                            lLastScore;                         
}CMD_S_ResultSelect;

//换牌结束
typedef struct CMD_S_ChangeCard
{
	BYTE                            cbSendCardData;
	BYTE							cbUserAction;								//用户动作
	BYTE                            cbOperateCard;                              //操作扑克
	BYTE							cbCardCount;								//扑克数目
	BYTE							cbCardData[MAX_COUNT];						//扑克列表
}CMD_S_ChangeCard;


//游戏状态
typedef struct CMD_S_StatusFree
{
	LONG							lCellScore;							//基础金币
	WORD							wBankerUser;						//庄家用户
	bool							bTrustee[GAME_PLAYER];				//是否托管
	BYTE							cbGameStep;							//游戏步骤
	LONG                            lMaxUseGold;
}CMD_S_StatusFree;

//游戏状态
typedef struct CMD_S_StatusPlay
{
	//游戏变量
	LONG							lCellScore;									//单元积分
	WORD							wSiceCount;									//骰子点数
	WORD							wBankerUser;								//庄家用户
	WORD							wCurrentUser;								//当前用户
    
	//状态变量
	BYTE							cbActionCard;								//动作扑克
	BYTE							cbActionMask;								//动作掩码
	BYTE							cbHearStatus[GAME_PLAYER];					//听牌状态
	BYTE							cbLeftCardCount;							//剩余数目
	BYTE							cbBuhuaCardCount;							//补牌区数量
	bool							bTrustee[GAME_PLAYER];						//是否托管
    
	//出牌信息
	WORD							wOutCardUser;								//出牌用户
	BYTE							cbOutCardData;								//出牌扑克
	BYTE							cbDiscardCount[GAME_PLAYER];				//丢弃数目
	BYTE							cbDiscardCard[GAME_PLAYER][60];				//丢弃记录
    
	//扑克数据
	BYTE							cbCardCount;								//扑克数目
	BYTE							cbCardData[MAX_COUNT];						//扑克列表
	BYTE							cbSendCardData;								//发送扑克
	WORD							cbSendCardUser;								//发送对象
	BYTE							cbEnjoinGangCard[5];						//
	BYTE							cbEnjoinGangCount;							//
    
	//组合扑克
	BYTE							cbWeaveCount[GAME_PLAYER];					//组合数目
	CMD_WeaveItem					WeaveItemArray[GAME_PLAYER][MAX_WEAVE];		//组合扑克
    
	BYTE							cbZhangCard[GAME_PLAYER];					//
    
	//堆立信息
	WORD							wHeapHand;									//堆立头部
	WORD							wHeapTail;									//堆立尾部
	BYTE							cbHeapCardInfo[GAME_PLAYER][2];				//堆牌信息
    
	//花
	BYTE							huaItemCount[GAME_PLAYER];					//花数目
	BYTE							huaItemArray[GAME_PLAYER][MAX_HUA];		//花的数组
    
	WORD							wZhuangTimes;							// 连庄次数
	BYTE							cbTaiArray[GAME_PLAYER];				//座位东南西北信息	
	BYTE							cbDoorDirection[GAME_PLAYER];			//门风
	BYTE							cbQuan;									//圈序
	BYTE                            cbMultiple;                             //当前倍数
    
	LONG							lTotalScore[GAME_PLAYER];					//当前总的累计得分
	LONG                            lSwapScore;                         //奖金
	LONG                            lMaxUseGold;                         //使用金币上限
	LONG                            lLastGold;                         //每局已经使用道具的金币
	BYTE							cbGameStep;							//游戏步骤
}CMD_S_StatusPlay;

//游戏开始
typedef struct CMD_S_GameStart
{
	WORD							wSiceCount;									//骰子点数
	WORD							wBankerUser;								//庄家用户
	WORD							wCurrentUser;								//当前用户
	BYTE							cbUserAction;								//用户动作
	BYTE							cbCardData[MAX_COUNT];						//扑克列表
	bool							bTrustee[GAME_PLAYER];						//是否托管
	WORD							wHeapHand;									//堆立牌头
	WORD							wHeapTail;									//堆立牌尾
	BYTE							cbHeapCardInfo[GAME_PLAYER][2];				//堆立信息
    
    
	WORD							wZhuangTimes;							// 连庄次数
	BYTE							cbTaiArray[GAME_PLAYER];				//座位东南西北信息
	BYTE							cbDoorDirection[GAME_PLAYER];			//门风，每局开始时决定，从哪个方向开始抓牌，该方向就是门风东
	BYTE							cbQuan;									//圈序
	BYTE                            cbMultiple;                             //当前倍数
}CMD_S_GameStart;

//动画结束命令
typedef struct CMD_S_MovieEnd
{
	BYTE                            cbSwapCard;                         //换牌标识
}CMD_S_MovieEnd;

//出牌命令
typedef struct CMD_S_OutCard
{
	WORD							wOutCardUser;						//出牌用户
	BYTE							cbOutCardData;						//出牌扑克
}CMD_S_OutCard;

//发送扑克
typedef struct CMD_S_SendCard
{
	BYTE							cbCardData;							//扑克数据
	BYTE							cbActionMask;						//动作掩码
	WORD							wCurrentUser;						//当前用户
	WORD							bHua;								//是否是补花
	bool							bTail;								//末尾发牌
	bool							bFromGang;							//是否是因为杠牌
}CMD_S_SendCard;


//听牌命令
typedef struct CMD_S_ListenCard
{
	WORD							wListenUser;						//听牌用户
}CMD_S_ListenCard;


//操作提示
typedef struct CMD_S_OperateNotify
{
	WORD							wResumeUser;						//还原用户
	BYTE							cbActionMask;						//动作掩码
	BYTE							cbActionCard;						//动作扑克
}CMD_S_OperateNotify;

//操作命令
typedef struct CMD_S_OperateResult
{
	WORD							wOperateUser;						//操作用户
	WORD							wProvideUser;						//供应用户
	BYTE							cbOperateCode;						//操作代码
	BYTE							cbOperateCard;						//操作扑克
}CMD_S_OperateResult;

//听牌提示命令
typedef struct CMD_S_ListenNotify
{
	BYTE cbAbandonCard[MAX_COUNT];										//可丢弃牌
	BYTE cbTingCard0[MAX_COUNT][MAX_COUNT-1];							//听牌扑克
	BYTE cbTingCard1[MAX_COUNT][MAX_COUNT-1];						    //听牌扑克
	BYTE cbChiHuRank0[MAX_COUNT][MAX_COUNT-1];                          //对应的吃胡番数
	BYTE cbChiHuRank1[MAX_COUNT][MAX_COUNT-1];                          //对应的吃胡番数
}CMD_S_ListenNotify;

//游戏结束
typedef struct CMD_S_GameEnd
{
	LONG							lGameTax;							//游戏税收
	//结束信息
	WORD							wProvideUser;						//供应用户
	BYTE							cbProvideCard;						//供应扑克
	bool							bEnd;								//是否全部结束 (BOOL是int，4个字节)
	DWORD							dwChiHuKind[GAME_PLAYER];			//胡牌类型
	DWORD							dwChiHuRight[GAME_PLAYER][MAX_RIGHT_COUNT];		//胡牌类型
	BYTE							cbDynamicFanCount;					//数量
	BYTE							cbDynamicFanType[5];				//动态番型
	BYTE							cbDynamicFanValue[5];				//对应番数
    
	//积分信息
	LONG							lGameScore[GAME_PLAYER];			//游戏积分
	LONG							lTotalGameScore[GAME_PLAYER];		//总的游戏积分
	BYTE							cbDianGang[GAME_PLAYER];			//
	BYTE							cbAnGang[GAME_PLAYER];				//
    
	//扑克信息
	BYTE							cbCardCount[GAME_PLAYER];			//扑克数目
	BYTE							cbCardData[GAME_PLAYER][MAX_COUNT];	//扑克数据
    
	BYTE							cbZhangCard[GAME_PLAYER];			//
	BYTE							cbEndReason[GAME_PLAYER];
    
	bool							bLevelUp[GAME_PLAYER];				//是否升级
	WORD							wAddExp[GAME_PLAYER];				//增加的经验
	LONG                            lSwapScore;                         //奖金
}CMD_S_GameEnd;


typedef struct playGameIng
{
    DWORD							dwUserID[GAME_PLAYER];
	WORD							wChairID[GAME_PLAYER];   
}playGameIng;


#define MAX_CHAIR_NORMAL    9
//交换座位
typedef struct CMD_GR_SwitchChair
{
	DWORD							dwUserID[MAX_CHAIR_NORMAL];
	WORD							wChairID[MAX_CHAIR_NORMAL];
}CMD_GR_SwitchChair;



typedef struct CMD_S_SwitchChair
{
	DWORD							dwSice;
	WORD							wNewChair[GAME_PLAYER];
}CMD_S_SwitchChair;

//用户托管
typedef struct CMD_S_Trustee
{
	bool							bTrustee;							//是否托管
	WORD							wChairID;							//托管用户
}CMD_S_Trustee;

typedef struct CMD_S_GetAward
{
	DWORD							dwUserID;							//用户编号
	LONG							lAwardValue;						//奖励的值(金币、点券数量，物品ID)
	LONG							lAwardFlag;							//附加值，如几个物品
	BYTE							cbAwardType;						//类型
	TCHAR							szAwardDesc[128];					//描述信息
}CMD_S_GetAward;

typedef struct CMD_S_Response
{
	WORD							wChairID;							//用户
}CMD_S_Response;

//亮牌
typedef struct CMD_S_ExposureCard
{
	WORD							wChairID;							//用户
	BYTE							cbCardData[MAX_COUNT];				//扑克列表
}CMD_S_ExposureCard;

//换牌结束
typedef struct CMD_S_SwapCardEnd 
{
	WORD                            wSwapCount[GAME_PLAYER];           //每人换牌次数
	LONG                            lTotalScore;                       //总奖金
}CMD_S_SwapCardEnd;

typedef struct CMD_S_Debug
{
	WORD							wCurrentUser;					//当前用户
	WORD							wResumeUser;					//恢复用户
	WORD							wProvideUser;					//供应用户
	BYTE							cbUserAction[GAME_PLAYER];		//用户动作
	bool							bResponse[GAME_PLAYER];			//用户响应
	BYTE							cbGameStep;						//游戏状态
	CHAR							LogBuffer[LOG_MAX_SIZE];		//游戏记录
}CMD_S_Debug;

//番数不够
typedef struct CMD_S_NotChiHu
{
	BYTE cbCanChihu;//不能胡
	BYTE cbCurrCard;//当前扑克
	WORD wCurrFans; //当前番数
}CMD_S_NotChiHu;

//玩家退出
typedef struct CMD_S_UserLeft
{
	WORD							wLeftUser;							//
}CMD_S_UserLeft;

//////////////////////////////////////////////////////////////////////////
//客户端命令结构

#define SUB_C_OUT_CARD				1									//出牌命令
#define SUB_C_LISTEN_CARD			2									//听牌命令
#define SUB_C_OPERATE_CARD			3									//操作扑克
#define SUB_C_TRUSTEE				4									//用户托管
#define SUB_C_DING_ZHANG			5									//
#define	SUB_C_MOVIE_END				6									//动画结束
#define SUB_C_SWITCH_END			7									//交换座位结束
#define SUB_C_DEBUG_CARD			8									//测试命令，想要哪张摸哪张
#define SUB_C_RULE_TEST_REQ   	    9									//测试命令
#define SUB_C_CONTINUE_GAME         10                                  //每小节结束继续游戏
#define SUB_C_TRYAGAIN_GAME         11                                  //游戏结束继续
#define SUB_C_EXPOSURE_CARD         12                                  //亮牌
#define SUB_C_EXPOSURE_END          13                                  //亮牌结束
#define SUB_C_SWAP_CARD			    14									//使用换牌卡
#define SUB_C_USER_LEFT             16                                  //用户退出
#define SUB_C_DEBUG					99									//客户端调试命令

//测试命令
typedef struct CMD_C_RuleTest
{
	BYTE							cbCardData[14];				//扑克数据
	BYTE							cbWeaveKind[4];				//组合类型
	BYTE							cbCenterCard[4];			//中心扑克
	BYTE							cbPublicCard[4];			//公开标志
	BYTE                            cbZimo;                     //自摸标识
	BYTE                            cbDoorDirection;            //圈风  
	BYTE                            cbQuan;                     //圈风
	BYTE                            cbHuCard;                   //吃胡牌
}CMD_C_RuleTest;

//换牌命令
typedef struct CMD_C_ChangeCard
{
	DWORD                           dwItemID;
	bool                            bSendCard;                          //是否发的牌
	BYTE							cbCardCount;						//扑克数据
	BYTE							cbCardData[MAX_COUNT];				//扑克数据
}CMD_C_ChangeCard;

//出牌命令
typedef struct CMD_C_OutCard
{
	BYTE							cbCardData;							//扑克数据
}CMD_C_OutCard;

//操作命令
typedef struct CMD_C_OperateCard
{
	BYTE							cbOperateCode;						//操作代码
	BYTE							cbOperateCard;						//操作扑克
}CMD_C_OperateCard;

//用户托管
typedef struct CMD_C_Trustee
{
	bool							bTrustee;							//是否托管	
}CMD_C_Trustee;



//////////////////////////////////////////////////////////////////////////

// 累计数据的类型
//enum enExtraType
//{
//	enExtraType_Cihu, // 胡牌次数
//	enExtraType_Zimo, // 自摸次数
//	enExtraType_Tai,  // 总的台数
//	enExtraType_UserItem, // 使用物品记录--暂时没有使用
//	enExtraType_HolidayWinCount,				//节日期间赢的次数
//};

// 累计数据的类型
enum enExtraType
{
	enExtraType_Chihu = 1 + 100, // 胡牌次数
	enExtraType_Zimo, // 自摸次数
	enExtraType_Tai,  // 总的台数
	enExtraType_Qiang,// 放枪次数
	enExtraType_TotalWinGolds, //总共赢了多少金币
	enExtraType_UserItem, // 使用物品记录--暂时没有使用
	enExtraType_FriendsMasterBonus,				//好友场桌主拿奖励
	enExtraType_HolidayWinCount,				//节日期间赢的次数
};

enum enGameAct
{
	enCampaignFriendTai		= 1 + KIND_ID*1000,			//密友增加台数
	enCampaignFriendMaster,								//好友场结束后，桌主增加奖励
	enCampaignHoliday,									//节日活动
	enCampaignAddFans,                                  //活动一、番数增加，赢钱更犀利
	enCampaignAddGold,                                  //活动四、积分有“礼”，胡牌得金币
	enCampaignGetItemOnEnd,								//一轮结束时赠送奖品
	enCampaignGirlAddFan,								//女性加番
	enCampaignBachelor,                                 //光棍节
};

// 任务类型
enum enAssiConditionType
{
	enAssiConditionType_HuCount	= 1 + KIND_ID * 1000,//胡牌次数:胡牌达到一定次数
	enAssiConditionType_ZimoCount,			//自摸次数:自摸达到一定次数
	enAssiConditionType_QiangCount,			//放枪次数:放枪达到一定次数
	enAssiConditionType_TaiCount,			//胡牌台/番数:一次胡到多少台/番
	enAssiConditionType_BigFan,				//胡大牌:胡到一定值或以上的牌型
	enAssiConditionType_Fan,				//胡指定牌型:胡到指定牌型
	enAssiConditionType_GameEnd,			//正常结束游戏:结束游戏，并且不是因为自己离线、没钱
	enAssiConditionType_ServerLevel,		//获胜场所:在某个馆获得一场胜利
	enAssiConditionType_OnlyFriends,		//好友馆获胜
};


#define EXP_ADD_WIN			10					//赢一局增加经验值
#define EXP_ADD_LOST		0					//输一局增加经验值
#define EXP_ADD_DRAW		3					//和一局增加经验值
#define EXP_ADD_BASE		5					//计算公式中的基础值


#define RP_ADD				2				//每正常结束一场，增加0.2分
#define RP_DEC				10			//非正常结束，扣1分 

#define BASE_SCORE          8

enum CARD_TYPE
{
	CARD_TYPE_SWAP,
	CARD_TYPE_GOOD,
	CARD_TYPE_CHANGE,
	CARD_TYPE_ZIMO,
};


//乾坤大挪移 : 游戏开始前使用，得到一手好牌
#define QIANKUN_DANUOYI_ITEM_ID     2000007
#define QIANKUN_DANUOYI_YUANBAO     20
//瞒天过海:没有吃碰杠的时候换全部牌
#define MANTIAN_GUOHAI_ITEM_ID      2000006
#define MANTIAN_GUOHAI_YUANBAO      10
//移花接木:将手中的牌换成随机一张牌
#define YIHUA_JIEMU_ITEM_ID         2000008
#define YIHUA_JIEMU_YUANBAO         5
//妙手空空:听牌后重新摸一张牌
#define MIAOSHOU_KONGKONG_ITEM_ID   2000009
#define MIAOSHOU_KONGKONG_YUANBAO   10


#define MAX_CHANGE_YUANBAO             20                            //元宝上限



#endif

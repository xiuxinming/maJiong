//
//  Cmd.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月1日.
//  Copyright (c) 2012年 Yuan. All rights reserved.
//

#ifndef HappyMahjong_Cmd_h
#define HappyMahjong_Cmd_h
 
#import "SocketDef.h"



//静态常量================================================================
//麻将管
#define Majong4Number    4
#define Majong4PuTong    0
#define Majong4fan3      1
#define Majong4fan5      2
#define Majong4fan8      3



#define WORD_SIZE		 2
#define DWORD_SIZE		 4  //双字的字节数
#define	RUN_AT_LOCAL	 false	//是否运行在本地
#define	IS_DEBUG		 false	//是否调试版本
        
//长度宏定义
#define NAME_LEN		 32			//用户名长度
#define TITLE_LEN		 32			//用户称号长度
#define PASS_LEN		 33			//密码长度
#define PASS_LEN_FULL	 36			//对齐后的密码长度
#define MODULE_LEN		 32			//进程长度
#define GROUP_LEN    32  //社团名字
#define UNDER_WRITE_LEN    32  //社团名字
//性别定义
#define GENDER_BOY						 1									//男性性别
#define GENDER_GIRL						 0									//女性性别


//////////////////////////////////////////////////////////////////////////
//登录数据包定义

#define MDM_GR_LOGON				1									//房间登录

#define SUB_GR_LOGON_ACCOUNTS		1									//帐户登录
#define SUB_GR_LOGON_USERID			2									//I D 登录

#define SUB_GR_LOGON_SUCCESS		100									//登录成功
#define SUB_GR_LOGON_ERROR			101									//登录失败
#define SUB_GR_LOGON_FINISH			102									//登录完成
#define MAX_TABLE_OPTIONS 6						//桌子最大属性

#define MAX_MAIL_TITLE              32     //邮件标题长度
#define MAX_MAIL_CONTENT            512    //邮件内容长度
#define MAX_PAGE_SIZE               10     //每一页邮件的数量
#define RANK_TYPE_LEN               12     //排行榜类型数量

//内核命令码
#define MDM_KN_COMMAND					0									//内核命令
#define SUB_KN_DETECT_SOCKET			1									//检测命令
#define SUB_KN_SHUT_DOWN_SOCKET			2									//中断网络

enum TABLE_OPTION
{
	TABLE_OPTION_SCENE = 0,		//场景
	TABLE_OPTION_GOLD,			//底和台
	TABLE_OPTION_QUAN,			//几圈结束
	TABLE_OPTION_SPEED,			//出手速度
	TABLE_OPTION_RULE,			//规则，常规或见字见花
	TABLE_OPTION_ALLFRIEND,		//所有人都是好友
	TABLE_OPTION_FANS,          //起胡番数
	TABLE_OPTION_FIXED,			//是否定额
	TABLE_OPTION_PARAM,         //备用
	TABLE_OPTION_TEN,			//备用
	TABLE_OPTION_MAX,			//总数，共8个
};



enum enGameSetValueType
{
	enGameSetValueType_None   = 0,                                      //保留位
	enGameSetValueType_Regsiter,                                        //注册赠送
	enGameSetValueType_Spreader,                                        //推荐奖励
	enGameSetValueType_UnAppDaily,                                      //未认证用户每日补足
	enGameSetValueType_AppDaily,                                        //认证用户每日补足
	enGameSetValueType_MsgMax,                                          //人人网,FaceBook最多可发消息数
	enGameSetValueType_Value6,                                          //未使用
	enGameSetValueType_GoldRate,                                        //点券兑换金币的比例
	enGameSetValueType_Font,                                            //0表示简体，1表示繁体
	enGameSetValueType_Fcm,                                             //防沉迷标识
	enGameSetValueType_ExpireTime,                                      //注册送衣服过期时间天
	enGameSetValueType_UserAdult,                                       //所有用户成年标识
	enGameSetValueType_GoldSupply,                                      //游戏中补给金币
	enGameSetValueType_GiveClothingOnReg,								//注册时是否赠送服装
	enGameSetValueType_CurrVersion,										//当前版本
	enGameSetValueType_LeastVersion,									//最小可用版本
	GAMESET_SPREADER_GIFTPOINT,											//推荐人可获得多少礼券
	GAMESET_MAX_ANDROID,												//最多读进多少机器人
	enGameSetValueType_Remit,                                           //汇款功能
	enGameSetValueType_SaveConsumeScore,								//是否保存金币变更记录
	enGameSetValueType_SaveChat,										//是否保存聊天信息
	enGameSetValueType_UseAssiModule,									//使用任务模块
	enGameSetValueType_SendMailOfHonor,									//获得成就时是否发送邮件通知
	enGameSetValueType_CanUseGameItem,									//是否可以使用游戏道具
	enGameSetValueType_SpecialSceneID,									//特定的场景
	enGameSetValueType_EveryDayLostGold,								//每天输赢金币上限
	MAX_GAMESET_LEN = 50,												//游戏设置总数量
};

enum enClientType
{
	ClientType_Normal,
	ClientType_Flash,
	ClientType_HTML5,
	ClientType_IOS,
	ClientType_Android
};


//////////////////////////////////////////////////////////////////////////
//用户数据包定义

#define MDM_GR_USER					2									//用户信息

#define SUB_GR_USER_SIT_REQ			1									//坐下请求
#define SUB_GR_USER_LOOKON_REQ		2									//旁观请求
#define SUB_GR_USER_STANDUP_REQ		3									//起立请求
#define SUB_GR_USER_LEFT_GAME_REQ	4									//离开游戏
#define SUB_GR_USER_SIT_SEARCH_REQ	5									//自动配桌    // by csk
#define SUB_GR_USER_INFO			6									//请求用户信息
#define SUB_GR_USER_FAST_SIT_REQ    7                                   //快速配桌


#define SUB_GR_USER_COME			100									//用户进入
#define SUB_GR_USER_STATUS			101									//用户状态
#define SUB_GR_USER_SCORE			102									//用户分数
#define SUB_GR_SIT_FAILED			103									//坐下失败
#define SUB_GR_USER_RIGHT			104									//用户权限
#define SUB_GR_MEMBER_ORDER			105									//会员等级
#define SUB_GR_SWITCH_CHAIR			106									//交换座位


#define SUB_GR_USER_CHAT			200									//聊天消息
#define SUB_GR_USER_WISPER			201									//私语消息
#define SUB_GR_USER_RULE			202									//用户规则

#define SUB_GR_USER_INVITE			300									//邀请消息
#define SUB_GR_USER_INVITE_REQ		301									//邀请请求

//默认快速配桌信息
#define  TABLE_OPTION_SCENE		 0			//场景
#define TABLE_OPTION_GOLD		 1			//底和台


#define TABLE_OPTION_QUAN		 2			//几圈结束
#define TABLE_OPTION_SPEED		 3			//出手速度
#define TABLE_OPTION_RULE		 4			//规则，常规或见字见花
#define TABLE_OPTION_ALLFRIEND	 5
#define TABLE_OPTION_FANS		 6
#define TABLE_OPTION_EMPTY		 7


//----------------------------------------------------------------------------------------------
// by xuxiangqian 2010-04-15

// 好友系统服务器端统一用于用户操作请求的错误码
#define SUB_GR_USER_RESULT          410                                 //返回错误码

// 好友系统
#define	SUB_GR_FRIENDLIST		    400								    //好友列表   
#define SUB_GR_FRIEND_ADD_REQ       402                                 //添加好友请求
#define SUB_GR_FRIEND_DEL_REQ       403                                 //删除好友

//连续登录
#define SUB_GR_KEEP_LOGON_AWARD     404   //连续登录次数
#define SUB_GR_GET_LOGON_AWARD      405   //领取奖励
#define SUB_GR_GET_LOGON_AWARD_RESULT 406 //领奖返回

#define SUB_GR_USER_INVITECOUNT     407   //邀请人数

// 邮件系统 -- 通信协议
#define SUB_GR_UNREAD_MAIL          419                                 //未读邮件数量
#define SUB_GR_GETMAIL_REQ          420                                 //获取邮件列表
#define SUB_GR_GETMAIL_RESP         421                                 //获取邮件列表返回
#define SUB_GR_GETMAIL_LIST         422                                 //邮件列表
#define SUB_GR_MAIL_PRIVATE         423                                 //用户之间邮件：包括发送和接收
#define SUB_GR_MAIL_RESULT          424                                 //返回发送邮件结果
#define SUB_GR_GETCONTENT           425                                 //读取邮件内容
#define SUB_GR_GETCONTENT_RESULT    426                                 //获取邮件内容返回
#define SUB_GR_MAIL_SYSTEM          427                                 //系统邮件
#define SUB_GR_MAIL_SYSGM           428                                 //GM邮件
#define SUB_GR_REMOVE_MAIL          429                                 //删除邮件
#define SUB_GR_REMOVE_MAIL_RESULT   430                                 //删除邮件返回

#define SUB_GR_MATCH_INFO			440									//活动信息
#define SUB_GR_MATCH_BONUS			441									//活动奖金更新
#define SUB_GR_MATCH_SELF_INFO		442									//自己在活动中的名次信息

// 成就
#define SUB_GR_HONOR_NOTIFY         450                                 //用户解开成就的提示
#define SUB_GR_MODIFY_TITLE         451                                 //用户修改了当前称号
#define SUB_GR_UPDATE_BAG_NOTIFY	 452									//物品加入到背包 --- 服务端发给客户端

// 背包物品
#define SUB_GR_UPDATE_ITEMS         453                                 //更新背包道具
#define SUB_GR_USE_AVATAR_REQ       454                                 //玩家使用物品请求
#define SUB_GR_DEL_ITEM_REQ         455                                 //删除物品
#define SUB_GR_HANDLE_ITEM_RESP     456                                 //处理物品返回
#define SUB_GR_LOAD_BAG_REQ         457                                 //打开背包请求读取背包物品
#define SUB_GR_BAG_LIST             458                                 //背包物品列表
#define SUB_GR_UPDATE_EQUIP         459                                 //更新装饰物数据

// 商店装备
#define SUB_GR_SHOP_ITEM_LIST       460                                 //商店物品列表
#define SUB_GR_BUY_AVATAR_REQ       461                                 //购买装备请求
#define SUB_GR_BUY_ITEM_RESP        462                                 //购买返回

// 礼物
#define SUB_GR_SEND_GIFT_REQ        463                                 //赠送物品
#define SUB_GR_SEND_GIFT_RESP       464                                 //赠送物品返回
#define SUB_GR_GIFT_LIST            465                                 //显示礼物
#define SUB_GR_GIFT_GET_REQ         466                                 //收取礼物
#define SUB_GR_GIFT_GET_RESP        467                                 //收取礼物返回
#define SUB_GR_GIFT_THROW_REQ       468                                 //丢弃礼物
#define SUB_GR_GIFT_THROW_RESP      469                                 //丢弃礼物返回
#define SUB_GR_GIFT_LIST_RESP       470                                 //显示礼物返回
#define SUB_GR_GIFT_COUNT           471                                 //礼物数量

// 道具
#define SUB_GR_BUY_ITEM_REQ         472                                 // 购买道具
#define SUB_GR_USE_ITEM_REQ         473                                 // 使用道具
#define SUB_GR_PAY_ITEM_REQ         474                                 // 续费
#define SUB_GR_PAY_ITEM_RESP        475                                 // 续费返回
//-----------------------------------------------------------------------------------------------

//礼券
#define SUB_GR_GIFT_EXCHANGE_REQ    480                                 //兑换礼券请求
#define SUB_GR_GIFT_EXCHANGE_RESP   481                                 //兑换礼券结果

//补偿
#define SUB_GR_EXPIATION_NOTIFY     482                                 //提示用户获得补偿 

//领取当日奖励
#define SUB_GR_TAKE_GOLD_NOTIFY     483                                 //提示玩家领奖
#define SUB_GR_TAKE_GOLD_REQ        484                                 //玩家领奖请求
#define SUB_GR_TAKE_GOLD_RESP       485                                 //玩家领奖返回

#define SUB_GR_CAMPAIGN_QUERY_REQ        486                            //查询活动
#define SUB_GR_CAMPAIGN_QUERY_RESP       487                            //返回结果

#define SUB_GR_CAMPAIGN_REWARDS_REQ      488                            //领取奖励
#define SUB_GR_CAMPAIGN_REWARDS_RESP     489                            //领取奖励返回


#define SUB_GR_CAMPAIGN_NEW_LOGON_INFO	490								//新的连续登录奖励
#define SUB_GR_CAMPAIGN_NEW_LOGON_GET	491								//新的连续登录请求领取及返回


#define SUB_GR_EXCHANGE_GOLD_REQ         500                            //兑换金币
#define SUB_GR_EXCHANGE_GOLD_RESP        501                            //兑换金币返回

#define SUB_GR_GAME_SET      		     502                            //游戏设置

#define SUB_GR_GAME_CHENMI      		 503                            //防沉迷

#define SUB_GR_ADDGOLD_INGAME      		 504                            //游戏里补充金币

// 排行榜
#define SUB_GR_RANK_LIST_REQ             505                            //排行榜请求
#define SUB_GR_RANK_LIST_RESP            506                            //排行榜返回
#define SUB_GR_RANK_QUERY_REQ            507                            //排行榜查询请求
#define SUB_GR_RANK_QUERY_RESP           508                            //排行榜查询返回

// Buffer
#define SUB_GR_USER_BUFFER               509                            //玩家buffer

#define SUB_GR_MODIFY_USERNICK           510                            //修改昵称
#define SUB_GR_MODIFY_USERNICK_RESP      511                            //修改昵称返回

// 任务
#define SUB_GR_MISSION_LIST              512                            //任务列表
#define SUB_GR_ASSI_CONDITION            513                            //某个任务的条件已完成 --只有一些特定的任务才由客户端提交完成请求
#define SUB_GR_ASSI_CONDITION_RESP       514                            //返回
#define SUB_GR_MISSION_SUBMIT            515                            //用户提交已完成的某个任务,获得奖励
#define SUB_GR_MISSION_SUBMIT_RESP       516                            //提交任务返回
#define SUB_GR_MISSION_FINISH            517                            //发送任务完成信息

#define SUB_GR_REMIT                     520                            //汇款
#define SUB_GR_REMIT_RESULT              521                            //汇款返回

#define SUB_GR_SYNC_REQUEST              523                            //请求同步个人数据

//////////////////////////////////////////////////////////////////////////
//配置信息数据包

#define MDM_GR_INFO					3									//配置信息

#define SUB_GR_SERVER_INFO			100									//房间配置
#define SUB_GR_ORDER_INFO			101									//等级配置
#define SUB_GR_MEMBER_INFO			102									//会员配置
#define SUB_GR_COLUMN_INFO			103									//列表配置
#define SUB_GR_CONFIG_FINISH		104									//配置完成

//////////////////////////////////////////////////////////////////////////
//房间状态数据包

#define MDM_GR_STATUS				4									//状态信息

#define SUB_GR_TABLE_INFO			100									//桌子信息
#define SUB_GR_TABLE_STATUS			101									//桌子状态
#define SUB_GR_NEW_TABLE			102									//新桌子

#define TABLE_SEND_COUNT				8						//每次发送多少桌子信息
//////////////////////////////////////////////////////////////////////////
//管理数据包

#define MDM_GR_MANAGER				5									//管理命令

#define SUB_GR_SEND_WARNING			1									//发送警告
#define SUB_GR_SEND_MESSAGE			2									//发送消息
#define SUB_GR_LOOK_USER_IP			3									//查看地址
#define SUB_GR_KILL_USER			4									//踢出用户
#define SUB_GR_LIMIT_ACCOUNS		5									//禁用帐户
#define SUB_GR_SET_USER_RIGHT		6									//权限设置
#define SUB_GR_OPTION_SERVER		7									//房间设置
#define SUB_GR_KILL_ALL_USER		8									//踢出所有用户
#define SUB_GR_SHOW_KNOCKOUT		9									//查看淘汰赛信息

//设置标志
#define OSF_ROOM_CHAT				1									//大厅聊天
#define OSF_GAME_CHAT				2									//游戏聊天
#define OSF_ROOM_WISPER				3									//大厅私聊
#define OSF_ENTER_GAME				4									//进入游戏
#define OSF_ENTER_ROOM				5									//进入房间
#define OSF_SHALL_CLOSE				6									//即将关闭




//////////////////////////////////////////////////////////////////////////////////////////////
//淘汰赛命令
#define MDM_GR_KNOCKOUT				6									//淘汰赛

#define SUB_GR_KNOCKOUT_LIST			1								//比赛列表
#define SUB_GR_KNOCKOUT_INFO    		2								//报名人数更新
#define SUB_GR_KNOCKOUT_ENTER			3								//报名
#define SUB_GR_KNOCKOUT_ENTER_RESULT    4                               //报名返回
#define SUB_GR_KNOCKOUT_EXIT			5								//退出报名
#define SUB_GR_KNOCKOUT_EXIT_RESULT     6                               //退出报名返回
#define SUB_GR_KNOCKOUT_RANKLIST        7                               //玩家列表
#define SUB_GR_KNOCKOUT_RANKING			8								//排名变化
#define SUB_GR_KNOCKOUT_UPDATE			9								//比赛信息更新
#define SUB_GR_KNOCKOUT_BEGIN			10								//开始比赛
#define SUB_GR_KNOCKOUT_FINAL			11								//自己的最终排名
#define SUB_GR_KNOCKOUT_BASESCORE       12                              //基数变化
#define SUB_GR_KNOCKOUT_AWARDLIST       13                              //奖励列表
#define SUB_GR_KNOCKOUT_WAIT            14                              //等待
#define SUB_GR_KNOCKOUT_STEP            15                              //游戏状态改变
#define SUB_GR_KNOCKOUT_RECONNECT       16                              //中途进入
#define SUB_GR_KNOCKOUT_DISMISS         17                              //游戏解散
#define SUB_GR_KNOCKOUT_SCORE           18                              //积分变化

//struct tagKnockout
//{
//	DWORD			dwGameID;				//比赛ID
//	TCHAR			szGameName[50];			//名称
//	TCHAR           szGameDesc[250];        //描述
//	BYTE			cbGameType;				//比赛类型，是随时报名还是固定时间开始
//	BYTE			cbDateType;				//日期类型，每天、每周、每月
//	INT				nBeginTime;				//每天第一场的开始时间，-1表示没有
//	INT				nEndTime;				//每天最后一场的开始时间
//	DWORD			dwIntervalTime;			//2==GameType时表示间隔时间。3==GameType时表示开始时间
//	DWORD			dwEntryFee;				//报名费用，金币。
//	DWORD			dwEntryItemID;			//报名道具ID。
//	DWORD           dwItemNum;              //道具数量
//	DWORD			dwEntryFee2;			//报名费用，金币。
//	DWORD			dwEntryItemID2;			//报名道具ID。
//	DWORD           dwItemNum2;             //道具数量
//	DWORD			dwInitScore;			//初始积分
//	DWORD			dwInitScore2;			//初始积分
//	DWORD           dwInitBaseScore;        //游戏基数
//	WORD			wMinPlayer;				//最少报名人数
//	WORD            wFinalsNum;             //决赛人数
//	BYTE			cbPreSystem;			//预赛赛制
//	BYTE			cbFinalsSystem;			//决赛赛制
//	BYTE			cbPreRound;				//预赛轮数
//	BYTE			cbFinalsRound;			//决赛轮数
//	BYTE            cbPreSection;           //预赛每轮局数
//	BYTE            cbFinalsSection;        //决赛每轮局数
//	INT				nGameFlag[4];			//游戏附加数据
//};
//
////淘汰赛奖励
//struct KnockoutAward 
//{
//	DWORD dwGameID;
//	WORD  wTopLevelID;//最高名次
//	WORD  wBottomLvID;//最低名次
//	DWORD dwAwardExp;//奖励经验
//	DWORD dwAwardGold;//奖励金币
//	DWORD dwAwardGiftPoint;//奖励礼券
//	DWORD dwAwardItemID;//奖励物品
//	WORD  wItemNum;//物品数量
//	INT   nItemKeepSeconeds;//物品有效期
//	TCHAR szOtherAwardName[128];//其他奖励名称
//};
//
////当前报名人数和时间
//struct CMD_GR_KnockInfo
//{
//	DWORD dwGameID;
//	DWORD dwPlayerCount;//报名人数
//	DWORD dwElapse; //多少时间后开始
//};
//
////报名
//struct CMD_GR_KnockRegister
//{
//	DWORD dwGameID;
//	bool  bBuy;//直接购买
//	BYTE  cbOptions;//报名方案 0--第一种方案/2-第二种方案
//};
//
////退出报名
//struct CMD_GR_KnockoutExit
//{
//	DWORD			dwGameID;
//};
//
////报名结果
//struct CMD_GR_KnockoutEntryResult
//{
//	DWORD			dwResult;				//0为成功
//	DWORD			dwGameID;
//	DWORD			dwCurrPlayer;			//当前人数
//};
//
////报名结果
//struct CMD_GR_KnockoutExitResult
//{
//	DWORD			dwResult;				//0为成功
//	DWORD			dwGameID;
//};
//
//struct CMD_GR_KnockoutBaseScore
//{
//	DWORD			dwGameID;
//	DWORD			dwBaseScore;			//游戏基数
//};
//
//struct CMD_GR_KnockUpdate
//{
//	DWORD dwGameID;
//	DWORD dwBaseScore;	 //游戏基数
//	DWORD dwUserCount;   //用户数量
//	DWORD dwNextRoundPlayerCount;
//	BYTE  cbCurrRound;   //当前轮数
//	BYTE  cbCurrSection; //当前局数
//};
//
////中途进入
//struct CMD_GR_KnockReConnect 
//{
//	DWORD dwGameID;
//	DWORD dwGroupID;
//	DWORD dwBaseScore;   //游戏基数
//	DWORD dwBeginTime;   //开始时间
//	DWORD dwPlayerCount;
//	DWORD dwNextRoundPlayerCount;		//下一阶段人数
//	BYTE  cbCurrRound;   //当前轮数
//	BYTE  cbCurrSection; //当前局数
//	BYTE  cbStep;        //0-预赛 1-决赛
//	bool  bPlay;//是否牌局中
//};
//
//struct CMD_GR_KnockoutStep 
//{
//	DWORD dwGameID;
//	BYTE  cbStep;//0-预赛 1-决赛
//	BYTE  cbStartOrEnd;//0开始 1结束
//};
//
//struct CMD_GR_KnockUserScore 
//{
//	DWORD dwUserID;
//	LONG  lScore;
//};
//
////排名变化。比赛开始时，通过此命令发送列表。过程中，通过此命令维护列表
//struct CMD_GR_KnockoutScoreRank
//{
//	DWORD			dwUserID;			
//	LONG			lScore;			//积分
//	WORD			wRank;			//名次
//	bool			bActive;	    //是否活动。false表示已淘汰
//	TCHAR           szUserNick[NAME_LEN];//名称
//};
//
////比赛等待中
//struct CMD_GR_KnockoutWait 
//{
//	DWORD	dwGameID;
//	bool	bWaitApplyTable;		//是否等待分配桌子
//	bool	bPreEnd;				//预赛是否即将结束
//};
//
////自己的最终排名及奖项
//struct CMD_GR_KnockoutFinal
//{
//	DWORD			dwGameID;
//	DWORD			dwUserID;
//	DWORD			dwAwardGold;		//金币奖金
//	DWORD			dwAwardGiftPoint;	//礼券奖金
//	DWORD			dwAwardExp;			//奖励经验
//	DWORD			dwAwardItemID;		//奖品
//	INT             nItemKeepSeconeds;//物品有效期
//	BYTE			cbAwardItemCount;	//奖品数量
//	bool            bActive;            //0-淘汰
//	WORD			wRanking;			//最终名次
//	LONG            lScore;             //最终积分
//	TCHAR           szOtherAwardName[128];//其他奖励名称
//};
//
////游戏解散
//struct CMD_GR_KnockoutDismiss
//{
//	WORD  wError;//错误码 1人数不足
//	DWORD dwGameID;
//};
//
//////////////////////////////////////////////////////////////////////////
//系统数据包

#define MDM_GR_SYSTEM				10									//系统信息

#define SUB_GR_MESSAGE				100									//系统消息
#define SUB_GR_UPLOAD_LOG			101									//上传客户端当时的情况
#define SUB_GR_LEAVEROOM			102									//通知客户端离开此房间

//消息类型
#define SMT_INFO					0x0001								//信息消息
#define SMT_EJECT					0x0002								//弹出消息
#define SMT_GLOBAL					0x0004								//全局消息
#define SMT_CLOSE_ROOM				0x1000								//关闭房间
#define SMT_KNOCK                   0x2000                              //淘汰赛信息
#define SMT_INTERMIT_LINE			0x4000								//中断连接

//游戏列表命令码
#define MDM_GP_SERVER_LIST				2								//列表信息
#define SUB_GP_LIST_TYPE				 100								//类型列表
#define SUB_GP_LIST_KIND				 101								//种类列表
#define SUB_GP_LIST_STATION				 102								//站点列表
#define SUB_GP_LIST_SERVER				 103							//房间列表
#define SUB_GP_LIST_FINISH				 104								//发送完成
#define SUB_GP_LIST_CONFIG				 105								//列表配置

//////////////////////////////////////////////////////////////////////////
//房间数据包

#define MDM_GR_SERVER_INFO			11									//房间信息

#define SUB_GR_ONLINE_COUNT_INFO	100									//在线信息
#define SUB_GR_LIST_TYPE			101									//类型列表
#define SUB_GR_LIST_KIND			102									//种类列表
#define SUB_GR_LIST_STATION			103									//站点列表
#define SUB_GR_LIST_SERVER			104									//房间列表
#define SUB_GR_LIST_FINISH			105									//发送完成
#define SUB_GR_LIST_CONFIG			106									//列表配置

// 错误码，所有错误码定义，统一管理
enum __Global_Error_Define__
{
	Error_NoError                  = 0x00,                               //成功
	Error_FriendIsFull,                                                  //好友数量达到上线
	Error_EnemyIsFull,                                                   //黑名单数量达到上线
	Error_UserHasExist,                                                  //好友/黑名单用户已经存在
	Error_AddUserFail,                                                   //添加好友/黑名单失败
	Error_DelUserFail,                                                   //删除好友/黑名单失败
	Error_UserIsOffline,                                                 //用户不在线
	Error_UserNotExist,                                                  //用户不存在
	Error_AddUserUnKnow,                                                 //未知关系：添加时候不是加好友也不是加黑名单
	Error_DelUserUnKnow,                                                 //未知关系：删除时候不在好友也不是黑名单中
	Error_NoPermit,                                                      //权限不够/对方设置了权限不允许任何人加好友
	Error_Unknow,                                                        //未知错误
	Error_Version,														//版本错误
    
	//邮件相关错误码  从20开始
	Error_IsEmptyTitle              = 0x14,                              //邮件标题为空
	Error_TitleTooLong,                                                  //邮件标题太长
	Error_IsEmptyText,                                                   //邮件内容为空
	Error_TextTooLong,                                                   //邮件内容太长
	Error_RecvUserNotExist,                                              //收件人不存在
	Error_MailNotExist,                                                  //邮件不存在
	Error_MailIDError,                                                   //参数错误
	Error_MailNoPermit,                                                  //邮件不属于该用户
	Error_MailWriteFail,                                                 //邮件写入db失败
    
	//用户坐下处理错误码 -- SUB_GR_SIT_FAILED
	Error_SetException              = 0x1E,                              //游戏设置异常 30
	Error_LevelNotEnough,                                                //等级不够
	Error_RPNotEnough,                                                   //RP不够
	Error_InPlaying,                                                     //你正在的 [ %d ] 号游戏桌游戏，暂时不能离开位置
	Error_NoVacancies,                                                   //暂时没有能够加入的游戏桌，请稍后
	Error_UnLookOn,                                                      //本房间限制了旁观游戏
	Error_IsDetestNotEnter,                                              //你是该桌玩家的黑名单用户，不能进入游戏
	Error_IsDetestNotLook,                                               //你是该桌玩家的黑名单用户，不能进入旁观
	Error_InDetestNotEnter,                                              //该桌玩家是你的黑名单用户，不能进入游戏
	Error_InDetestNotLook,                                               //该桌玩家是你的黑名单用户，不能进入旁观
	Error_IsShallClose,                                                  //由于此游戏房间即将暂停服务，玩家不允许再进入游戏桌
	Error_IsMatchNoBegin,                                                //活动还没有开始
	Error_NotAllowEnterGame,                                             //抱歉，此游戏桌现在不允许玩家进入
	Error_HadPlaying,                                                    //椅子已经被人捷足先登了，下次动作要快点了
	Error_GameStarted,                                                   //游戏已经开始了，暂时不能进入游戏桌
	Error_IsGameOver,                                                    //游戏已经结束了，不能进入游戏桌
	Error_NotMatchUser,                                                  //这是游戏比赛房间，你不是比赛选手，不能坐到此位置上
	Error_CheckSameIP,                                                   //你设置了不跟相同 IP 地址的玩家游戏，此游戏桌存在与你 IP 地址相同的玩家，不能加入游戏
	Error_TableSameIPPlay,                                               //此桌设置了不跟相同 IP 地址的玩家游戏，此游戏桌存在与你 IP 地址相同的玩家，不能加入游戏
	Error_DisSameIPPlay,                                                 //你设置了不跟相同 IP 地址的玩家游戏，此游戏桌存在 IP 地址相同的玩家，不能加入游戏
	Error_MatchFinish,                                                   //恭喜您，您的比赛局数已经完成了，不需要再继续比赛，请耐心等待赛果公布
	Error_NotRight,                                                      //抱歉，你没有进行游戏的权限，若需要帮助，请联系游戏客服咨询
	Error_CoinNotEnough,                                                 //您的金币不够，不能加入
	Error_ScoreNotEnough,                                                //您的积分不够，不能加入
	Error_CoinIsMore,                                                    //您的金币超过本房间的最大限制额度,请更换游戏房间
	Error_ScoreIsMore,                                                   //您的游戏积分超过本房间的最大限制额度,请更换游戏房间
	Error_PasswordIsWrong,                                               //密码错误，不能加入游戏
	Error_EscapeRateHigh,                                                //你的逃跑率太高，不能加入游戏
	Error_WinRateLow,                                                    //你的胜率太低，，不能加入游戏 
	Error_NoUserLook,                                                    //所请求旁观的位置已经没有玩家了，不能旁观
	Error_GameNotStartLook,                                              //游戏还没有开始，暂时不能旁观
	Error_IsOverLook,                                                    //游戏已经结束，不能旁观  61
	Error_TableFull,													 //桌子坐满了
	Error_RoomFull,														 //房间满了
	Error_ChairError,                                                    //位置错误
	Error_ChipNotEnough,                                                 //筹码不足
    
	// 背包物品相关
	Error_BagNotExist             = 0x46,                                //背包不存在
	Error_ItemNotExist,                                                  //物品不存在
	Error_ItemTemplateNotExit,                                           //物品原型不存在
	Error_SlotError,                                                     //物品位置不对
	Error_HasOverDue,                                                    //物品已经过期
	Error_HadBinding,                                                    //物品已经绑定了不能使用
	Error_ItemNotEnough,                                                 //物品数量不够
	Error_BagIsFull,                                                     //背包已满
	Error_EquipNotMatch,                                                 //装备不匹配
	Error_SlotInvalid,                                                   //位置非法
    
	// 商店系统
	Error_GoodsNotEnough          = 0x50,                                //商品数量不足
	Error_GoldNotEnough,                                                 //金币不足
	Error_CrystalNotEnough,                                              //点券不足
	Error_ServerBusy,                                                    //服务器忙
	Error_GoodsIsNone,                                                   //商品已经售完
    
	// 礼物
	Error_GiftNotExist,                                                  //礼物不存在
	Error_NotFriend,                                                     //对方不是好友
	Error_NotRemove,                                                     //不能删除
    
	Error_ItemBeUsed,                                                    //物品已经使用了
	Error_ScorePositive,                                                 //积分为正，不能使用负分清零
	Error_RPPositive,                                                    //牌品大于50不需要使用
	Error_NotOverDue,                                                    //没有过期
	Error_NotBuyVipItem,                                                 //非会员不能购买VIP物品
};

enum enOperate
{
	enOperate_Add,                                                       //添加操作
	enOperate_Del                                                        //删除操作
};


//邮件类型
enum EM_MAIL_TYPE
{
	EM_MAIL_PRIVATE      = 0x00, //一对一私聊
	EM_MAIL_SYSTEM,              //系统邮件， 针对玩家发送的邮件
	EM_MAIL_GUILD,               //工会
};


//typedef struct tagCurrMatchInfo
//{
//	DWORD								dwMatchID;							//活动编号
//	BYTE								cbMatchType;						//活动类型
//	DWORD								dwBeginTime;						//开始时间
//	DWORD								dwKeepTime;							//持续时间
//	BYTE								cbGoldLevel;						//台番级别
//	BYTE								cbSpeedLevel;						//出手速度
//	WORD								wSceneID;							//场景编号
//	WORD								wNeedLevel;							//最低级别
//	DWORD								dwNeedGameRP;						//最低牌品
//	DWORD								dwNeedGold;							//最少金币
//	DWORD								dwGameFlag;							//附加选项
//	DWORD								dwTotalWinner;						//将有多少人获奖
//	WORD								wTimes;								//第几期
//    
//	DWORD								dwReallyBeginTime;					//实际开始时间
//	DWORD								dwAllServerGoldBonus;				//所有服务器累计奖金总额
//	DWORD								dwAllServerGiftPointBonus;			//所有服务器累计奖金总额
//	WORD								wMeRank;							//自己的排名
//	DWORD								dwMeScore;							//自己的分数
//	WORD								wRankList[4];						//名次列表，包括前三名，中间位置、最后位置各一名
//	DWORD								dwScoreList[4];						//积分列表
//	TCHAR								szUserNick[4][NAME_LEN];			//玩家姓名
//};
//
//struct tagCurrMatchBonus
//{
//	DWORD								dwMatchID;							//活动编号
//	DWORD								dwAllServerGoldBonus;				//所有服务器累计奖金总额
//	DWORD								dwAllServerGiftPointBonus;			//所有服务器累计奖金总额
//	WORD								wMeRank;							//自己的排名
//	DWORD								dwMeScore;							//自己的分数
//	WORD								wRankList[4];						//名次列表，包括前两名，中间位置、最后位置各一名
//	DWORD								dwScoreList[4];						//积分列表
//	TCHAR								szUserNick[4][NAME_LEN];			//玩家姓名
//};

enum USE_ITEM_FLAG
{
	USE_ITEM_FLAG_BUY   = 0x00,//购买物品返回
	USE_ITEM_FLAG_USE,         //使用物品返回
	USE_ITEM_FLAG_DEL,         //删除物品返回
};

#define GIFT_MSG_LEN    150
//// 赠送物品
//struct CMD_GR_SendGift 
//{
//	DWORD dwDestUserID;
//	DWORD dwItemID[ADORN_MAX_TYPE]; //物品ID
//	WORD  wBuyCount[ADORN_MAX_TYPE]; //赠送数量
//	BYTE  cbShopID; //商店编号
//	BYTE  cbAnonym; //是否匿名
//	TCHAR szMsg[GIFT_MSG_LEN]; //附带赠言
//};
//
//// 显示礼物
//struct tagGiftData
//{
//	DWORD dwGiftID; //礼物编号
//	DWORD dwSendUserID; //赠送者ID
//	TCHAR szSendUserNick[NAME_LEN]; //赠送者呢称
//	BYTE  bAnonym; //是否匿名赠送
//	DWORD dwSendTime; //赠送时间
//	TCHAR szMsg[GIFT_MSG_LEN]; //赠送消息
//};
//
//// 收取礼物
//struct CMD_GR_GetGift
//{
//	DWORD dwGiftID; //礼物ID
//};
//
//// 收取礼物返回
//struct CMD_GR_GetGiftResult
//{
//	WORD  wError; //收取结果
//	DWORD dwItemList[ADORN_MAX_TYPE]; //收取到的物品ID
//	LONG  lSendGold;//附带赠送金币
//};
//
//// 丢弃礼物
//struct CMD_GR_ThrowGift
//{
//	DWORD dwGiftID;	//礼物编号
//};
//
////发送礼物数量
//struct  CMD_GR_GiftCount
//{
//	DWORD dwGiftCount;//礼物数量
//};
//
//// 活动查询请求
//struct CMD_GR_CampaignQueryReq
//{
//	DWORD dwCampaignID[10];//活动id列表
//};
////活动查询结果
//struct CMD_GR_CampaignQueryResp
//{
//	DWORD dwCampaignID[10];//活动id列表
//	WORD  wError[10];//活动对应的结果列表 0-未领取/1-已领取/2-活动已结束/3-没有活动/4-条件不满足
//	WORD  wLeftCount[10];//剩余次数
//	BYTE  wRawType[10];  //奖励类型，1-金币，2-物品 
//	DWORD dwRawValue[10];//物品编号或者金币数量
//};


//用户任务结构
#define ASSI_MAX_REQUIRE			3						//最大触发条件数
#define ASSI_MAX_CONDITION			4						//最大条件数
#define ASSI_MAX_ITEM				3						//最大奖品数

//IPC 网络事件
#define IPC_MAIN_SOCKET					 1								//网络消息
#define IPC_SUB_SOCKET_SEND				 1								//网络发送
#define IPC_SUB_SOCKET_RECV				 2								//网络接收


#define MDM_GF_GAME					 100								//游戏消息
#define MDM_GF_FRAME				 101								//框架消息
#define MDM_GF_PRESENT				 102								//礼物消息
#define MDM_GF_BANK					 103								//银行消息

#define SUB_GF_INFO						 1								//游戏信息
#define SUB_GF_USER_READY				 2								//用户同意
#define SUB_GF_LOOKON_CONTROL			 3								//旁观控制
#define SUB_GF_KICK_TABLE_USER			 4								//踢走用户
#define SUB_GF_START_BY_MASTER			 5							//桌主开始

#define SUB_GF_OPTION					 100								//游戏配置
#define SUB_GF_SCENE					 101								//场景信息

#define SUB_GF_USER_CHAT				 200								//用户聊天

#define SUB_GF_MESSAGE					 300								//系统消息

#define SUB_GF_BANK_STORAGE				 450								//银行存储
#define SUB_GF_BANK_GET					 451								//银行提取

#define SUB_GF_FLOWER_ATTRIBUTE			 500								//鲜花属性

#define SUB_GF_FLOWER					 501								//鲜花消息
#define SUB_GF_EXCHANGE_CHARM			 502								//兑换魅力

#define SUB_GF_PROPERTY					 550								//道具消息
#define SUB_GF_PROPERTY_RESULT			 551								//道具结果
#define SUB_GF_RESIDUAL_PROPERTY		 552								//剩余道具
#define SUB_GF_PROP_ATTRIBUTE			 553								//道具属性





//默认信息
#define DTP_NULL					0								//无效数据

//基础信息
//基础信息
#define DTP_USER_ID					1								//用户 I D
#define DTP_GAME_ID					2								//用户 I D
#define	DTP_USER_ACCOUNTS			3								//用户帐号
#define	DTP_USER_PASS				4								//用户密码
#define DTP_USER_GENDER				5								//用户性别
#define DTP_USER_FACE				6								//用户头像
#define DTP_USER_RIGHT				7								//用户权限
#define DTP_MASTER_RIGHT			8								//管理权限
#define	DTP_UNDER_WRITE				9								//个性签名
#define	DTP_LOVE_LINESS				10								//用户魅力
#define DTP_USER_NICK				11								//用户昵称

#define DTP_SOCIAL_URI				12
#define DTP_SOCIAL_URL_FIELD		13								//第三方调用URL参数

//状态信息
#define DTP_USER_STATUS				100								//用户状态
#define DTP_USER_TABLE				101								//游戏桌号
#define DTP_USER_CHAIR				102								//椅子号码
#define DTP_USER_PING				103								//网络延时
#define DTP_USER_INDEX				104								//用户索引
#define DTP_USER_ROUND				105								//循环计数
#define DTP_LOOK_ON_USER			106								//旁观玩家

//积分信息
#define DTP_USER_WIN				200								//胜局盘数
#define DTP_USER_LOST				201								//输局盘数
#define DTP_USER_DRAW				202								//和局盘数
#define DTP_USER_FLEE				203								//逃局盘数
#define DTP_WIN_RATE				204								//用户胜率
#define DTP_LOST_RATE				205								//用户输率
#define DTP_DRAW_RATE				206								//用户和率
#define DTP_FLEE_RATE				207								//用户逃率
#define DTP_USER_TAX				208								//用户税收
#define DTP_INSURE_SCORE			209								//存储金币
#define DTP_GAME_GOLD				210								//游戏金币
#define DTP_USER_SCORE				211								//用户分数
#define DTP_USER_PLAY_COUNT			212								//总局盘数
#define DTP_USER_EXPERIENCE			213								//用户经验
#define DTP_GAME_LEVEL				214								//游戏等级
#define DTP_COMMUNITY_LEVEL			215								//社区等级

//扩展信息
#define DTP_USER_GROUP_ID			300								//社团 I D
#define DTP_USER_GROUP_NAME			301								//社团名字
#define DTP_USER_NOTE				302								//用户备注
#define DTP_USER_DESCRIBE			303								//用户描述
#define DTP_USER_COMPANION			304								//用户关系

//系统信息
#define DTP_COMPUTER_ID				1000							//机器序列
#define DTP_STATION_PAGE			1001							//站点页面
#define DTP_OPTION_BUFFER			1002							//配置信息

        
#endif

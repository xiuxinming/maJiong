//
//  GameLevel\.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月11日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SocketDef.h"
#import "SocketHelper.h"
#import "Cmd.h"
#import "GameManager.h"
#import "GameConfig.h"
#import "MainMenuLayer.h"
#import "GameLayer.h"
#import "MainLayer.h"

@interface GameLevel : CCLayer 
{
    
}


+(CCScene *) scene;

@end

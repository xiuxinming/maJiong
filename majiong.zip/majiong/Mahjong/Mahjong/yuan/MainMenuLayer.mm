//
//  MainMenuLayer.m
//  HappyMahjong
//
//  Created by Gao Yuan on 12年7月27日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import "MainMenuLayer.h"


@implementation MainMenuLayer






+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MainMenuLayer *layer = [MainMenuLayer node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}


- (id) init
{
    self = [super init];
    
    if (self != nil)
    {
        
        //test 1284
        short a = 0x0504;        //低位 4    //高位
        CCLOG(@"a======%d  %d  %d", a, a & 0xff, (a<<8) & 0xff);
        
        //test 登陆
        CCMenu *shopMenu;
        shopMenu = [CCMenu menuWithItems:nil, nil];
        CGSize screenSize = [CCDirector sharedDirector].winSize;    
        CCMenuItemImage *btBack = [CCMenuItemImage 
                                   itemFromNormalImage:@"Default.png" 
                                   selectedImage:@"Default.png"
                                   disabledImage:nil
                                   target:self
                                   selector:@selector(ButtonTest:)];
        btBack.position = ccp(screenSize.width/6,screenSize.height/4);
        btBack.scale = 0.2;
        [shopMenu addChild:btBack];
        
        
        
        
        
        CCMenuItemImage *GoLevel = [CCMenuItemImage 
                                   itemFromNormalImage:@"Default.png" 
                                   selectedImage:@"Default.png"
                                   disabledImage:nil
                                   target:self
                                   selector:@selector(ButtonGo:)];
        GoLevel.position = ccp(screenSize.width/3,screenSize.height/4);
        GoLevel.scale = 0.2;
        [shopMenu addChild:GoLevel];
        
        [self addChild:shopMenu];
        
        //最后初始化socket这里 前面初始化其他东西
        //链接如果请求失败则提示“网络链接异常”然后当玩家点击链接服务器时判断是否链接上服务器了
        //如果没有链接上服务器则继续提示 如果链接上了则发送链接请求
        int request = [[GameManager sharedGameManager] initSocket];
        if (request == ERROR)
        {
            //这里添加ALERT提示网络链接异常 现在测试简写为打印 可以用标志位设置 如果链接失败则提示
            CCLOG(@"init: initSocket error");
        }
        
       
        
        
    }
    
    return  self;
}

# pragma 测试

//test 登陆
-(void)ButtonTest:(CCMenuItemFont*)itemPassedIn
{
    
    
    CMD_GP_LogonByAccounts logon;
	memset(&logon, 0, sizeof(CMD_GP_LogonByAccounts));
	snprintf(logon.szAccounts, NAME_LEN, "eminetest1015");
	snprintf(logon.szPassWord, PASS_LEN, "96e79218965eb72c92a549dd5a330112");//密码需要MD5
	logon.dwPlazaVersion = CLIENT_VER;
    logon.wSocialID = WSOCIAlID;
    logon.cbPasswordType = 0;
    
    
    CCLOG(@"点击我了");
    
    [[GameManager sharedGameManager] SendData:MDM_GR_LOGON SubCmd:SUB_GR_LOGON_ACCOUNTS  arg:&logon len:sizeof(CMD_GP_LogonByAccounts)];
	
    // CCLOG(@"发送请求完成");
}

//进入gameLevel界面
- (void)ButtonGo:(CCMenuItemFont*)itemPassedIn
{
    
    [[CCDirector sharedDirector] replaceScene: [GameLevel scene]];
}





- (void)dealloc
{
     
    
    [super dealloc];
}

@end

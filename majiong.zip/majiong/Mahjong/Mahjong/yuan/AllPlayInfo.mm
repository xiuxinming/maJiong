//
//  AllPlayInfo.m
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月20日.
//  Copyright 2012年 etgame. All rights reserved.
//

#import "AllPlayInfo.h"


@implementation AllPlayInfo

@synthesize  dwUserID;
@synthesize  lLoveliness;
@synthesize  cbGender;
@synthesize  wTableID;  
@synthesize  wChairID;
@synthesize  cbUserStatus;
@synthesize  dwTitleID;
@synthesize  cbUserType;

@synthesize PlayerAccount;
@synthesize PlayerNickName;


+ (BOOL)addPlayer:(AllPlayInfo*) player
{
    assert(player != NULL);
    
    BOOL havePlayer = NO;
    int count = [[GameManager sharedGameManager].AllPlayerInfo count];
    
    
    //判断玩家是否已经在大厅了 如果在则更新最新信息 
    for (int i = 0; i < count; i++)
    {
        
        AllPlayInfo *oldPlayer = [[GameManager sharedGameManager].AllPlayerInfo objectAtIndex:i];
        
        if ( oldPlayer.dwUserID == player.dwUserID)
        {
             havePlayer = YES;
            [[GameManager sharedGameManager].AllPlayerInfo replaceObjectAtIndex:i  withObject:player];
            CCLOG(@"addPlayer:replace new player success");
            return YES;
        }
    }
    
    
    //玩家第一次进入大厅
    if (havePlayer == NO || count == 0)
    {
        
        [[GameManager sharedGameManager].AllPlayerInfo addObject:player];
        CCLOG(@"addPlayer:add new player success");
    }
    
    return YES;
    
}

//更新玩家信息 包括桌子 椅子 状态
+ (BOOL)updataPlayerInfo:(CMD_GR_UserStatus*) player
{
    assert(player != NULL);
    
    BOOL havePlayer = NO;
    int count = [[GameManager sharedGameManager].AllPlayerInfo count];
    
    
    for (int i = 0; i < count; i++)
    {
        
        AllPlayInfo *oldPlayer = [[GameManager sharedGameManager].AllPlayerInfo objectAtIndex:i];
        
        //找到此人 更新桌位
        if ( oldPlayer.dwUserID == player->dwUserID)
        {
            havePlayer = YES;
            oldPlayer.wTableID = player->wTableID;
            oldPlayer.wChairID = player->wChairID;
            oldPlayer.cbUserStatus = player->cbUserStatus;
            
            return YES;
        }
    }
    
    //没有找到玩家 不需要更新信息
    if (havePlayer == NO || count == 0)
    {
        
        CCLOG(@"updataPlayerInfo:have no player infomation");
        return NO;
    }
    
    return YES;
    
}


+ (DWORD)findByUserID:(DWORD)userID
{
    int count = [[GameManager sharedGameManager].AllPlayerInfo count];
    for (int i = 0; i < count; i++)
    {
        AllPlayInfo *oldPlayer = [[GameManager sharedGameManager].AllPlayerInfo objectAtIndex:i];
        if (oldPlayer.dwUserID == userID)
        {
           // CCLOG(@"find name by userID");
            return i;
        }
    }
    
    return -1;
}


+ (BOOL)removeByUserID:(DWORD)userID;
{
    int count = [[GameManager sharedGameManager].AllPlayerInfo count];
    for (int i = 0; i < count; i++)
    {
        AllPlayInfo *oldPlayer = [[GameManager sharedGameManager].AllPlayerInfo objectAtIndex:i];
        if (oldPlayer.dwUserID == userID)
        {
            [[GameManager sharedGameManager].AllPlayerInfo removeObjectAtIndex:i];
            return YES;
        }
    }
    
    return NO;
}


- (id) init
{   
    
    self = [super init];
    
    if(self != nil)
    {
        dwUserID = 0;
        lLoveliness = 0;
        cbGender = 0;
        wTableID = 0;
        wChairID = 0;
        cbGender = 0;
        cbUserStatus = 0;
        cbUserType = 0;
    }
    
    return self;
}


- (void)dealloc
{
    
    [PlayerNickName release];
    [PlayerAccount release];
    [super dealloc];
}

@end

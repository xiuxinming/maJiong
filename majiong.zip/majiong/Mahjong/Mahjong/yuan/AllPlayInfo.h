//
//  AllPlayInfo.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年8月20日.
//  Copyright 2012年 etgame. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "SocketDef.h"
#import "GameManager.h"






//用户的基本信息要一直更新 保持最新信息  添查删找
@interface AllPlayInfo : NSObject 
{
    
    //用户基本信息
    DWORD        dwUserID;       //用户 I D
    LONG         lLoveliness;      //用户魅力                  用于开福袋的货币，玩游戏即可获得
    BYTE         cbGender;       //用户性别
    WORD         wTableID;       //桌子号码                    在哪张桌子上。65535(INVALID_TABLE)表示不在桌子上
    WORD         wChairID;       //椅子位置                    椅子编号。INVALID_CHAIR表示不在椅子上
    BYTE         cbUserStatus;      //用户状态                 见com\emine\qp\share\utils\GlobalDef.as中的US_XXX
    DWORD        dwTitleID;        //当前称号id                对应的成就ID
    BYTE         cbUserType;        //用户类型  0普通帐号 1机器人 2游客
    
    //账号
    NSString *PlayerAccount;
    
    //昵称
    NSString *PlayerNickName;
    
}

@property (nonatomic, assign) DWORD dwUserID;
@property (nonatomic, assign) LONG  lLoveliness;
@property (nonatomic, assign) BYTE  cbGender;
@property (nonatomic, assign) WORD  wTableID;  
@property (nonatomic, assign) WORD  wChairID;
@property (nonatomic, assign) BYTE  cbUserStatus;
@property (nonatomic, assign) DWORD dwTitleID;
@property (nonatomic, assign) BYTE  cbUserType;

@property (nonatomic, retain) NSString *PlayerAccount;
@property (nonatomic, retain) NSString *PlayerNickName;


//添加玩家基本信息
+ (BOOL)addPlayer:(AllPlayInfo*) player;

//替换玩家最新信息  替换之一：只包括用户的桌子号 椅子号 玩家状态 3个
+ (BOOL)updataPlayerInfo:(CMD_GR_UserStatus*) player;

//查找
+ (DWORD)findByUserID:(DWORD)userID;


//删除
+ (BOOL)removeByUserID:(DWORD)userID;
@end

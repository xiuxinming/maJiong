//
//  MainMenuLayer.h
//  HappyMahjong
//
//  Created by Gao Yuan on 12年7月27日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameManager.h"
#import "GameConfig.h"
#import "SocketDef.h"
#import "Cmd.h"
#import "GameLevel.h"

@interface MainMenuLayer : CCLayer 
{
    
}

+(CCScene *) scene;

@end

//
//  GameLayer.m
//  Mahjong
//
//  Created by etgame iphone on 12-8-23.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "GameLayer.h"


@implementation GameLayer

typedef enum {
    TAG_Table = 1,
} GameLayerTags;

+(id) scene
{
    CCScene *scene = [CCScene node];
    CCLayer *layer = [GameLayer node];
    [scene addChild:layer];
    
    return scene;
}

-(id) init
{
    if (self = [super init]) {//手牌
        [GameManager sharedGameManager].delegate = self;
        
        CCSprite *table = [CCSprite spriteWithFile:@"table.png"];
        [self addChild:table z:0 tag:TAG_Table];
        table.position = CGPointMake(512, 240);
        
        for (int i=0; i<13; i++) {
            CCSprite *tile = [CCSprite spriteWithFile:[NSString stringWithFormat:@"tile_main_0_%d.png", i%9+1]];
            [self addChild:tile z:13];
            tile.position = CGPointMake(267+i*42, 71);
            
            CCSprite *tileup = [CCSprite spriteWithFile:@"tile_up.png"];
            [self addChild:tileup z:2];
            tileup.position = CGPointMake(655-i*24, 428);
            
            CCSprite *tileleft = [CCSprite spriteWithFile:@"tile_left.png"];
            [self addChild:tileleft z:(2+i)];
            tileleft.position = CGPointMake(202-i*12, 378-i*12);
            
            CCSprite *tileright = [CCSprite spriteWithFile:@"tile_right.png"];
            [self addChild:tileright z:(13-i)];
            tileright.position = CGPointMake(980-i*12, 206+i*12);
        }
        
        for (int i=0; i<18; i++) {//牌山
        
            CCSprite *tileMain1 = [CCSprite spriteWithFile:@"tile_main_in.png"];
            [self addChild:tileMain1 z:1];
            tileMain1.position = CGPointMake(718-i*24, 180);
            
            CCSprite *tileMain2 = [CCSprite spriteWithFile:@"tile_main_in.png"];
            [self addChild:tileMain2 z:2];
            tileMain2.position = CGPointMake(718-i*24, 191);
            
            CCSprite *tileUp1 = [CCSprite spriteWithFile:@"tile_up_in.png"];
            [self addChild:tileUp1 z:1];
            tileUp1.position = CGPointMake(357+i*19, 354);
            
            CCSprite *tileUp2 = [CCSprite spriteWithFile:@"tile_up_in.png"];
            [self addChild:tileUp2 z:2];
            tileUp2.position = CGPointMake(357+i*19, 365);
            
            CCSprite *tileLeft1 = [CCSprite spriteWithFile:@"tile_left_in.png"];
            [self addChild:tileLeft1 z:1+18-i];
            tileLeft1.position = CGPointMake(188+i*8, 166+i*11);
            
            CCSprite *tileLeft2 = [CCSprite spriteWithFile:@"tile_left_in.png"];
            [self addChild:tileLeft2 z:2+18-i];
            tileLeft2.position = CGPointMake(188+i*8, 177+i*11);
            
            CCSprite *tileRight1 = [CCSprite spriteWithFile:@"tile_right_in.png"];
            [self addChild:tileRight1 z:1+i];
            tileRight1.position = CGPointMake(709+i*8, 354-i*11);
            
            CCSprite *tileRight2 = [CCSprite spriteWithFile:@"tile_right_in.png"];
            [self addChild:tileRight2 z:2+i];
            tileRight2.position = CGPointMake(709+i*8, 365-i*11);
            
        }
        
        for (int i=0; i<24; i++) {//打出的牌
            CCSprite *tileMainOut = [CCSprite spriteWithFile:[NSString stringWithFormat:@"tile_main_out_%d_%d.png",rand()%3,rand()%9+1]];
            tileMainOut.position = CGPointMake(349+(i%12)*30, 151-(i/12)*33);
            [self addChild:tileMainOut z:(2+i/12)];
            
//            CCSprite *tileUpOut = [CCSprite spriteWithFile:[NSString stringWithFormat:@""]
        }
        
    }
    
    return self;
}

//add bu yuan for gamecenter
# pragma 网络代理 游戏中心部分接收到各种报文 根据不同状态切换来处理对应不同的请求

//游戏开始通知
- (void)GameStart:(WORD)SubCmd arg:(char*) pData len: (WORD)wDataSize
{
    CMD_S_GameStart GameStart;
    memset(&GameStart, 0, sizeof(CMD_S_GameStart));
    memcpy(&GameStart, pData, sizeof(CMD_S_GameStart));
    
    if (GAMEDEBUG)
    {
        //筛子点数 一共2筛子 2个字节 解析开
        CCLOG(@"shaizidianshu:%d  %d", pData[0], pData[1]);
        
        //庄家用户 根据椅子ID辨别
        CCLOG(@"zhuangJia:%d", GameStart.wBankerUser);
        //当前用户
        CCLOG(@"dangQianYongHu:%d", GameStart.wCurrentUser);
        //活动
        CCLOG(@"yongHuDongZuo:%d",GameStart.cbUserAction);
        //堆力头
        CCLOG(@"duiLiPaiTou:%d", GameStart.wHeapHand);
        //堆里尾巴
        CCLOG(@"duiLiPaiWei:%d", GameStart.wHeapTail);
        //圈数
        CCLOG(@"quanXu:%d", GameStart.cbQuan);
        //倍数
        CCLOG(@"BeiShu:%d", GameStart.cbMultiple);
        
        //麻将牌 庄家也是发送13个牌，如果有花牌则在补花中处理精灵动作
        for (int i = 0; i < MAX_COUNT; i++)
        { 
            CCLOG(@"MaJiangPai:%d", GameStart.cbCardData[i]);
        }
        
        //4位玩家是否托管  1代表是 0代表NO
        for (int i = 0; i < GAME_PLAYER; i++)
        {
            CCLOG(@"ShiFouTuoGuan:%d", GameStart.bTrustee[i]);
            
        }
        
        //4位玩家的座位信息
        for (int i = 0; i < GAME_PLAYER; i++)
        {
            CCLOG(@"ZuoWeiXinXi:%d", GameStart.cbTaiArray[i]);
        }
        
        //门风东 的对应
        for (int i = 0; i < GAME_PLAYER; i++)
        {
            CCLOG(@"MenFengDong:%d", GameStart.cbDoorDirection[i]);
        }
        
        //二维数组 行代表椅子账号  列代表抓拍的数目  
        for (int i = 0; i < GAME_PLAYER; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                CCLOG(@"DuiLiXinXi:%d", GameStart.cbHeapCardInfo[i][j]);
            }
        }
        
        
    }
    
    
    //此处应当给个逻辑位接下来的动作在帧数循环方法中进行
    //处理牌局开始逻辑当完全摆放好精灵位置以及玩家位置之后发送游戏牌局开始摆放结束请求
    //。。。。。这里是游戏中逻辑摆放处理
    
    [[GameManager sharedGameManager] sendData:MDM_GF_GAME sum:SUB_S_MOVIE_END];
    
    
    //不要忘记释放掉内存
    free(pData);
    
}


- (void)GameSendCard:(WORD)SubCmd arg:(char*) pData len: (WORD)wDataSize
{
    CMD_S_SendCard GameStart;
    memset(&GameStart, 0, sizeof(CMD_S_SendCard));
    memcpy(&GameStart, pData, sizeof(CMD_S_SendCard));
    
    if (GAMEDEBUG)
    {
        //发送的具体扑克
        CCLOG(@"SendCard:%d", GameStart.cbCardData);
        
        //动作掩码
        CCLOG(@"ActionMask:%d", GameStart.cbActionMask);
        
        //当前用户 意思就是给谁的
        CCLOG(@"CurrentUser:%d", GameStart.wCurrentUser);
        
        //是否是补花
        CCLOG(@"ShiFouBuHua:%d", GameStart.bHua);
        
        //是否是补杠或者花  游戏中
        CCLOG(@"ShiFouBuhuaBuGang:%d", GameStart.bTail);
        
        
        //是否因为杠牌带来的发牌
        CCLOG(@"YinWeiGang:%d", GameStart.bFromGang);
    }
    
    
    
    free(pData);
    
}

//end by yuan





@end

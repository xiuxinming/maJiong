//
//  HelloWorldLayer.h
//  Mahjong_JP
//
//  Created by Gao Feng on 12-8-21.
//  Copyright BUPT 2012年. All rights reserved.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"

// HelloWorldLayer
@interface HelloWorldLayer : CCLayer
{
}

// returns a CCScene that contains the HelloWorldLayer as the only child
+(CCScene *) scene;

@end

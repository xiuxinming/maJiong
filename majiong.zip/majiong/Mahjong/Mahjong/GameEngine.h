//
//  GameEngine.h
//  Mahjong
//
//  Created by etgame iphone on 12-8-21.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "constMahjong.h"

@interface GameEngine : CCLayer {
    int mahjong_tiles[N_ALL_TILE]; // 
    
}

@end

//
//  HelloWorldLayer.m
//  tttees
//
//  Created by ETGame on 12-9-7.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//


// Import the interfaces
#import "MainMenuScreen.h"


@implementation MainMenuScreen

+(CCScene *) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	MainMenuScreen *layer = [MainMenuScreen node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
-(id) init
{
	// always call "super" init
	// Apple recommends to re-assign "self" with the "super" return value
	if( (self=[super init])) {
		
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile:@"mainmenu.pv.plist"];
        
        sizeOfWin = [[CCDirector sharedDirector] winSize];
        sprite_back =[CCSprite spriteWithSpriteFrameName:@"p-38.png"];
        [self addChild:sprite_back ];   
        
        [sprite_back setPosition:ccp(sizeOfWin.width*0.5 , sizeOfWin.height*0.5)];
        topred=[CCSprite spriteWithSpriteFrameName:@"p-3.png"];
        leftred=[CCSprite spriteWithSpriteFrameName:@"p-36.png"];
        rightred=[CCSprite spriteWithSpriteFrameName:@"p-37.png"];
        topred.position = ccp(160,580);
        leftred.position = ccp(-100,240);
        rightred.position = ccp(420,240);
        [self addChild:topred z:1];
        [self addChild:leftred z:1];
        [self addChild:rightred z:1];
        [leftred runAction:[CCMoveTo actionWithDuration:0.5F position:ccp(9.75,sizeOfWin.height*0.5-20)]];
        [rightred runAction:[CCMoveTo actionWithDuration:0.5F position:ccp(sizeOfWin.width-9.5,sizeOfWin.height*0.5-20)]];
        [topred runAction:[CCMoveTo actionWithDuration:0.5F position:ccp(sizeOfWin.width*0.5,sizeOfWin.height-49.25)]];
        
        
        topyellowa=[CCSprite spriteWithSpriteFrameName:@"p-2.png"];
        topyellowb=[CCSprite spriteWithSpriteFrameName:@"p-1.png"];
        bottompic=[CCSprite spriteWithSpriteFrameName:@"p-34.png"];
        topyellowa.position = ccp(57.75,sizeOfWin.height+100);
        topyellowb.position = ccp(sizeOfWin.width-95.5,sizeOfWin.height+100);
        bottompic.position = ccp(sizeOfWin.width*0.5,-50);
        [self addChild:topyellowa z:2];
        [self addChild:topyellowb z:2];
        [self addChild:bottompic z:2];
        [topyellowa runAction:[CCMoveTo actionWithDuration:0.6F position:ccp(57.75,sizeOfWin.height-18.5)]];
        [topyellowb runAction:[CCMoveTo actionWithDuration:0.7F position:ccp(sizeOfWin.width-95.5,sizeOfWin.height-10.25)]];
        [bottompic runAction:[CCMoveTo actionWithDuration:0.6F position:ccp(sizeOfWin.width*0.5,26)]];
        
        
        dog=[CCSprite spriteWithSpriteFrameName:@"p-32.png"];
        catbig=[CCSprite spriteWithSpriteFrameName:@"p-31.png"];
        dog.position = ccp(sizeOfWin.width*0.2,-100);
        catbig.position = ccp(sizeOfWin.width*0.72,-150);
        [self addChild:dog z:3];
        [self addChild:catbig z:3];
        
        
        id ac1=[CCMoveTo actionWithDuration:0.3F position:ccp(sizeOfWin.width*0.2,53.5)];  
        id ac2=[CCMoveBy actionWithDuration:0.3F position:ccp(0,-7)];
        id ac3=[ac2 reverse];
        id ac34=[CCRepeat actionWithAction:[CCSequence actions:ac2, ac3,nil]times:111];
        [dog runAction:[CCSequence actions:ac1,ac34,nil]] ; 
//        [dog runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac2, ac3,nil]]]; 
//        [catbig runAction:[CCMoveTo actionWithDuration:0.6F position:ccp(sizeOfWin.width*0.75,59.25)]];
        id ac5=[CCMoveTo actionWithDuration:0.6F position:ccp(sizeOfWin.width*0.72,51)];
        id ac6=[CCMoveBy actionWithDuration:0.7F position:ccp(0,7)];
        id ac7=[ac6 reverse];
        id ac67=[CCRepeat actionWithAction:[CCSequence actions:ac6, ac7,nil]times:111];
        [catbig runAction:[CCSequence actions:ac5,ac67,nil]] ; 
        
      
        
        a02big=[CCSprite spriteWithSpriteFrameName:@"p-24.png"];
        a02big.position = ccp(sizeOfWin.width*0.5-10,sizeOfWin.height*0.5+40);
        [self addChild:a02big z:6];
        [a02big setVisible:NO];
        
        yellobj=[CCSprite spriteWithSpriteFrameName:@"p-29.png"];
        yellobj.position = ccp(sizeOfWin.width*0.5+10,sizeOfWin.height*0.5+120);
        [self addChild:yellobj z:4];
        [yellobj setVisible:NO];
        
        tanchitb=[CCSprite spriteWithSpriteFrameName:@"p-28.png"];
        tanchitb.position = ccp(sizeOfWin.width*0.5,sizeOfWin.height*0.5+130);
        [self addChild:tanchitb z:5];
        [tanchitb setVisible:NO];
        
        liveback=[CCSprite spriteWithSpriteFrameName:@"光效.png"];
        liveback.position = ccp(sizeOfWin.width*0.5,sizeOfWin.height*0.5+33);
        [self addChild:liveback z:0];
        [liveback setVisible:NO];
        
        bread=[CCSprite spriteWithSpriteFrameName:@"p-30.png"];
        bread.position = ccp(sizeOfWin.width*0.88,-100);
        [self addChild:bread z:4];

        
        
        
        
        cover_curstate = FIRSTGO;

        [self schedule:@selector(gameLogic:) interval:0.02];
        
        [self addmenu];
       

        

        
        
    }
	return self;
}






-(void)addmenu
{
    
    item5 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-7.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-7.png"] target:self selector:@selector(GameSound)];
    [item5 setPosition:ccp(35-sizeOfWin.width*0.5,sizeOfWin.height*0.5-16)];
    [item5 setVisible:NO];
    [item5 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action], [CCFadeIn actionWithDuration:0.8f],nil]]; 
    
    
    item6 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-8.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-8.png"] target:self selector:@selector(GameMusi)];
    [item6 setPosition:ccp(15-sizeOfWin.width*0.5,sizeOfWin.height*0.5-16)];
    [item6 setVisible:NO];
    [item6 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action], [CCFadeIn actionWithDuration:0.8f],nil]]; 
    
    item7 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-5.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-5.png"] target:self selector:@selector(GameWeibo)];
    [item7 setPosition:ccp(sizeOfWin.width*0.5-42,sizeOfWin.height*0.5-46)];
    [item7 setVisible:NO];
    [item7 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action], [CCFadeIn actionWithDuration:0.8f],nil]]; 
    
    
    item8 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-4.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-4.png"] target:self selector:@selector(GameShare)];
    [item8 setPosition:ccp(sizeOfWin.width*0.5-16,sizeOfWin.height*0.5-46)];
    [item8 setVisible:NO];
    [item8 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action], [CCFadeIn actionWithDuration:0.8f],nil]]; 
    
    a02smal=[CCSprite spriteWithSpriteFrameName:@"p-6.png"];
    a02smal.position = ccp(sizeOfWin.width-39,sizeOfWin.height-16);
    [self addChild:a02smal z:7];
    [a02smal setVisible:NO];
    [a02smal runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action], [CCFadeIn actionWithDuration:0.8f],nil]]; 

    
    
    id ac2=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id ac13=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];
    id chili1=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id chili2=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];

    
    id ac4=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id ac23=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];
    id bonefish1=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id bonefish2=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];

    id ac6=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id ac33=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];
    id statmen1=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id statmen2=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];

    id ac8=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id ac43=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];
    id bone1=[CCMoveBy actionWithDuration:0.5F position:ccp(0,270)];
    id bone2=[CCMoveBy actionWithDuration:0.1F position:ccp(0,-10)];

    
    item1 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-15.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-15.png"] target:self selector:@selector(GameStart)];
    [item1 setPosition:ccp(0,-275)];
    chili=[CCSprite spriteWithSpriteFrameName:@"p-9.png"];
    chili.position = ccp(sizeOfWin.width*0.5+51,-19);
    [self addChild:chili z:7];
    
    
    
    item2 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-16.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-16.png"] target:self selector:@selector(GameHelp)];
    [item2 setPosition:ccp(0,-315)];
    bonefish=[CCSprite spriteWithSpriteFrameName:@"p-10.png"];
    bonefish.position = ccp(sizeOfWin.width*0.5-51,-59);
    [self addChild:bonefish z:7];
    
    item3 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-17.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-17.png"] target:self selector:@selector(GameNo)];
    [item3 setPosition:ccp(0,-355)];
    starmenu=[CCSprite spriteWithSpriteFrameName:@"p-11.png"];
    starmenu.position = ccp(sizeOfWin.width*0.5+49,-99);
    [self addChild:starmenu z:7];
    
    item4 = [CCMenuItemSprite itemFromNormalSprite:[CCSprite spriteWithSpriteFrameName:@"p-18.png"] selectedSprite:[CCSprite spriteWithSpriteFrameName:@"p-18.png"] target:self selector:@selector(GameMore)];
    [item4 setPosition:ccp(0,-395)];
    bone=[CCSprite spriteWithSpriteFrameName:@"p-12.png"];
    bone.position = ccp(sizeOfWin.width*0.5-51,-141);
    [self addChild:bone z:7];
    
    CCMenu *menu1 = [CCMenu menuWithItems:item1,item2,item3,item4,item5,item6,item7,item8,nil];
    [self addChild:menu1 z:6 ];
    [item1 runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 0.8],ac2,ac13,nil]];
    [chili runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 0.8],chili1,chili2,nil]];
    
    [item2 runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 0.9],ac4,ac23,nil]];
    [bonefish runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 0.9],bonefish1,bonefish2,nil]];

    [item3 runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 1.0],ac6,ac33,nil]];
    [starmenu runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 1.0],statmen1,statmen2,nil]];
    
    [item4 runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 1.1],ac8,ac43,nil]];
    [bone runAction:[CCSequence actions: [CCDelayTime actionWithDuration: 1.1],bone1,bone2,nil]];
    



}


-(void )gameLogic : (ccTime)dt
{

    switch (cover_curstate) {
        case FIRSTGO:
        {
            a02big.scaleX = 0.0f;
            a02big.scaleY = 0.0f;
            
            [a02big setVisible:YES];
            CCAction *actiona02big = [CCSequence actions:
                                [CCDelayTime actionWithDuration: 0.3],
                                [CCScaleTo actionWithDuration:0.2F scale:0.4],
                                      [CCScaleTo actionWithDuration:0.1F scale:0.3],
                                      [CCScaleTo actionWithDuration:0.2F scale:1.0],
                                nil];
            [a02big runAction: actiona02big];
            CCAction *actionabread= [CCSequence actions:
                                      [CCDelayTime actionWithDuration: 0.3],
                                      [CCMoveTo actionWithDuration:0.5F position:ccp(sizeOfWin.width*0.88,26)],
                                      nil];
             [bread runAction: actionabread];

            
             cover_curstate = SECONDGO;
            break;
        
        }
            
            
        case SECONDGO:{
            
            tanchitb.scaleX = 0.0f;
            tanchitb.scaleY = 0.0f;
            
            [tanchitb setVisible:YES];
            CCAction *actionatanc = [CCSequence actions:
                                      [CCDelayTime actionWithDuration: 0.6],
                                      
                                      [CCScaleTo actionWithDuration:0.2F scale:1.0],
                                      nil];
            [tanchitb runAction: actionatanc];
            
            
            yellobj.scaleX = 0.0f;
            yellobj.scaleY = 0.0f;
            
            [yellobj setVisible:YES];
            CCAction *actionayel = [CCSequence actions:
                                     [CCDelayTime actionWithDuration: 0.6],
                                     
                                     [CCScaleTo actionWithDuration:0.2F scale:1.0],
                                     nil];
            [yellobj runAction: actionayel];
            cover_curstate = THIRDGO;
            
        break;
        }
            
        case THIRDGO:{
            liveback.scaleX = 0.0f;
            liveback.scaleY = 0.0f;
            [liveback setVisible:YES];
            
            CCAction *actionalive= [CCSequence actions: [CCDelayTime actionWithDuration: 0.6],
                                    [CCScaleTo actionWithDuration:0.1F scale:1.0],
                                    [CCRepeat actionWithAction:[CCRotateBy actionWithDuration:5 angle:360]times:111],nil];
            
            [liveback runAction:actionalive];
            
            catsmal=[CCSprite spriteWithSpriteFrameName:@"p-26.png"];
            catsmal.position = ccp(sizeOfWin.width*0.5,sizeOfWin.height*0.5+130);
            [self addChild:catsmal z:4];
            [catsmal setVisible:NO];
            catsmal.scaleX = 0.0f;
            catsmal.scaleY = 0.0f;
            id acf = [CCCallFunc actionWithTarget:self selector:@selector(CallBack1)];
            [catsmal runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.6],[CCShow action],acf,[CCMoveBy actionWithDuration:0.5  position:ccp(-97, 4) ],nil]]; 
            
            chiken=[CCSprite spriteWithSpriteFrameName:@"p-35.png"];
            chiken.position = ccp(sizeOfWin.width*0.5,sizeOfWin.height*0.5+110);
            [self addChild:chiken z:4];
            [chiken setVisible:NO];
            chiken.scaleX = 0.0f;
            chiken.scaleY = 0.0f;
            id acf2 = [CCCallFunc actionWithTarget:self selector:@selector(CallBack2)];
            [chiken runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.5],[CCShow action],acf2,[CCMoveBy actionWithDuration:0.5  position:ccp(75, -10) ],nil]];
            
            cake=[CCSprite spriteWithSpriteFrameName:@"p-25.png"];
            cake.position = ccp(sizeOfWin.width*0.5,sizeOfWin.height*0.5+130);
            [self addChild:cake z:4];
            [cake setVisible:NO];
            cake.scaleX = 0.0f;
            cake.scaleY = 0.0f;
            id acf3 = [CCCallFunc actionWithTarget:self selector:@selector(CallBack3)];
            [cake runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.6],[CCShow action],acf3,[CCMoveBy actionWithDuration:0.5  position:ccp(97, 4) ],nil]];
            
            bearb=[CCSprite spriteWithSpriteFrameName:@"p-27.png"];
            bearb.position = ccp(178,400);
            [self addChild:bearb z:7];
            [bearb setVisible:NO];
            bearb.scaleX = 9.0f;
            bearb.scaleY = 9.0f;
            [bearb runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.0],[CCShow action],[CCScaleTo actionWithDuration:0.3F scale:1.0],nil]];
            
            
            cover_curstate = FORTHGO;

            break;
        
        }
        case FORTHGO:{  
            
//            [CCDelayTime actionWithDuration: 0.3];
            [self schedule:@selector(addsmallobj:) interval:2.0];
            [self schedule:@selector(addstar:) interval:1.0];


           
       cover_curstate = FIVETH;
       
           break;
       }
            break;
            
            
    }
    

}
- (void) CallBack1
{
	[catsmal runAction:[CCScaleTo actionWithDuration:0.5F scale:1.0]];	
}


- (void) CallBack2
{
	[chiken runAction:[CCScaleTo actionWithDuration:0.5F scale:1.0]];	
}



- (void) CallBack3
{
	[cake runAction:[CCScaleTo actionWithDuration:0.5F scale:1.0]];	
}





-(void)addstar:(ccTime)dt
{
    star1=[CCSprite spriteWithSpriteFrameName:@"p-14.png"];
    star1.position = ccp(160,333);
    [self addChild:star1 z:3];
    id star1actionMove = [CCMoveBy actionWithDuration:0.5
                                            position:ccp(-111, -111)];
    id acmstar1=[CCEaseOut actionWithAction:star1actionMove rate:3];
    id acmstar2=[CCEaseIn actionWithAction:star1actionMove rate:1];
    
    
    id actionMoveDone = [CCCallFuncN actionWithTarget:self 
                                             selector:@selector(spriteMoveFinished:)];
    [star1 runAction:[CCSequence actions:[CCRotateBy actionWithDuration:0.01 angle:55],acmstar1,acmstar2, actionMoveDone, nil]];
    
    
    
    
    star3=[CCSprite spriteWithSpriteFrameName:@"p-14.png"];
    star3.position = ccp(160,333);
    [self addChild:star3 z:3];
    id star3actionMove = [CCMoveBy actionWithDuration:0.5
                                             position:ccp(111, -111)];
    id acmstar31=[CCEaseOut actionWithAction:star3actionMove rate:3];
    id acmstar32=[CCEaseIn actionWithAction:star3actionMove rate:1];
    
    [star3 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.2],acmstar31,acmstar32, actionMoveDone, nil]];
    
    
    star2=[CCSprite spriteWithSpriteFrameName:@"p-11.png"];
    star2.position = ccp(160,333);
    [self addChild:star2 z:3];
    id star2actionMove = [CCMoveBy actionWithDuration:0.5
                                             position:ccp(111, -61)];
    id acmstar21=[CCEaseOut actionWithAction:star2actionMove rate:3];
    id acmstar22=[CCEaseIn actionWithAction:star2actionMove rate:1];
      
    [star2 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.4],[CCRotateBy actionWithDuration:0.01 angle:55],acmstar21,acmstar22, actionMoveDone, nil]];
    
    star4=[CCSprite spriteWithSpriteFrameName:@"p-11.png"];
    star4.position = ccp(160,333);
    [self addChild:star4 z:3];
    id star4actionMove = [CCMoveBy actionWithDuration:0.5
                                             position:ccp(-111, -39)];
    id acmstar41=[CCEaseOut actionWithAction:star4actionMove rate:3];
    id acmstar42=[CCEaseIn actionWithAction:star4actionMove rate:1];
    
    [star4 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.6],acmstar41,acmstar42, actionMoveDone, nil]];
    
    
    star5=[CCSprite spriteWithSpriteFrameName:@"p-11.png"];
    star5.position = ccp(160,333);
    [self addChild:star5 z:3];
    id star5actionMove = [CCMoveBy actionWithDuration:0.5
                                             position:ccp(-111, 11)];
    id acmstar51=[CCEaseOut actionWithAction:star5actionMove rate:3];
    id acmstar52=[CCEaseIn actionWithAction:star5actionMove rate:1];
    
    [star5 runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.8],[CCRotateBy actionWithDuration:0.01 angle:55],acmstar51,acmstar52, actionMoveDone, nil]];
    
    
  
    

}



-(void)addsmallobj:(ccTime)dt
{
    
    
    meat=[CCSprite spriteWithSpriteFrameName:@"p-13.png"];
    meat.position = ccp(40,333);
    [self addChild:meat z:3];
    [meat setVisible:NO];
    meat.scaleX = 0.0f;
    meat.scaleY = 0.0f;
    
    [meat setVisible:YES];
    id meatactionMove = [CCMoveBy actionWithDuration:2.0 
                                        position:ccp(0, -383)];
    id acmmeat=[CCEaseOut actionWithAction:meatactionMove rate:2];
    

    id actionMoveDone = [CCCallFuncN actionWithTarget:self 
                                             selector:@selector(spriteMoveFinished:)];
    [meat runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 0.6], [CCScaleTo actionWithDuration:0.05F scale:1.0],acmmeat, actionMoveDone, nil]];
    
    
    fish=[CCSprite spriteWithSpriteFrameName:@"p-19.png"];
    fish.position = ccp(280,333);
    [self addChild:fish z:5];
    [fish setVisible:NO];
    fish.scaleX = 0.0f;
    fish.scaleY = 0.0f;
    
    [fish setVisible:YES];
    id fishactionMove = [CCMoveBy actionWithDuration:2.0 
                                            position:ccp(0, -383)];
    id acmfish=[CCEaseOut actionWithAction:fishactionMove rate:2];
    
    
    [fish runAction:[CCSequence actions:[CCDelayTime actionWithDuration: 1.1], [CCScaleTo actionWithDuration:0.05F scale:1.0],acmfish, actionMoveDone, nil]];
    
    bomb=[CCSprite spriteWithSpriteFrameName:@"p-33.png"];
    bomb.position = ccp(100,303);
    [self addChild:bomb z:3];
    id bombactionMove = [CCMoveBy actionWithDuration:1.5
                                            position:ccp(0, -363)];
    id acmbomb=[CCEaseOut actionWithAction:bombactionMove rate:2];
    [bomb runAction:[CCSequence actions:acmbomb, actionMoveDone, nil]];

    
    


    
    
}

-(void)spriteMoveFinished:(id)sender {
    
    CCSprite *sprite = (CCSprite *)sender;
    [self removeChild:sprite cleanup:YES];
    sprite = nil; 
}
    

-(void)GameStart
{
    CCLOG(@"游戏开始");
//    [[CCDirector sharedDirector] replaceScene:[CCShrinkGrowTransition transitionWithDuration:1.2f scene:scene]];
    [[CCDirector sharedDirector] replaceScene:[CCBReader sceneWithNodeGraphFromFile:@"loading.ccb"]];
}

-(void)GameHelp
{
    CCLOG(@"帮助");
}

-(void)GameNo
{
    CCLOG(@"排行榜");
}


-(void)GameMore
{
    CCLOG(@"其他游戏");
}

-(void)GameSound
{
    CCLOG(@"游戏声音");
}

-(void)GameMusi
{
    CCLOG(@"游戏音乐");
}

-(void)GameWeibo
{
    CCLOG(@"微博");
}

-(void)GameShare
{
    CCLOG(@"游戏中心");
}

- (void) dealloc
{
	// in case you have something to dealloc, do it in this method
	// in this particular example nothing needs to be released.
	// cocos2d will automatically release all the children (Label)
	
	// don't forget to call "super dealloc"
	[super dealloc];
}
@end




#import "cocos2d.h"
#import "loading.h"


#define FIRSTGO       0
#define SECONDGO      1
#define THIRDGO       2
#define FORTHGO       3
#define FIVETH        4

@interface MainMenuScreen : CCLayer
{
    CGSize sizeOfWin;
    CCSprite* sprite_back;
    CCSprite* liveback;
    CCSprite* topyellowa;
    CCSprite* topyellowb;
    
    
    CCSprite* topred;
    CCSprite* leftred;
    CCSprite* rightred;
    CCSprite* logpic;
    
    
    CCSprite* star1;
    CCSprite* star2;
    CCSprite* star3;
    CCSprite* star4;
    CCSprite* star5;
    
    CCSprite* starmenu;
    CCSprite* chili;
    CCSprite* bone;
    CCSprite* bonefish;
    
    
    CCSprite* bomb;
    CCSprite* meat;
    CCSprite* bearb;
    CCSprite* a02smal;
    CCSprite* a02big;
    
    
    CCSprite* cake;
    CCSprite* fish;
    CCSprite* dog;
    CCSprite* chiken;
    CCSprite* catbig;
    CCSprite* catsmal;
    
    
    CCSprite* bottompic;
    CCSprite* tanchitb;
    CCSprite* yellobj;
    CCSprite* bread;
    
    CCMenuItemSprite *item1;
    CCMenuItemSprite *item2;
    CCMenuItemSprite *item3;
    CCMenuItemSprite *item4;
    CCMenuItemSprite *item5;
    CCMenuItemSprite *item6;
    CCMenuItemSprite *item7;
    CCMenuItemSprite *item8;
    
    int cover_curstate;
}

+(CCScene *) scene;

-(void )gameLogic : (ccTime)dt;
-(void)addsmallobj:(ccTime)dt;
-(void)addstar:(ccTime)dt;
-(void)addmenu;

@end

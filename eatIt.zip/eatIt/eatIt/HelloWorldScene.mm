//
//  HelloWorldScene.mm
//  presentation
//
//  Created by Bogdan Vladu on 15.03.2011.
//
// Import the interfaces
#import "HelloWorldScene.h"
const float32 FIXED_TIMESTEP = 1.0f / 60.0f;
const float32 MINIMUM_TIMESTEP = 1.0f / 600.0f;  
const int32 VELOCITY_ITERATIONS = 8;
const int32 POSITION_ITERATIONS = 8;
const int32 MAXIMUM_NUMBER_OF_STEPS = 25;

static int tick = 0;
static int realtick = 0;
static int shengming = 0;

//显示猪脚 表情动作
BOOL    LEFTCAT = NO;
BOOL    LEFTDOG = NO;
BOOL   CENCAT = NO;
BOOL   CENDOG = NO;
BOOL   RIGHTCAT = NO;
BOOL  RIGHTDOG = NO;


BOOL CENTERZHUJIAO = NO;
BOOL LEFTZHUJIAO = NO; 
BOOL RIGHTZHUJIAO = NO;

// HelloWorld implementation
@implementation HelloWorldScene


@synthesize allbody, zhujiaoSprite;
@synthesize cat1,cat2,cat3,dog1,dog2,dog3;
@synthesize opacity;
@synthesize gameStatus, status;
@synthesize parse,interval;
@synthesize noPhySprite;


-(void)afterStep
{
	// process collisions and result from callbacks called by the step
//    CCLOG(@"peng zhuang le");
}
////////////////////////////////////////////////////////////////////////////////
-(void)step:(ccTime)dt
{
	float32 frameTime = dt;
	int stepsPerformed = 0;
	while ( (frameTime > 0.0) && (stepsPerformed < MAXIMUM_NUMBER_OF_STEPS) )
    {
		float32 deltaTime = std::min( frameTime, FIXED_TIMESTEP );
		frameTime -= deltaTime;
		if (frameTime < MINIMUM_TIMESTEP)
        {
			deltaTime += frameTime;
			frameTime = 0.0f;
		}
		world->Step(deltaTime,VELOCITY_ITERATIONS,POSITION_ITERATIONS);
		stepsPerformed++;
		[self afterStep]; // process collisions and result from callbacks called by the step
	}
	world->ClearForces ();
}
////////////////////////////////////////////////////////////////////////////////
+(id) scene
{
	// 'scene' is an autorelease object.
	CCScene *scene = [CCScene node];
	
	// 'layer' is an autorelease object.
	HelloWorldScene *layer = [HelloWorldScene node];
	
	// add layer as a child to scene
	[scene addChild: layer];
	
	// return the scene
	return scene;
}


-(void) retrieveRequiredObjects
{
    
    CGSize size = [CCDirector sharedDirector].winSize;
    ////    sprite.position = ccp(size.width/2,size.height/2);
    
    //背景
    bg = [lh spriteWithUniqueName:@"p-78"];
    assert(bg != nil);
    
    //上层酱油
    LHSprite *upBg = [lh spriteWithUniqueName:@"p-70"];
    assert(upBg != nil);
//  upBg.position = ccp(160,424);
    [upBg transformPosition:ccp(160.0,554.0)];
    CCMoveTo* moveto = [CCMoveTo actionWithDuration:0.3f position:ccp(160, 424)];
    [upBg runAction:moveto];
    
    //下层 160 32   ,-50 
    LHSprite *downBg = [lh spriteWithUniqueName:@"p-75"];
    assert(downBg != nil);
    [downBg transformPosition:ccp(160, -50)];
    CCMoveTo *moveto1 = [CCMoveTo actionWithDuration:0.3 position:ccp(160,32)];
    [downBg runAction:moveto1];
    
    //左
    //8 254  480
    LHSprite *leftBg = [lh spriteWithUniqueName:@"p-71"];
    assert(leftBg != nil);
    [leftBg transformPosition:ccp(-50, 254)];
    CCMoveTo *moveto2 = [CCMoveTo actionWithDuration:0.5 position:ccp(8,254)];
    [leftBg runAction:moveto2];
    
    //右 302 232  480
    LHSprite *rightBg = [lh spriteWithUniqueName:@"p-72"];
    assert(rightBg !=nil );
    [rightBg transformPosition:ccp(380,248)];
    CCMoveTo *moveto3 = [CCMoveTo actionWithDuration:0.5 position:ccp(308,240)];
    [rightBg runAction:moveto3];
    
    
        //中间狗
    dog1 = [lh spriteWithUniqueName:@"Dog_jieshiwu_1"];
    assert(dog1 != nil);
    
    //左边杂项 64 69 68 
    LHSprite* p64 = [lh spriteWithUniqueName:@"p-64"];
    LHSprite* p68 = [lh spriteWithUniqueName:@"p-68"];
    LHSprite* p69 = [lh spriteWithUniqueName:@"p-69"];
    
    CCMoveTo* moveto4 = [CCMoveTo actionWithDuration:0.7 position:ccp(16,480-64)];
    CCMoveTo* moveto5 = [CCMoveTo actionWithDuration:0.7 position:ccp(16,480-128)];
    CCMoveTo* moveto6 = [CCMoveTo actionWithDuration:0.7 position:ccp(16,480-248)];
    [p64 runAction:moveto4];
    [p69 runAction:moveto5];
    [p68 runAction:moveto6];
    
    id ac1 = [CCMoveTo actionWithDuration:0.5 position:ccp(16, 480-80)];
    
//    id ac2 = [ac1 reverse];
    id ac2 = [CCMoveTo actionWithDuration:0.5 position:ccp(16, 480-64)];
    [p64 runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac1, ac2,nil]]];
    
    id ac3 = [CCRotateTo actionWithDuration:0.5 angle:25];
    id ac4 = [CCRotateTo actionWithDuration:0.5 angle:-25];
    
    [p69 runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac3, ac4,nil]]];
    
    //右边  304 88     296 104  296 216
    LHSprite* p65 = [lh spriteWithUniqueName:@"p-65"];
    LHSprite* p681 = [lh spriteWithUniqueName:@"p-68_1"];
    LHSprite* p651 = [lh spriteWithUniqueName:@"p-65_1"];
    LHSprite* p95 = [lh spriteWithUniqueName:@"p-95"];
    
    CCMoveTo* moveto7 = [CCMoveTo actionWithDuration:0.7 position:ccp(304 ,480-88)];
    CCMoveTo* moveto8 = [CCMoveTo actionWithDuration:0.7 position:ccp(296,480-104)];
    CCMoveTo* moveto9 = [CCMoveTo actionWithDuration:0.7 position:ccp(306,480-216)];
    CCMoveTo* moveto10 = [CCMoveTo actionWithDuration:0.7 position:ccp(136 ,480-40)];
    [p681 runAction:moveto7];
    [p651 runAction:moveto8];
    [p95 runAction:moveto9];
    [p65 runAction:moveto10];
    
    id ac5 = [CCRotateTo actionWithDuration:0.5 angle:20];
    id ac6 = [CCRotateTo actionWithDuration:0.5 angle:-20];
    [p95 runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac5, ac6,nil]]];
    
    id ac7 = [CCScaleTo actionWithDuration:0.3 scale:1.3];
    id ac8 = [CCScaleTo actionWithDuration:0.3 scale:1];
    [p651 runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac7, ac8,nil]]];
    
    id ac9 = [CCScaleTo actionWithDuration:0.3 scale:1.3];
    id ac10 = [CCScaleTo actionWithDuration:0.3 scale:1];
    [p65 runAction:[CCRepeatForever actionWithAction:[CCSequence actions:ac9, ac10,nil]]];
    
    
    
    //生命条显示
    si1 = [lh spriteWithUniqueName:@"p-48"];
    si2 = [lh spriteWithUniqueName:@"p-48_1"];
    si3 = [lh spriteWithUniqueName:@"p-48_2"];
    ming1 = [lh spriteWithUniqueName:@"p-49"];
    ming2 = [lh spriteWithUniqueName:@"p-49_1"];
    ming3 = [lh spriteWithUniqueName:@"p-49_2"];
    
    
    
    [self performSelector:@selector(initSprite) withObject:self afterDelay:1];
    
}

- (void)pauseGame
{
    CCLOG(@"暂停游戏");
}

-(void)initSprite
{
    dog1.visible = YES;
    ming1.visible = YES;
    ming2.visible = YES;
    ming3.visible = YES;
    
    
    //名称
    CCSprite *name = [CCSprite spriteWithFile:@"p-6.png"];
    name.position = ccp(276 ,464);
    [self addChild:name];
    
    LHSprite *p50 = [lh spriteWithUniqueName:@"p-50"];
    LHSprite *p52 = [lh spriteWithUniqueName:@"p-52"];
    LHSprite *p53 = [lh spriteWithUniqueName:@"p-53"];
    p50.visible = YES;
    p52.visible = YES;
    p53.visible = YES;
    
    //暂停
    // Standard method to create a button
    CCMenuItem *pauseMenuItem = [CCMenuItemImage
                                 itemFromNormalImage:@"p-67.png" selectedImage:@"p-66.png"
                                 target:self selector:@selector(pauseGame)];
    pauseMenuItem.position = ccp(216, 480-16);
    
    CCMenu *starMenu = [CCMenu menuWithItems:pauseMenuItem, nil];
    starMenu.position = CGPointZero;
    [starMenu _setZOrder:0];
    [self addChild:starMenu];


}
# pragma animation

- (void)catDeyi:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_deyi_1" fromSpriteHelperScene:@"action" tag:CAT];
            [cat transformPosition:ccp(168.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            CENCAT = YES;
            break;
        }
            //左边  68
        case 2:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_deyi_1" fromSpriteHelperScene:@"action" tag:CAT2];
            [cat transformPosition:ccp(68.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            LEFTCAT = YES;

            break;
        }
            //右边  270
        case 3:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_deyi_1" fromSpriteHelperScene:@"action" tag:CAT3];
            [cat transformPosition:ccp(270.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_deyi" onSprite:cat];
            RIGHTCAT = YES;
            break;
        }
            
        default:
            break;
    }
    
}




- (void)catDengdai:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_dengdai_1" fromSpriteHelperScene:@"action" tag:CAT];
            [cat transformPosition:ccp(168.0,480.0-416)];
            
            
            [lh prepareAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            CENCAT = YES;
            break;
        }
            //左边
        case 2:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_dengdai_1" fromSpriteHelperScene:@"action" tag:CAT2];
            [cat transformPosition:ccp(68.0,480.0-416)];
            
            
            [lh prepareAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            LEFTCAT = YES;
            break;
        }
            //右边
        case 3:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_dengdai_1" fromSpriteHelperScene:@"action" tag:CAT3];
            [cat transformPosition:ccp(270.0,480.0-416)];
            
            
            [lh prepareAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_dengdai" onSprite:cat];
            RIGHTCAT = YES;
            break;
        }
            
        default:
            break;
    }
    
}



- (void)catJiedao:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_jiedao_1" fromSpriteHelperScene:@"action" tag:CAT];
            [cat transformPosition:ccp(168.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            CENCAT = YES;
            break;
        }
            //左边
        case 2:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_jiedao_1" fromSpriteHelperScene:@"action" tag:CAT2];
            [cat transformPosition:ccp(68.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            LEFTCAT = YES;
            break;
        }
            //右边
        case 3:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_jiedao_1" fromSpriteHelperScene:@"action" tag:CAT3];
            [cat transformPosition:ccp(270.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_jiedao" onSprite:cat];
            RIGHTCAT = YES;
            break;
        }
            
        default:
            break;
    }
    
}





- (void)catChicuo:(int)station
{
    
    switch (station) 
    {
            //中间
        case 1:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_chicuo_1" fromSpriteHelperScene:@"action" tag:CAT];
            [cat transformPosition:ccp(168.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            CENCAT = YES;
            
            [self removeNoSprite];
            break;
        }
            //左边
        case 2:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_chicuo_1" fromSpriteHelperScene:@"action" tag:CAT2];
            [cat transformPosition:ccp(68.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            LEFTCAT = YES;
            
            [self removeNoSprite];
            break;
        }
            //右边
        case 3:
        {
            LHSprite* cat = [lh createBatchSpriteWithName:@"Cat_chicuo_1" fromSpriteHelperScene:@"action" tag:CAT3];
            [cat transformPosition:ccp(270,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            [lh startAnimationWithUniqueName:@"cat_chicuo" onSprite:cat];
            RIGHTCAT = YES;
            
            [self removeNoSprite];
            break;
        }
            
        default:
            break;
    }
    
}


- (void)dogChicuo:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_chicuo_1" fromSpriteHelperScene:@"action" tag:DOG];
            [dog transformPosition:ccp(168.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            CENDOG = YES;
            
            [self removeNoSprite];
            break;
        }
            //左边
        case 2:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_chicuo_1" fromSpriteHelperScene:@"action" tag:DOG2];
            [dog transformPosition:ccp(68.0,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            LEFTDOG = YES;
            
            [self removeNoSprite];
            break;
        }
            //右边
        case 3:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_chicuo_1" fromSpriteHelperScene:@"action" tag:DOG3];
            [dog transformPosition:ccp(270,480.0-416)];
            
            [lh prepareAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_chucuo" onSprite:dog];
            RIGHTDOG = YES;
            
            [self removeNoSprite];
            break;
        }
            
        default:
            break;
    }
    
}

- (void)dogJiedao:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_jiedao_1" fromSpriteHelperScene:@"action" tag:DOG];
            [dog transformPosition:ccp(168.0,480.0-416)];
            
     
            
            [lh prepareAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            CENDOG = YES;
            
            break;
        }
            //左边
        case 2:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_jiedao_1" fromSpriteHelperScene:@"action" tag:DOG2];
            [dog transformPosition:ccp(68.0,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            LEFTDOG = YES;
            
            break;
        }
            //右边
        case 3:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_jiedao_1" fromSpriteHelperScene:@"action" tag:DOG3];
            [dog transformPosition:ccp(270,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_jiedao" onSprite:dog];
            RIGHTDOG = YES;
            
            break;
        }
            
        default:
            break;
    }
    
}


- (void)dogDeyi:(int)station
{
    
    switch (station)
    {
            //中间
        case 1:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_deyi_1" fromSpriteHelperScene:@"action" tag:DOG];
            [dog transformPosition:ccp(168.0,480.0-416)];
            
         
            
            [lh prepareAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            CENDOG = YES;
            
            break;
        }
            //左边
        case 2:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_deyi_1" fromSpriteHelperScene:@"action" tag:DOG2];
            [dog transformPosition:ccp(68.0,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            LEFTDOG = YES;
            
            break;
        }
            //右边
        case 3:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_deyi_1" fromSpriteHelperScene:@"action" tag:DOG3];
            [dog transformPosition:ccp(270,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_deyi" onSprite:dog];
            RIGHTDOG = YES;
            
            break;
        }
            
        default:
            break;
    }
    
}



- (void)dogDengdai:(int)station
{
    
    switch (station) 
    {
            //中间
        case 1:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_dengdai_1" fromSpriteHelperScene:@"action" tag:DOG];
            [dog transformPosition:ccp(168.0,480.0-416)];
            

            
            [lh prepareAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            CENDOG = YES;
            
            break;
        }
            //左边
        case 2:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_dengdai_1" fromSpriteHelperScene:@"action" tag:DOG2];
            [dog transformPosition:ccp(68.0,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            LEFTDOG = YES;
            
            break;
        }
            //右边
        case 3:
        {
            LHSprite* dog = [lh createBatchSpriteWithName:@"Dog_dengdai_1" fromSpriteHelperScene:@"action" tag:DOG3];
            [dog transformPosition:ccp(270,480.0-416)];
            
            
            
            [lh prepareAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            [lh startAnimationWithUniqueName:@"dog_dengdai" onSprite:dog];
            RIGHTDOG = YES;
            
            break;
        }
            
        default:
            break;
    }
    
}

- (void)dogJieshiwu:(int)tag
{
    switch (tag)
    {
        case DOG:
        {
            [self CenterCollision];
            dog1 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:DOG];
            [dog1 transformPosition:ccp(163.0,480.0-416)];
            [self addChild:dog1];
            [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog1];
            [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog1];
//            CENDOG = NO;
            break;
        }   
            
        case DOG2:
        {
            [self LeftCollision];
            dog2 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:DOG2];
            [dog2 transformPosition:ccp(60.0,480.0-416)];
            [self addChild:dog2];
            [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog2];
            [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog2];
//            LEFTDOG = NO;
            break;
        }
        case DOG3:
        {
            [self RightCollision];
            dog3 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:DOG3];
            [dog3 transformPosition:ccp(262,480.0-416)];
            [self addChild:dog3];
            [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog3];
            [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog3];
//            RIGHTDOG = NO;
            break;
        }
        default:
            break;
    }
}

- (void)catJieshiwu:(int)tag
{
    
    switch (tag) 
    {
        case CAT:
        {
            [self CenterCollision];
            cat1 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:CAT];
            [cat1 transformPosition:ccp(163.0,480.0-416)];
            [self addChild:cat1];
            [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat1];
            [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat1];
//            CENCAT = NO;

            break;
        }   
        case CAT2:
        {
            [self LeftCollision];
            cat2 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:CAT2];
            [cat2 transformPosition:ccp(60.0,480.0-416)];
            [self addChild:cat2];
            [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat2];
            [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat2];
//            LEFTCAT = NO;
            break;
        }
        case CAT3:
        {
            [self RightCollision];
            cat3 = [lh createPhysicalSpriteWithName:@"Cat_jieshiwu_1" fromSpriteHelperScene:@"action" tag:CAT3];
            [cat3 transformPosition:ccp(262,480.0-416)];
            [self addChild:cat3];
            [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat3];
            [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat3];
//            RIGHTCAT = NO;
            break;
        }
        default:
            break;
    }
}

#pragma 猪脚 标签互换
- (int)tagBysprite:(LHSprite*)sprite
{
    if ([sprite isEqual:(LHSprite*)cat1])
    {
        return 1;
    }
    
    if ([sprite isEqual:(LHSprite*)cat2])
    {
        return 2;
    }
    if ([sprite isEqual:(LHSprite*)cat3])
    {
        return 3;
    }
    
    if ([sprite isEqual:(LHSprite*)dog1])
    {
        
        return 1;
    }
    
    if ([sprite isEqual:(LHSprite*)dog2])
    {
        return 2;
    }
    if ([sprite isEqual:(LHSprite*)dog3])
    {
        return 3;
    }

    
}

- (void)cancleCollision:(int)tag
{
    switch (tag) 
    {
        case DOG:
        case CAT:
        {
            [self CancleCenterCollision];
            break;
        }   
        case DOG2:
        case CAT2:
        {
            [self CancleLeftCollision];
            break;
        }
        case DOG3:
        case CAT3:
        {
            [self CancleRightCollision];
            break;
        }
            
        default:
            break;
    }

}

#pragma pengzhuang

// 10  猫和zhongYu碰撞
-(void)catAndYu:(LHContactInfo*)contact
{
    CCLOG(@"catAndYuPengZhuang");
    
    //coid 是zhongYu 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];
        
    //1:删掉动物
    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    
    //2：表情变化
    [lh stopAnimationOnSprite:who];
    int number = [self tagBysprite:who];
//    [zhujiaoSprite addObject:who];
    who.visible = NO;
    
    
    [self catJiedao:number];
}

-(void)catAndRou:(LHContactInfo*)contact
{
//    CCLOG(@"catAndRouPengZhuang");
    
    //coid 是zhongYu 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];


    //1:删掉动物
    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    
     //2：表情变化
     [lh stopAnimationOnSprite:who];
     int number = [self tagBysprite:who];
    
//     [zhujiaoSprite addObject:who];
    who.visible = NO;
    
    [self catChicuo:number];
}

//游戏结束 迟到炸弹或者红辣椒
-(void)catAndBad:(LHContactInfo*)contact
{
    CCLOG(@"catAndRouPengZhuang");
    
    //coid 是zhongYu 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];

    //1:删掉动物
    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    
    //2：表情变化
    [lh stopAnimationOnSprite:who];
    int number = [self tagBysprite:who];
//     [zhujiaoSprite addObject:who];
    who.visible = NO;
    
    
    [self catChicuo:number];
    
    //3 游戏状态设置为GAMEEND
    gameStatus = GAMEEND;
}

// -10                    
-(void)dogAndYu:(LHContactInfo*)contact
{
    CCLOG(@"GouHeYuPengZhuang");
    
    //coid 是中肉 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];

    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    //2：表情变化
    [lh stopAnimationOnSprite:who];
    int number = [self tagBysprite:who];
//     [zhujiaoSprite addObject:who];
    who.visible = NO;
     
    
    [self dogChicuo:number];


}



-(void)dogAndRou:(LHContactInfo*)contact
{
//    CCLOG(@"GouHeRouPengZhuang");
    
    //coid 是中肉 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];
    
    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    //2：表情变化
    [lh stopAnimationOnSprite:who];
    int number = [self tagBysprite:who];
//     [zhujiaoSprite addObject:who];
    who.visible = NO;
    
   
    [self dogJiedao:number];
    
    
}


-(void)dogAndBad:(LHContactInfo*)contact
{
    CCLOG(@"GouHeBadPengZhuang");
    
    //coid 是中肉 如果不为空则删除掉
    LHSprite* coin = [contact spriteB];
    LHSprite* who = [contact spriteA];
    
    //0:取消当前猪脚位置的所以碰撞
    int tag = [who tag];
    [self cancleCollision:tag];
    
    if(nil != coin)
    {
        if([coin visible])
        {
            //准备销毁的物体添加到数组 tick循环中删除掉
            [allbody addObject:coin];
        }
    }
    //2：表情变化
    [lh stopAnimationOnSprite:who];
    int number = [self tagBysprite:who];
//     [zhujiaoSprite addObject:who];
    who.visible = NO;
   
    
    [self dogChicuo:number];
   
    
    //3:GAME OVER
    gameStatus = GAMEEND;
    
    
}

- (void)CancleCenterCollision
{
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:BAD];
    
    
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:BAD];
    
}

- (void)CancleLeftCollision
{
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:BAD];
    
    
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:BAD];

}


- (void)CancleRightCollision
{
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:BAD];
    
    
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:DAYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:ZHONGYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:XIAOYU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:DAROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:ZHONGROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:XIAOROU];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:GOOD];
    [lh cancelBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:BAD];
    

}


- (void)CenterCollision
{
    //中间猫
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:DAYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:ZHONGYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:XIAOYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:DAROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:ZHONGROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:XIAOROU idListener:self selListener:@selector(catAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:GOOD idListener:self selListener:@selector(catAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT andTagB:BAD idListener:self selListener:@selector(catAndBad:)];
    
    //中间狗
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:DAYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:ZHONGYU idListener:self selListener:@selector(dogAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:XIAOYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:DAROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:ZHONGROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:XIAOROU idListener:self selListener:@selector(dogAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:GOOD idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG andTagB:BAD idListener:self selListener:@selector(dogAndBad:)];

}
- (void)LeftCollision
{
    //左边猫
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:DAYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:ZHONGYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:XIAOYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:DAROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:ZHONGROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:XIAOROU idListener:self selListener:@selector(catAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:GOOD idListener:self selListener:@selector(catAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT2 andTagB:BAD idListener:self selListener:@selector(catAndBad:)];
    
    //左边狗
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:DAYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:ZHONGYU idListener:self selListener:@selector(dogAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:XIAOYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:DAROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:ZHONGROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:XIAOROU idListener:self selListener:@selector(dogAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:GOOD idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG2 andTagB:BAD idListener:self selListener:@selector(dogAndBad:)];
    

}

- (void)RightCollision
{
    //中间猫
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:DAYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:ZHONGYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:XIAOYU idListener:self selListener:@selector(catAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:DAROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:ZHONGROU idListener:self selListener:@selector(catAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:XIAOROU idListener:self selListener:@selector(catAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:GOOD idListener:self selListener:@selector(catAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:CAT3 andTagB:BAD idListener:self selListener:@selector(catAndBad:)];
    
    //中间狗
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:DAYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:ZHONGYU idListener:self selListener:@selector(dogAndYu:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:XIAOYU idListener:self selListener:@selector(dogAndYu:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:DAROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:ZHONGROU idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:XIAOROU idListener:self selListener:@selector(dogAndRou:)];
    
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:GOOD idListener:self selListener:@selector(dogAndRou:)];
    [lh registerBeginOrEndCollisionCallbackBetweenTagA:DOG3 andTagB:BAD idListener:self selListener:@selector(dogAndBad:)];
    

}
-(void) setupCollisionHandling
{
    
    //使用levelhelper处理碰撞
    [lh useLevelHelperCollisionHandling];
    [self CenterCollision];
    [self LeftCollision];
    [self RightCollision];
    
}

/*
 ONE:160 480+24
 TWO:62  480+24
 THREE:270
 */

-(LHSprite*)randomSprite:(int)randomInt
{
    
    int curentLevel = 0;
    CGPoint size;
    int level = status;
    
    
    if (level == ONE)
        size = ccp(160, 480+24);
    
    
    if (level == TWO)
    {
        curentLevel = rand() % 2;
        if (curentLevel == ONE)
            size = ccp(160, 480+24);
        else
            size = ccp(60, 480+24);
    }
    
    if (level == THREE)
    {
        curentLevel = rand() % 3;
        if (curentLevel == ONE)
            size = ccp(160, 480+24);
        if (curentLevel == TWO)
            size = ccp(60, 480+24);
        if (curentLevel == THREE)
            size = ccp(270, 480+24);
    }
    
//    CCLOG(@"randomSprite:%d level:%d", randomInt,level);
    
    //test yuan
//    randomInt = 7;
    
    switch (randomInt)
    {
        case 3:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-93" fromSpriteHelperScene:@"gamemain" tag:DAYU];
            [sprite transformPosition:size];
            return sprite;
        }
        case 4:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-73" fromSpriteHelperScene:@"gamemain" tag:ZHONGYU];
            [sprite transformPosition:size];
            return sprite;
            
        }
        case 5:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-10" fromSpriteHelperScene:@"gamemain" tag:XIAOYU];
            [sprite transformPosition:size];
            return sprite;
            
        }
        case 6:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-13" fromSpriteHelperScene:@"gamemain" tag:DAROU];
            [sprite transformPosition:size];
            return sprite;
            
        }
        case  7:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-35" fromSpriteHelperScene:@"gamemain" tag:ZHONGROU];
            [sprite transformPosition:size];
            return sprite;
            
        }
        case 8:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-12" fromSpriteHelperScene:@"gamemain" tag:XIAOROU];
            [sprite transformPosition:size];
            return sprite;
            
        }
        case 9:
        {
            LHSprite* sprite = [lh createPhysicalSpriteWithName:@"p-14" fromSpriteHelperScene:@"gamemain" tag:GOOD];
            [sprite transformPosition:size];
            return sprite;
            
        }
            //2 种
        case 10:
        {
            int num = rand() % 2;
            LHSprite* sprite;
            if (num == 0)
            {
                sprite = [lh createPhysicalSpriteWithName:@"p-33" fromSpriteHelperScene:@"gamemain" tag:BAD];
                [sprite transformPosition:size];
            }
            else
            {
                sprite = [lh createPhysicalSpriteWithName:@"p-9" fromSpriteHelperScene:@"gamemain" tag:BAD];
                [sprite transformPosition:size];
            }
            return sprite;
            
        }
            
        default:
            break;
    }
}

- (void)addTarget
{
    //随即生成不同吃的
    int r = rand() % 11;
    if ( (r == 0) || (r == 1) )
        r = 9;
    if (r == 2)
        r = 10;
    
    LHSprite* target = [self randomSprite:r];
    [self addChild:target];
//    CCLOG(@"uname:%@", [target uniqueName]);
}

-(void)gameLogic:(ccTime)dt
{
    if (parse == 0)
    {
        
    }
    
    [self addTarget];
}


////////////////////////////////////////////////////////////////////////////////
// initialize your instance here
-(id) init
{
	if( (self=[super init]))
    {
		CGSize size = [CCDirector sharedDirector].winSize;
      
		
        tick = 0;
        realtick = 0;
        
        //显示猪脚 表情动作
        LEFTCAT = NO;
        LEFTDOG = NO;
        CENCAT = NO;
        CENDOG = NO;
        RIGHTCAT = NO;
        RIGHTDOG = NO;
        
        //当前3个位置的猪脚  NO代表狗   YES代表猫
        CENTERZHUJIAO = NO;
        LEFTZHUJIAO = NO; 
        RIGHTZHUJIAO = NO;
        shengming = 3;
        
        parse = 0;
        interval = 2.8;
        status = ONE;
        gameStatus = GAMEING;
        opacity = 0;
        allbody = [[NSMutableArray alloc] init];
        noPhySprite = [[NSMutableArray alloc] init];
        zhujiaoSprite = [[NSMutableArray alloc] init];
        // enable touches
		self.isTouchEnabled = YES;
		
		// enable accelerometer
		self.isAccelerometerEnabled = YES;
		
		[[[CCDirector sharedDirector] openGLView] setMultipleTouchEnabled:YES];
        
		// Define the gravity vector.
		b2Vec2 gravity;
		gravity.Set(0.0f, -5.0f);
		
		// Construct a world object, which will hold and simulate the rigid bodies.
		world = new b2World(gravity);
		
		world->SetContinuousPhysics(true);
		
		// Debug Draw functions
		m_debugDraw = new GLESDebugDraw();
		world->SetDebugDraw(m_debugDraw);
		
		uint32 flags = 0;
		flags += b2Draw::e_shapeBit;
		flags += b2Draw::e_jointBit;
		m_debugDraw->SetFlags(flags);		
				
		[self schedule: @selector(tick:) interval:1.0f/60.0f];
		
        //TUTORIAL - loading one of the levels - test each level to see how it works
        lh = [[LevelHelperLoader alloc] initWithContentOfFile:@"level"];

        //notification have to be added before creating the objects
        //if you dont want notifications - it is better to remove this lines
//        [lh registerNotifierOnAllPathEndPoints:self selector:@selector(spriteMoveOnPathEnded:pathUniqueName:)];
        [lh registerNotifierOnAllAnimationEnds:self selector:@selector(spriteAnimHasEnded:animationName:)];
        [lh enableNotifOnLoopForeverAnimations];
        
        
        //creating the objects
        [lh addObjectsToWorld:world cocos2dLayer:self];
        
        if([lh hasPhysicBoundaries])
            [lh createPhysicBoundaries:world];
        
        if(![lh isGravityZero])
            [lh createGravity:world];
        
        
        
        //导入关卡对象并做动画处理
        [self retrieveRequiredObjects]; // Retrieve all objects after we’ve loaded the level.
        
        //碰撞处理
        [self setupCollisionHandling];
        
        [self schedule:@selector(gameLogic:) interval:interval];
        
	}
	return self;
}
////////////////////////////////////////////////////////////////////////////////
//-(void)spriteMoveOnPathEnded:(LHSprite*)spr pathUniqueName:(NSString*)pathName
//{
//    NSLog(@"Sprite \"%@\" movement on path \"%@\" has just ended.", [spr uniqueName], pathName);    
//}
////////////////////////////////////////////////////////////////////////////////


//动画完成通知 yuan
-(void) spriteAnimHasEnded:(LHSprite*)spr animationName:(NSString*)animName
{
//    CCLOG(@"Animation with name %@ has ended on sprite %@", animName, [spr uniqueName]);
    
    
    //检测是不是游戏OVER
    if (gameStatus == GAMEEND)
    {
        //        CCLOG(@"切换游戏结束场景");
    }
    
#if 1
    //动画完成删除掉精灵
    if ((![animName isEqualToString:@"dog_jieshiwu"]) && (![animName isEqualToString:@"cat_jieshiwu"]))
    {
        int tag = [spr tag];
        
        //删除完成的动画表情
        [spr removeSelf];
        
        //根据标签恢复对应猪脚动画
        switch (tag)
        {
            case CAT:
            {
                [self CenterCollision];
                CENCAT = NO;
                cat1.visible = YES;
                [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat1];
                [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat1];
                break;
            }
            case CAT2:
            {
                [self LeftCollision];
                LEFTCAT = NO;
                cat2.visible = YES;
                [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat2];
                [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat2];
                break;
            }
            case CAT3:
            {
                [self RightCollision];
                RIGHTCAT = NO;
                cat3.visible = YES;
                [lh prepareAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat3];
                [lh startAnimationWithUniqueName:@"cat_jieshiwu" onSprite:cat3];
                break;
            }
            case DOG:
            {
                [self CenterCollision];
                CENDOG = NO;
                dog1.visible = YES;
                [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog1];
                [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog1];
                break;
            }
            case DOG2:
            {
                [self LeftCollision];
                LEFTDOG = NO;
                dog2.visible = YES;
                [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog2];
                [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog2];
                break;
            }
            case DOG3:
            {
                [self RightCollision];
                RIGHTDOG = NO;
                dog3.visible = YES;
                [lh prepareAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog3];
                [lh startAnimationWithUniqueName:@"dog_jieshiwu" onSprite:dog3];
                break;
            }
                
            default:
                break;
        }
        
        
    }
    
#endif
    
}

//设置关卡 一共3种关卡 对应3个猪脚位置
- (void)updaTick
{
    tick++;
    if (tick % 60 == 0)
        realtick++;
    
    //test
//    realtick = 0;
    
    if (status == THREE)
        return;
    
    
    //第二关
    if (realtick >= 3 && realtick < 10)
    {
        if (status == ONE)
        {
            status = TWO;
            [self dogJieshiwu:DOG2];
        }
        
    }
    
    //第三关
    if (realtick >= 10)
    {
        if (status == TWO)
        {
            status = THREE;
            [self dogJieshiwu:DOG3];
        }
    }
    
    //超级模式
    //
    
    
}

////////////////////////////////////////////////////////////////////////////////
//FIX TIME STEPT------------>>>>>>>>>>>>>>>>>>
-(void) tick: (ccTime) dt
{
	
    //设置透明
    opacity += 20;
    if (opacity >= 254)
    {
        opacity = 254;
       
    }
    if (opacity < 254)
    {
        bg.opacity = opacity;
//        dog1.visible = YES;
    }
    
    //计时器
    [self updaTick];
    
    
    [self step:dt];
    
	//Iterate over the bodies in the physics world
	for (b2Body* b = world->GetBodyList(); b; b = b->GetNext())
	{
		if (b->GetUserData() != NULL) 
        {
			//Synchronize the AtlasSprites position and rotation with the corresponding body
			CCSprite *myActor = (CCSprite*)b->GetUserData();
            
            if(myActor != 0)
            {
                //THIS IS VERY IMPORTANT - GETTING THE POSITION FROM BOX2D TO COCOS2D
                myActor.position = [LevelHelperLoader metersToPoints:b->GetPosition()];
                myActor.rotation = -1 * CC_RADIANS_TO_DEGREES(b->GetAngle());		
            }
            
        }	
	}
	
//    int num = [zhujiaoSprite count];
//    if (num > 0)
//        [self removeZhujiao];
    
    
    //删除数组中元素并且删除垃圾物体 
    int count = [allbody count];
    if (count > 0)
        [self removeSprite];
    
}


- (void)removeZhujiao
{
    int count = [zhujiaoSprite count];
    CCLOG(@"coung:%d", count);
    for (int i = 0; i < count; i++)
    {
        LHSprite *sp = [zhujiaoSprite objectAtIndex:i];
        [sp removeSelf];
        
    }
    [zhujiaoSprite release];
    zhujiaoSprite = [[NSMutableArray alloc] init];
}

- (void)removeSprite
{
    int count = [allbody count];
    for (int i = 0; i < count; i++)
    {
        LHSprite *sp = [allbody objectAtIndex:i];
        [sp removeSelf];
        
    }
    [allbody release];
    allbody = [[NSMutableArray alloc] init];
}

- (void)removeNoSprite
{
//    for (LHSprite* spr in noPhySprite)
//        [lh removeSprite:spr];
}

- (void)ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event 
{
 
    for( UITouch *touch in touches )
    {
		
        CGPoint location = [touch locationInView: [touch view]];
        location = [[CCDirector sharedDirector] convertToGL: location];
        
        if(nil != lh)
        {
            
            //触摸中间狗
            b2Body* body = [lh bodyWithTag:DOG touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body)
            {
                //说明中间狗现在没有动画 在进行
                if (CENDOG == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体 yuan
                    CCLOG(@"touch zhongjiandog");
                    [self removeNoSprite];
                    [dog1 removeSelf];
                    [self catJieshiwu:CAT];  
                    CENTERZHUJIAO = YES;
                    break;

                }
            }
            //触摸中间猫
            b2Body* body1 = [lh bodyWithTag:CAT touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body1)
            {
                //中间猫没有动画在进行
                if (CENCAT == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体
                    CCLOG(@"touch zhongjianmao");
                    [self removeNoSprite];
                    [cat1 removeSelf];
                    
                    
                    [self dogJieshiwu:DOG];  
                    CENTERZHUJIAO = NO;
                    break;
                    
                }
            }
            
            //触摸炸弹 辣椒
            b2Body* body2 = [lh bodyWithTag:BAD touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body2)
            {
                
                //make sure you have physic boundaries in the level
                //触摸标签物体
                LHSprite *spr = [lh spriteWithTag:BAD touchedAtPoint:CGPointMake(location.x, location.y)];
                [spr removeSelf];
                
                CCLOG(@"touch lajiao");
                
                break;
                
            }

            
            //触摸左边狗
            b2Body* body3 = [lh bodyWithTag:DOG2 touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body3)
            {
                //说明左边狗现在没有动画 在进行
                if (LEFTDOG == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体 yuan
                    CCLOG(@"touch zuobiangou");
                    [self removeNoSprite];
                    [dog2 removeSelf];
                    [self catJieshiwu:CAT2];
                    LEFTZHUJIAO = YES;
                    break;
                    
                }
            }
            
            
            //触摸左边猫
            b2Body* body4 = [lh bodyWithTag:CAT2 touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body4)
            {
                //中间猫没有动画在进行
                if (LEFTCAT == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体
                    CCLOG(@"touch zuobianmao");
                    [self removeNoSprite];
                    [cat2 removeSelf];
                    [self dogJieshiwu:DOG2];
                    LEFTZHUJIAO = NO;
                    break;
                    
                }
            }
            
            
            //触摸右边狗
            b2Body* body5 = [lh bodyWithTag:DOG3 touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body5)
            {
                //说明左边狗现在没有动画 在进行
                if (RIGHTDOG == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体 yuan
                    CCLOG(@"touch zuobiangou");
                    [self removeNoSprite];
                    [dog3 removeSelf];
                    [self catJieshiwu:CAT3];
                    RIGHTZHUJIAO = YES;
                    break;
                    
                }
            }
            
            //触摸右边猫
            b2Body* body6 = [lh bodyWithTag:CAT3 touchedAtPoint:CGPointMake(location.x, location.y)];
            if(0 != body6)
            {
                //说明左边狗现在没有动画 在进行
                if (RIGHTCAT == NO)
                {
                    //make sure you have physic boundaries in the level
                    //触摸标签物体 yuan
                    CCLOG(@"touch zuobiangou");
                    [self removeNoSprite];
                    [cat3 removeSelf];
                    [self dogJieshiwu:DOG3];
                    RIGHTZHUJIAO = NO;
                    break;
                    
                }
            }



        }
    }
}
////////////////////////////////////////////////////////////////////////////////
- (void)ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
//    for( UITouch *touch in touches )
//    {
//		
//        CGPoint location = [touch locationInView: [touch view]];
//        location = [[CCDirector sharedDirector] convertToGL: location];        
//        
//        if(nil != mouseJoint)
//        {
//            if(nil != lh)
//            {
//                [lh setTarget:location onMouseJoint:mouseJoint];
//            }
//        }    
//    }
}
////////////////////////////////////////////////////////////////////////////////
- (void)ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
//    if(mouseJoint != 0)
//    {
//		world->DestroyJoint(mouseJoint);
//		mouseJoint = NULL;
//	}
//    
//	for( UITouch *touch in touches )
//    {
//
//		CGPoint location = [touch locationInView: [touch view]];
//		location = [[CCDirector sharedDirector] convertToGL: location];
//		
//	}
}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
-(void) draw
{
	// Default GL states: GL_TEXTURE_2D, GL_VERTEX_ARRAY, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	// Needed states:  GL_VERTEX_ARRAY,
	// Unneeded states: GL_TEXTURE_2D, GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY
	glDisable(GL_TEXTURE_2D);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	
	world->DrawDebugData();
	
	// restore default GL states
	glEnable(GL_TEXTURE_2D);
	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    
}



//

-(BOOL) respondsToSelector:(SEL)aSelector
{
    printf("SELECTOR: %s\n", [NSStringFromSelector(aSelector) UTF8String]);
    return [super respondsToSelector:aSelector];
}



////////////////////////////////////////////////////////////////////////////////
// on "dealloc" you need to release all your retained objects
- (void) dealloc
{
    
    if(nil != lh)
        [lh release];

    [allbody release];
    [zhujiaoSprite release];
    [allbody release];
    
	delete world;
	world = NULL;
	
  	delete m_debugDraw;

	// don't forget to call "super dealloc"
	[super dealloc];
}



//yuan animation




//        LHSprite *sprite = [lh createPhysicalSpriteWithName:@"p-73" fromSpriteHelperScene:@"image" tag:LAJIAO];
//        [sprite transformPosition:ccp(160.0,480.0)];
//        [self addChild:sprite];
//
//        CCLOG(@"  222 %f  %f",sprite.position.x, sprite.position.y);
//    CGSize size = [CCDirector sharedDirector].winSize;
////    sprite.position = ccp(size.width/2,size.height/2);
//    sprite.position = ccp(100.0,480.0);
//    [self addChild:sprite];
//    CCLOG(@"  222 %f  %f",sprite.position.x, sprite.position.y);


//prepare an animation on the sprite
//    [lh prepareAnimationWithUniqueName:@"dogDengdai" onSprite:sprite];
//    [lh startAnimationWithUniqueName:@"dogDengdai" onSprite:sprite];



//other animation methods can be found in LHSprite.h

/*
 -(void) prepareAnimationNamed:(NSString*)animName fromSHScene:(NSString*)shScene;
 
 -(void) playAnimation;
 -(void) pauseAnimation;
 -(void) restartAnimation;
 -(void) stopAnimation; //removes the animation entirely
 
 -(bool) isAnimationPaused;
 
 -(NSString*) animationName;
 -(int) numberOfFrames;
 -(int) currentFrame;
 
 -(float) animationDelayPerUnit;
 -(void) setAnimationDelayPerUnit:(float)d;
 
 -(float)animationDuration;//return how much time will take for a loop to complete
 
 -(void)setFrame:(int)frmNo;
 -(void) nextFrame;
 -(void) prevFrame;
 
 -(void) nextFrameAndRepeat; //will loop when it reaches end
 -(void) prevFrameAndRepeat; //will loop when it reaches start
 
 -(bool) isAtLastFrame;
 */

@end
////////////////////////////////////////////////////////////////////////////////
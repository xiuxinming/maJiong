//
//  gameManager.m
//  eatIt
//
//  Created by 高 源 on 12-9-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import "gameManager.h"


@implementation gameManager


//静态全局变量
static	gameManager* _sharedGameManager = nil;

@synthesize score,lianjie;


#pragma 单例模式初始化部分

-(id)init
{
    self = [super init];
    
	if(self != nil)
	{
        score = 0;
        lianjie = 0;
        
        
    }
    
    
    return  self;
    
    
}

//类方法
+(gameManager*)sharedGameManager
{
	@synchronized([gameManager class])
	{
		if(!_sharedGameManager)[[self alloc] init];
		return _sharedGameManager;
	}
	return nil;
}


+(id)alloc
{
    @synchronized([gameManager class])
    {
        NSAssert(_sharedGameManager == nil,
                 @"attempted to allocate a second instance of the Game Manager singletion");
        _sharedGameManager = [super alloc];
        return _sharedGameManager;
    }
}



- (void) dealloc
{
    
    //最后释放整个单例类
	_sharedGameManager = nil;
	[super dealloc];
}



@end

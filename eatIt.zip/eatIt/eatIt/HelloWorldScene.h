//
//  HelloWorldScene.h
//  presentation
//
//  Created by Bogdan Vladu on 15.03.2011.
//


// When you import this file, you import all the cocos2d classes
#import "cocos2d.h"
#import "Box2D.h"
#import "GLES-Render.h"
#import "LevelHelperLoader.h"
#import "LevelHelper.h"
#import "SpriteHelperLoader.h"
#import "gameManager.h"

//关卡状态
enum STATUS
{
    ONE,  //0
    TWO,
    THREE,
    STAR
};

enum GAMESTATUS
{
    GAMEING,
    GAMEEND
};



// HelloWorld Layer
@interface HelloWorldScene : CCLayer
{
	b2World* world;
	GLESDebugDraw *m_debugDraw;
    
	LevelHelperLoader* lh; 
    
    LHSprite *bg;
    int status;
    int gameStatus;
    int opacity;
    
    LHSprite *cat1;   //中间猫
    LHSprite *cat2; //左猫
    LHSprite *cat3;//右猫
    
    LHSprite *dog1;//中间狗
    LHSprite *dog2;//左狗
    LHSprite *dog3;//右狗
    
    LHSprite *ming1;
    LHSprite *ming2;
    LHSprite *ming3;
    LHSprite *si1;
    LHSprite *si2;
    LHSprite *si3;
    
    
    
    //销毁的碰撞物体
    NSMutableArray *allbody;
    
    //每次切换猪脚时删除所有未完成的动画精灵
    NSMutableArray *noPhySprite;
    
    //每次碰撞要删除的猪脚位置
    NSMutableArray *zhujiaoSprite;
    
    int parse;
    int interval;
   
}

// returns a Scene that contains the HelloWorld as the only child
+(id) scene;

@property (nonatomic, assign) int parse;
@property (nonatomic, assign) int interval;
@property (nonatomic, assign) int opacity;
@property (nonatomic, assign) int gameStatus;
@property (nonatomic, assign) int status;
@property (retain) NSMutableArray* allbody;
@property (retain) NSMutableArray* noPhySprite;
@property (retain) NSMutableArray* zhujiaoSprite;
@property (retain) LHSprite *cat1;
@property (retain) LHSprite *cat2;
@property (retain) LHSprite *cat3;
@property (retain) LHSprite *dog1;
@property (retain) LHSprite *dog2;
@property (retain) LHSprite *dog3;

- (void)updaTick;


- (void)catJiedao:(int)station;
- (void)catDeyi:(int)station;
- (void)catDengdai:(int)station;
- (void)catChicuo:(int)station;
- (void)catJieshiwu:(int)tag;


- (void)dogChicuo:(int)station;
- (void)dogJieshiwu:(int)tag;
- (void)dogJiedao:(int)station;
- (void)dogDeyi:(int)station;
- (void)dogDengdai:(int)station;

- (void)removeNoSprite;
- (int)tagBysprite:(LHSprite*)sprite;
-(int) tagBytag:(int) tag;
@end

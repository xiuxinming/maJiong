//
//  loading.h
//  load
//
//  Created by Gao Yuan on 12年9月13日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "CCBReader.h"
#import "HelloWorldScene.h"

@interface loading : CCLayer 
{
    int timeOver;
}

@property (nonatomic, assign) int timeOver;
@end

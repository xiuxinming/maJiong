//
//  RootViewController.h
//  eatIt
//
//  Created by 高 源 on 12-9-11.
//  Copyright __MyCompanyName__ 2012年. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface RootViewController : UIViewController {

}

@end

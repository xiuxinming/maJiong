//
//  gameManager.h
//  eatIt
//
//  Created by 高 源 on 12-9-16.
//  Copyright 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface gameManager : NSObject
{
    int score;
    int lianjie;
    
    
}

@property (nonatomic, assign) int score;
@property (nonatomic, assign) int lianjie;

//单例模式
+(gameManager*)sharedGameManager;

@end

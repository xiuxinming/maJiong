//
//  loading.m
//  load
//
//  Created by Gao Yuan on 12年9月13日.
//  Copyright 2012年 Yuan. All rights reserved.
//

#import "loading.h"


@implementation loading
//@synthesize timeOver;


- (void)didLoadFromCCB
{
    CCLOG(@"11111");
    timeOver = 0;
    [self schedule:@selector(timeover) interval:1];
}


- (void)timeover
{
    timeOver++;
    if (timeOver >= 3)
    {
        [[CCDirector sharedDirector] replaceScene:[HelloWorldScene scene]];
//        [[CCDirector sharedDirector] replaceScene:[CCTransitionScene transitionWithDuration:1.2f scene:[HelloWorldScene scene]]];
    }
}

@end


/*
 
 */